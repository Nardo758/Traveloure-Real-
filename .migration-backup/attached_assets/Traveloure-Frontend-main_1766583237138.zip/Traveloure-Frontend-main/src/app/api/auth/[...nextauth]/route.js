import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import FacebookProvider from "next-auth/providers/facebook";
import CredentialsProvider from "next-auth/providers/credentials";

// Simple JWT decoder function (no external dependencies needed)
function decodeJWT(token) {
  if (!token) return null;
  
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join('')
    );
    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error('Failed to decode JWT token:', error);
    return null;
  }
}

// Check if token is expired
function isTokenExpired(token) {
  if (!token) return true;
  
  try {
    const decoded = decodeJWT(token);
    if (!decoded || !decoded.exp) return true;
    
    // Add 30 second buffer to refresh before actual expiration
    const bufferTime = 30 * 1000; // 30 seconds
    const expirationTime = decoded.exp * 1000; // Convert to milliseconds
    return Date.now() >= (expirationTime - bufferTime);
  } catch (error) {
    console.error('Error checking token expiration:', error);
    return true;
  }
}

// Refresh access token using refresh token
async function refreshAccessToken(refreshToken) {
  if (!refreshToken) {
    throw new Error('No refresh token provided');
  }

  try {
    
    const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
    const response = await fetch(`${apiBaseUrl}/auth/refresh-token/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        refresh: refreshToken
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('🔴 Token refresh failed:', data);
      throw new Error(data?.detail || 'Failed to refresh token');
    }

    return {
      accessToken: data.access,
      refreshToken: data.refresh || refreshToken, // Use new refresh token if provided
      expires: data.expires || null,
    };
  } catch (error) {
    console.error('🔴 Token refresh error:', error);
    throw error;
  }
}


const handler = NextAuth({
  debug: true, // Enable debug mode
  url: process.env.NEXTAUTH_URL,
  providers: [
    // Google OAuth Login
    GoogleProvider({
      clientId: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
      clientSecret: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_SECRET,
      authorization: {
        params: {
          prompt: "consent",
          access_type: "offline",
          response_type: "code"
        }
      }
    }),

    // Facebook OAuth Login
    FacebookProvider({
      clientId: process.env.FACEBOOK_CLIENT_ID,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    }),

    // Email/Password Login (Credentials) and External Token Login
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
        accessToken: { label: "Access Token", type: "text" },
        refreshToken: { label: "Refresh Token", type: "text" },
        userData: { label: "User Data", type: "text" },
      },
      async authorize(credentials) {
              // Handle external token login (from URL callback)
      if (credentials?.accessToken) {
      
        
        try {
          // Parse user data if provided
          let userData = null;
          if (credentials.userData) {
            try {
              userData = JSON.parse(credentials.userData);
            } catch (e) {
              console.warn('⚠️ Could not parse user data:', e);
            }
          }

          // If no user data provided, fetch it from backend
          if (!userData) {
            const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
            const userResponse = await fetch(`${apiBaseUrl}/auth/user/`, {
              headers: {
                'Authorization': `Bearer ${credentials.accessToken}`,
                'Content-Type': 'application/json',
              },
            });

            if (userResponse.ok) {
              userData = await userResponse.json();
            } else {
              console.warn("⚠️ Failed to fetch user data from backend");
            }
          }

          const result = {
            id: userData?.id || 'external-user',
            name: userData?.name || userData?.first_name || 'User',
            email: userData?.email || '',
            accessToken: credentials.accessToken,
            refreshToken: credentials.refreshToken,
            backendData: userData,
            provider: 'external',
          };
          
          return result;
        } catch (err) {
          console.error("🔴 External token login failed:", err);
          return null;
        }
      }

        // Handle regular email/password login
        try {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
         

          const res = await fetch(`${apiBaseUrl}/auth/login/`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              email_or_username: credentials?.email,
              password: credentials?.password,
            }),
          });

          const data = await res.json();
        
          if (!res.ok) {
            throw new Error(data?.detail || "Invalid credentials");
          }

          // Check for access token in different possible locations
          const accessToken = data.tokens?.access || data.access || data.access_token || data.accessToken;

          if (!accessToken) {
            throw new Error("No access token received from server");
          }

          // Fetch complete user data using the access token
          let userData = null;
          try {
            const userResponse = await fetch(`${apiBaseUrl}/auth/user/`, {
              headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
              },
            });

            if (userResponse.ok) {
              userData = await userResponse.json();
            } else {
              console.warn("⚠️ Failed to fetch user data, using tokens data");
            }
          } catch (err) {
            console.warn("⚠️ Error fetching user data:", err);
          }

          // Merge tokens data with user data, preserving roles from login response
          const mergedData = {
            ...data,
            user: {
              ...data.user, // Root user from login response (contains roles)
              ...userData,  // Fetched user data (may have additional fields)
            },
          };

          // Get refresh token from different possible locations
          const refreshToken = data.tokens?.refresh || data.refresh || data.refresh_token || data.refreshToken;

          const result = {
            id: userData?.id || data.tokens?.id || data.user?.id || data.id,
            name: userData?.first_name || data.tokens?.first_name || data.user?.name || data.user?.first_name || data.first_name,
            email: userData?.email || data.tokens?.email || data.user?.email || data.email,
            accessToken: accessToken,
            refreshToken: refreshToken,
            backendData: mergedData,
          };

      

          return result;
        } catch (err) {
          console.error("🔴 Credentials login failed:", {
            error: err.message,
            stack: err.stack,
            credentials: {
              email: credentials?.email,
              hasPassword: !!credentials?.password
            },
            apiUrl: `${process.env.NEXT_PUBLIC_API_BASE_URL}/auth/login/`
          });
          
          // Check if it's a network error
          if (err.message.includes('fetch')) {
            console.error("🔴 Network error - Backend API might be down or unreachable");
          }
          
          return null;
        }
      },
    }),
  ],

  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },

  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "google") {
        try {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
          const response = await fetch(`${apiBaseUrl}/auth/google-callback/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: user.email,
              name: user.name,
              picture: user.image,
              google_id: profile.sub,
              access_token: account.access_token,
              id_token: account.id_token,
              refresh_token: account.refresh_token
            }),
          });

          const data = await response.json();

          if (!response.ok) {
            return false;
          }

          account.backendResponse = data;
          return true;
        } catch (err) {
          console.error("🔴 Google login error:", err);
          return false;
        }
      }

      if (account?.provider === "facebook") {
        try {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
          const response = await fetch(`${apiBaseUrl}/auth/facebook-callback/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: user.email,
              name: user.name,
              picture: user.image,
              facebook_id: profile.id,
              access_token: account.access_token,
            }),
          });

          const data = await response.json();

          if (!response.ok) {
            console.error("🔴 Facebook callback backend failed:", data);
            return false;
          }

          account.backendResponse = data;
          return true;
        } catch (err) {
          console.error("🔴 Facebook login error:", err);
          return false;
        }
      }

      return true; // allow credentials login to proceed
    },

    async jwt({ token, account, user, trigger }) {
      
      // Initial sign in
      if (account?.provider === "google" && account.backendResponse) {
        token.accessToken = account.backendResponse.access;
        token.refreshToken = account.backendResponse.refresh;
        token.backendData = account.backendResponse;
        token.expiresAt = account.backendResponse.expires || null;
      }

      // Handle Facebook backend response
      if (account?.provider === "facebook" && account.backendResponse) {
        token.accessToken = account.backendResponse.access;
        token.refreshToken = account.backendResponse.refresh;
        token.backendData = account.backendResponse;
        token.expiresAt = account.backendResponse.expires || null;
        token.provider = "facebook";
      } else if (account?.provider === "facebook") {
        // Fallback for Facebook without backend response
        token.accessToken = account.access_token;
        token.provider = "facebook";
      }

      if (user?.accessToken) {
        // From credentials login or external token login
        token.accessToken = user.accessToken;
        token.refreshToken = user.refreshToken;
        token.expiresAt = user.backendData?.expires || null;
        token.provider = user.provider || 'credentials';
        
        // Store full backendData to preserve all fields including toggle_role
        if (user.backendData) {
          token.backendData = user.backendData;
        }
        
        // Store only essential user data in token to reduce size
        if (user.backendData?.user) {
          token.userId = user.backendData.user.id;
          token.userEmail = user.backendData.user.email;
          token.userName = user.backendData.user.name || user.backendData.user.first_name;
          token.isLocalExpert = user.backendData.user.is_local_expert || false;
          token.isAdmin = user.backendData.user.is_admin || user.backendData.user.is_superuser || false;
          token.userRoles = user.backendData.user.roles || [];
          token.toggleRole = user.backendData.user.toggle_role || null;
        }
      }

      // Handle token refresh (for Google, credentials, external tokens, and Facebook with backend response)
      if (token.accessToken && token.refreshToken && token.backendData) {
        
        try {
          const expired = isTokenExpired(token.accessToken);
          
          if (expired) {
            
            try {
              const newTokens = await refreshAccessToken(token.refreshToken);
              
              token.accessToken = newTokens.accessToken;
              token.refreshToken = newTokens.refreshToken;
              token.expiresAt = newTokens.expires;
              
            } catch (error) {
              
              // Clear tokens on refresh failure
              token.accessToken = null;
              token.refreshToken = null;
              token.backendData = null;
              token.expiresAt = null;
            }
          } else {
            console.log("✅ Token is still valid");
          }
        } catch (error) {
          console.error("🔴 JWT token check error:", error);
        }
      }

      return token;
    },

    async session({ session, token }) {
      // Keep original session structure but optimize data size
      session.refreshToken = token.refreshToken;
      session.expiresAt = token.expiresAt;
      session.provider = token.provider;
      
      // Reconstruct backendData from optimized token data
      if (token.userId) {
        // Reconstruct backendData for credentials login
        session.backendData = {
          accessToken: token.accessToken,
          user: {
            id: token.userId,
            email: token.userEmail,
            name: token.userName,
            first_name: token.userName,
            is_local_expert: token.isLocalExpert,
            is_admin: token.isAdmin,
            is_superuser: token.isAdmin,
            roles: token.userRoles,
            toggle_role: token.toggleRole,
          }
        };
      } else if (token.backendData) {
        // Keep original backendData for OAuth logins
        session.backendData = token.backendData;
      } else {
        session.backendData = {};
      }
      
      // Ensure accessToken is at the right level (same as before)
      if (session.backendData.backendData?.accessToken) {
        session.backendData.accessToken = session.backendData.backendData.accessToken;
      } else if (token.accessToken) {
        session.backendData.accessToken = token.accessToken;
      }
      
      // Set user info from backendData (same structure as before)
      if (token.backendData || token.userId) {
        // Handle nested backendData structure
        const nestedBackendData = session.backendData.backendData || session.backendData;
        const userData = nestedBackendData.user || session.backendData.user;
        const rootUserData = session.backendData.user; // Root user object from backend response (contains roles)
        
        session.user = {
          id: userData?.id || session.backendData.tokens?.id || session.backendData.user?.id || session.backendData.id,
          name: userData?.name || userData?.first_name || session.backendData.tokens?.first_name || session.backendData.user?.name || session.backendData.user?.first_name || session.backendData.name || session.backendData.first_name,
          email: userData?.email || session.backendData.tokens?.email || session.backendData.user?.email || session.backendData.email,
          username: userData?.username || session.backendData.tokens?.username || session.backendData.user?.username || session.backendData.username,
          last_name: userData?.last_name || session.backendData.tokens?.last_name || session.backendData.user?.last_name || session.backendData.last_name,
          is_local_expert: userData?.is_local_expert || session.backendData.tokens?.is_local_expert || session.backendData.user?.is_local_expert || session.backendData.is_local_expert,
          is_admin: userData?.is_admin || userData?.is_superuser || session.backendData.tokens?.is_admin || session.backendData.user?.is_admin || session.backendData.is_admin || session.backendData.tokens?.is_superuser || session.backendData.user?.is_superuser || session.backendData.is_superuser,
          role: userData?.role || session.backendData.tokens?.role || session.backendData.user?.role || session.backendData.role,
          roles: rootUserData?.roles || userData?.roles || session.backendData.roles || session.backendData.tokens?.roles || session.backendData.user?.roles || [],
          toggle_role: userData?.toggle_role || session.backendData.tokens?.toggle_role || session.backendData.user?.toggle_role || session.backendData.toggle_role || token.toggleRole || null,
        };
      } else {
        // Fallback: create user object from token data
        session.user = {
          id: token.id,
          name: token.name,
          email: token.email,
        };
      }
      
      return session;
    },

    async signOut({ token }) {
      
      // If we have a backend token, try to logout from backend
      if (token?.accessToken) {
        try {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
          await fetch(`${apiBaseUrl}/auth/logout/`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token.accessToken}`,
              'Content-Type': 'application/json',
            },
          });
        } catch (error) {
          console.warn("⚠️ Backend logout failed:", error);
          // Don't throw error, continue with client-side logout
        }
      }
      
      return true;
    },
  },

  pages: {
    signIn: '/login',
    error: '/login',
  },

  secret: process.env.NEXTAUTH_SECRET,
});

export { handler as GET, handler as POST };