import { toast as sonnerToast } from "sonner";

export const useToast = () => ({
  toast: sonnerToast, // Provide the toast from Sonner
});
