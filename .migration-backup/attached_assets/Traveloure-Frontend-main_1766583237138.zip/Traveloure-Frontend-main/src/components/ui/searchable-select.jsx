'use client'

import { useState, useRef, useEffect } from 'react'
import { ChevronDown, Search, X } from 'lucide-react'
import { Button } from './button'
import { Input } from './input'

export function SearchableSelect({
  value,
  onValueChange,
  placeholder = "Select option...",
  options = [],
  searchable = false,
  maxHeight = "200px",
  className = ""
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const dropdownRef = useRef(null)

  // Filter options based on search term - search through ALL options
  const filteredOptions = searchable 
    ? options.filter(option => 
        option.label.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : options

  // Limit display to first 100 results for performance, but search through all
  const displayOptions = filteredOptions.slice(0, 100)

  // Get current option label
  const currentOption = options.find(option => option.value === value)
  const displayValue = currentOption ? currentOption.label : placeholder

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
        setSearchTerm("")
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSelect = (option) => {
    onValueChange(option.value)
    setIsOpen(false)
    setSearchTerm("")
  }

  const handleClear = (e) => {
    e.stopPropagation()
    onValueChange("all")
    setIsOpen(false)
    setSearchTerm("")
  }

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <Button
        type="button"
        variant="outline"
        className="w-full justify-between h-10 border-none bg-white"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="truncate">{displayValue}</span>
        <div className="flex items-center gap-1">
          {value !== "all" && (
            <X 
              className="h-4 w-4 text-gray-400 hover:text-gray-600" 
              onClick={handleClear}
            />
          )}
          <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </Button>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
          {searchable && (
            <div className="p-2 border-b border-gray-100">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-8 text-sm"
                  autoFocus
                />
              </div>
            </div>
          )}
          
          <div 
            className="overflow-y-auto"
            style={{ maxHeight }}
          >
            {displayOptions.length > 0 ? (
              displayOptions.map((option, index) => (
                <button
                  key={`${option.value}-${index}`}
                  type="button"
                  className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-100 ${
                    value === option.value ? 'bg-blue-50 text-blue-600' : 'text-gray-700'
                  }`}
                  onClick={() => handleSelect(option)}
                >
                  {option.label}
                </button>
              ))
            ) : (
              <div className="px-3 py-2 text-sm text-gray-500">
                {searchTerm ? 'No options found' : 'No options available'}
              </div>
            )}
            {filteredOptions.length > 100 && (
              <div className="px-3 py-2 text-sm text-gray-400 border-t border-gray-100">
                Showing 100 of {filteredOptions.length} results. Type to search for more.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
} 