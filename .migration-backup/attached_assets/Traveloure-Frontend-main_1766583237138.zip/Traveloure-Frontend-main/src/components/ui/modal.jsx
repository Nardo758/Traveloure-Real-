import { VisuallyHidden } from "@radix-ui/react-visually-hidden"

export function Modal({ open, onOpenChange, children }) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-fade-in" />
        <Dialog.Content className="fixed top-[50%] left-[50%] max-h-[85vh] w-[90vw] max-w-md -translate-x-[50%] -translate-y-[50%] overflow-auto rounded-md bg-white p-6 shadow-lg focus:outline-none data-[state=open]:animate-fade-in-slide-up">
          {/* Hidden title fallback to avoid error */}
          <VisuallyHidden>
            <Dialog.Title>Modal</Dialog.Title>
          </VisuallyHidden>

          {children}

          <Dialog.Close asChild>
            <button
              aria-label="Close"
              className="absolute top-3 right-3 inline-flex h-6 w-6 items-center justify-center rounded-full hover:bg-gray-200 focus:outline-none"
            >
              <CrossIcon />
            </button>
          </Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
