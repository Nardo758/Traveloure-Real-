"use client"
import React, { useState, useRef } from "react"
import Image from "next/image"
import dynamic from "next/dynamic"
import { useRouter } from "next/navigation"
import domtoimage from "dom-to-image-more";
import jsPDF from "jspdf"

const MapComponent = dynamic(() => import("../map-component"), {
  ssr: false,
  loading: () => <div className="w-full h-full flex items-center justify-center bg-gray-100"><div className="w-10 h-10 border-4 border-[#FF385C] border-t-transparent rounded-full animate-spin"></div><p className="mt-2 text-gray-600">Loading map...</p></div>,
})

function formatDateRange(start, end) {
  if (!start || !end) return "Not available"
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const s = new Date(start)
  const e = new Date(end)
  if (isNaN(s) || isNaN(e)) return "Not available"
  return `${s.getDate()}${ordinal(s.getDate())} ${months[s.getMonth()]} – ${e.getDate()}${ordinal(e.getDate())} ${months[e.getMonth()]} ${e.getFullYear()}`
}
function ordinal(n) {
  return ["st", "nd", "rd"][((n + 90) % 100 - 10) % 10 - 1] || "th"
}

import ShareButton from "../share-button"
import { Share2 } from "lucide-react"

export default function AiOptimizationResult({ data = {}, tripId }) {
  const [activeDay, setActiveDay] = useState(0)
  const [showMobileMap, setShowMobileMap] = useState(false)
  const router = useRouter()


  // Use icons/emoji from API data if provided, else fallback to empty string
  const sectionIcons = (data && data?.sectionIcons) || {}
  const activityIcons = (data && data?.activityIcons) || []

  // Responsive check for mobile
  const isMobile = typeof window !== "undefined" && window.innerWidth < 1024

  const tabListRef = useRef(null)

  const scrollLeft = () => {
    if (tabListRef.current) {
      tabListRef.current.scrollLeft -= 100
    }
  }

  const scrollRight = () => {
    if (tabListRef.current) {
      tabListRef.current.scrollLeft += 100
    }
  }

  const pdfRef = useRef();


  const handleDownloadPDF = async () => {
    if (!pdfRef.current) return;
    try {
    const pages = pdfRef.current.querySelectorAll('.pdf-page');
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
      
    for (let i = 0; i < pages.length; i++) {
      const dataUrl = await domtoimage.toPng(pages[i], { bgcolor: "#fff" });
      const img = new window.Image();
      img.src = dataUrl;
      await new Promise((resolve) => { img.onload = resolve; });
      const imgProps = { width: img.width, height: img.height };
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pdfWidth = pageWidth;
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      if (i > 0) pdf.addPage();
      pdf.addImage(dataUrl, "PNG", 0, 0, pdfWidth, pdfHeight);
    }
    pdf.save(`${data?.title || "itinerary"}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  return (
    <>
      {/* Normal web UI */}
      <div className="flex flex-col min-h-screen bg-[#f5f6fa]">
        {/* Mobile Map Overlay */}
        {showMobileMap && (
          <div className="fixed inset-0 z-50 bg-white">
            <div className="h-full flex flex-col">
              <div className="p-4 flex items-center justify-between border-b">
                <h2 className="font-semibold">Map View - {data?.city || "No destination selected"}</h2>
                <div className="flex items-center gap-2">
                  {tripId && (
                    <button 
                      className="rounded-full p-2 hover:bg-gray-100 text-[#FF385C]"
                      onClick={() => {
                        setShowMobileMap(false);
                        // Trigger share modal
                        const shareButton = document.querySelector('[onclick*="setIsShareModalOpen"]');
                        if (shareButton) {
                          shareButton.click();
                        }
                      }}
                    >
                      <Share2 className="h-5 w-5" />
                    </button>
                  )}
                  <button className="rounded-full p-2 hover:bg-gray-100" onClick={() => setShowMobileMap(false)}>
                    <svg className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
              </div>
              <div className="flex-1">
                <MapComponent destination={data?.city || ""} apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY} />
              </div>
            </div>
          </div>
        )}
        {/* Beta Banner */}
        <div className="w-full bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white py-2 px-4 text-center relative overflow-hidden border-b border-orange-300">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10 container mx-auto flex items-center justify-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold animate-pulse">
              🚀 BETA
            </span>
            <span className="text-xs md:text-sm font-medium">
              Testing new features • Your feedback helps us improve
            </span>
          </div>
        </div>

        {/* Header */}
        <header className="flex items-center justify-between px-4 md:px-8 py-4 border-b bg-white sticky top-0 z-30 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <Image 
                onClick={() => router.push("/")} 
                src="/Main-logo.png" 
                alt="Main Logo" 
                width={150} 
                height={150}
                className="cursor-pointer"
              />
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white shadow-md border border-orange-300">
                🚀 BETA
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 md:gap-3">
            <button
              className="flex items-center gap-1 md:gap-2 bg-[#FF385C] hover:bg-[#e02d50] text-white font-semibold px-3 md:px-5 py-2 rounded-lg shadow transition text-sm md:text-base"
              onClick={handleDownloadPDF}
            >
              <svg className="w-3 h-3 md:w-4 md:h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v12m0 0l-4-4m4 4l4-4M4 20h16" />
              </svg>
              <span className="hidden sm:inline">Download PDF</span>
              <span className="sm:hidden">PDF</span>
            </button>
           
              <ShareButton 
                tripId={tripId} 
                tripTitle={data?.title || data?.city || "My Trip"} 
                onDownloadPDF={handleDownloadPDF}
              />
           
          </div>
        </header>
        {/* Show Map Button for Mobile */}
        <div className="lg:hidden sticky top-0 z-10 bg-white p-2 border-b flex justify-center">
          <button
            className="w-full max-w-xs rounded-full shadow-sm bg-transparent border border-[#FF385C] text-[#FF385C] flex items-center justify-center py-2 text-sm"
            onClick={() => setShowMobileMap(true)}
          >
            <svg className="h-4 w-4 mr-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A2 2 0 0 1 2 15.382V6.618a2 2 0 0 1 1.553-1.946l7-2.1a2 2 0 0 1 1.894 0l7 2.1A2 2 0 0 1 22 6.618v8.764a2 2 0 1-1.553 1.946L15 20" /></svg>
            {data?.city ? `View ${data?.city} on map` : "Enter destination first"}
          </button>
        </div>

        {/* Floating Share Button for Mobile */}
        {tripId && (
          <div className="lg:hidden fixed bottom-6 right-6 z-40">
            <button
              onClick={() => {
                // Trigger share modal
                const shareButton = document.querySelector('[onclick*="setIsShareModalOpen"]');
                if (shareButton) {
                  shareButton.click();
                }
              }}
              className="bg-[#FF385C] hover:bg-[#e02d50] text-white p-3 rounded-full shadow-lg transition-colors"
            >
              <Share2 className="h-6 w-6" />
            </button>
          </div>
        )}
        <main className="flex flex-1 w-full">
          {/* Multi-page PDF export: wrap each page in .pdf-page */}
          <div ref={pdfRef} className="w-full">
            <div className="pdf-page w-full  py-4 md:py-8 px-2 sm:px-4 pdf-export">
              {/* Back Link */}
              <div className="mb-2">
                <button
                  className="text-[#222] text-base flex items-center gap-1 hover:underline bg-transparent p-0"
                  onClick={() => {
                    if (typeof window !== 'undefined') {
                      localStorage.removeItem('selectedTrip');
                      window.history.back();
                    }
                  }}
                >
                  <span className="text-xl">&lt;</span> Back to Previous Page
                </button>
              </div>
              {/* Title & Subtitle */}
              {data?.title && (
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-2 flex items-center gap-2 break-words">{data?.title} {data?.flag && <span className="text-xl md:text-2xl">{data?.flag}</span>}</h1>
              )}
              {data?.description && (
                <p className="text-gray-600 mb-6 text-base md:text-lg break-words">{data?.description}</p>
              )}

              {/* Trip Summary */}
              {data?.start_point || data?.end_point || data?.start_date || data?.end_date || (data?.summary && Object.keys(data?.summary).length > 0) ? (
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-2 text-lg md:text-xl font-bold"><span>{sectionIcons.summary || '✨'}</span> Trip Summary</div>
                  <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6 lg:gap-8 gap-y-4 text-sm md:text-base">
                      {data?.start_point && data?.end_point && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex  gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Start & End Point:</span>
                          <span className="text-gray-800 font-medium">{data?.start_point} – {data?.end_point}</span>
                        </div>
                      )}
                      {data?.start_date && data?.end_date && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex items-center  gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Dates:</span>
                          <span className="text-gray-800 font-medium">{formatDateRange(data?.start_date, data?.end_date)}</span>
                        </div>
                      )}
                      {data?.summary?.weather && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex  items-center  gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Weather Forecast:</span>
                          <span className="text-gray-800 font-medium">{data?.summary.weather}</span>
                        </div>
                      )}
                      {data?.summary?.mode && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex items-center gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Trip Mode:</span>
                          <span className="text-gray-800 font-medium">{data?.summary.mode}</span>
                        </div>
                      )}
                      {data?.summary?.total_hotels && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex items-center gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Hotels:</span>
                          <span className="text-gray-800 font-medium">{data?.summary.total_hotels} included {data?.summary.hotel_details && <span className="text-[#FF385C] underline cursor-pointer">(See Details)</span>}</span>
                        </div>
                      )}
                      {data?.summary?.coverage && (
                        <div className="flex flex-col gap-1">
                          <span className="font-semibold flex items-center gap-2"><span className="inline-block w-2 h-2 rounded-full bg-red-500"></span> Coverage:</span>
                          <span className="text-gray-800 font-medium">{data?.summary.coverage}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : null}

              {/* What's Included / Not Included */}
              {(Array.isArray(data?.inclusive) && data?.inclusive.length > 0) || (Array.isArray(data?.exclusive) && data?.exclusive.length > 0) ? (
                <div className="flex flex-col lg:flex-row gap-6 md:gap-8 mb-8">
                  {Array.isArray(data?.inclusive) && data?.inclusive.length > 0 && (
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-green-600 text-xl md:text-2xl">{sectionIcons.included || '✅'}</span> What's Included</div>
                      <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                        <ul className="pl-0 text-sm md:text-base text-gray-800 space-y-1">
                          {data?.inclusive.map((item, i) => (
                            <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{item}</span></li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                  {Array.isArray(data?.exclusive) && data?.exclusive.length > 0 && (
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">{sectionIcons.notIncluded || '❌'}</span> Not Included</div>
                      <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                        <ul className="pl-0 text-sm md:text-base text-gray-800 space-y-1">
                          {data?.exclusive.map((item, i) => (
                            <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{item}</span></li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              ) : null}

              {/* Daily Itinerary */}
              {Array.isArray(data?.itinerary) && data?.itinerary.length > 0 ? (
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-2 text-lg md:text-xl font-bold"><span>{sectionIcons.itinerary || '🗓️'}</span> Daily Itinerary</div>
                  <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                    {/* Tabs with arrows */}
                    <div className="flex items-center gap-1 md:gap-2 mb-4 md:mb-6">
                      <button onClick={scrollLeft} className="px-2 md:px-3 py-2 rounded-full bg-white font-bold text-base md:text-lg disabled:opacity-40">
                        &lt;
                      </button>
                      <div ref={tabListRef} className="flex-1 flex overflow-x-auto whitespace-nowrap scrollbar-hide">
                        {data?.itinerary.map((day, idx) => (
                          <button
                            key={day.day_number || idx}
                            className={`px-3 md:px-5 py-2 rounded-lg font-semibold text-sm md:text-base transition-all duration-150 min-w-[80px] md:min-w-[90px] flex items-center justify-center ${
                              activeDay === idx
                                ? '!bg-[#FF385C] !text-white border-2 border-[#FF385C]'
                                : 'bg-transparent text-[#FF385C] border-none hover:bg-[#ffe3ea]'
                            }`}
                            onClick={() => setActiveDay(idx)}
                          >
                            {day.day_number ? `Day ${day.day_number}` : `Day ${idx + 1}`}
                          </button>
                        ))}
                      </div>
                      <button onClick={scrollRight} className="px-2 md:px-3 py-2 rounded-full text-[#FF385C] bg-white font-bold text-base md:text-lg disabled:opacity-40">
                        &gt;
                      </button>
                    </div>
                    {/* Day Details */}
                    {data?.itinerary[activeDay] && (
                      <div className="">
                        <div className="flex items-center gap-2 text-base md:text-lg font-bold mb-2 break-words">
                          <span>{(data?.itinerary[activeDay].icon || activityIcons[activeDay % activityIcons.length] || '')}</span> {data?.itinerary[activeDay].day_number ? `Day ${data?.itinerary[activeDay].day_number}` : `Day ${activeDay + 1}`} – {data?.itinerary[activeDay].title || 'No Title'}
                        </div>
                        {data?.itinerary[activeDay].description && (
                          <div className="text-sm md:text-base mb-2 break-words"><span className="font-semibold">Theme:</span> {data?.itinerary[activeDay].description}</div>
                        )}
                        <div className="flex flex-col gap-6">
                          {Array.isArray(data?.itinerary[activeDay].activities) && data?.itinerary[activeDay].activities.length > 0 ? (
                            data?.itinerary[activeDay].activities.map((act, i) => {
                              // Compose details for the vertical list
                              const details = [];
                              if (act.time) details.push({ label: 'Time', value: act.time });
                              if (act.location) details.push({ label: 'Location', value: act.location + (act.metadata?.address ? ` (${act.metadata?.address})` : '') });
                              if (act.duration) details.push({ label: 'Duration', value: act.duration });
                              if (act.notes) details.push({ label: 'Notes', value: act.notes });
                              if (act.metadata?.estimated_cost) details.push({ label: 'Price', value: act.metadata?.estimated_cost });
                              if (act.metadata?.booking_required !== undefined) details.push({ label: 'Booking Required', value: act.metadata?.booking_required ? 'Yes' : 'No' });
                              if (act.metadata?.transport_mode) details.push({ label: 'Transport', value: act.metadata?.transport_mode });
                              if (act.metadata?.rating) details.push({ label: 'Rating', value: act.metadata?.rating });
                              if (act.metadata?.phone) details.push({ label: 'Phone', value: act.metadata?.phone });
                              return (
                                <div key={i} className="">
                                  <div className="flex items-center gap-2 text-sm md:text-base font-semibold mb-1 break-words">
                                    <span>{act.icon || activityIcons[i % activityIcons.length] || ''}</span>
                                    <span className="font-bold">{act.time ? `${act.time} – ` : ''}{act.activity || 'No Activity Name'}</span>
                                    {act.metadata?.website_url && (
                                      <a href={act.metadata?.website_url} target="_blank" rel="noopener noreferrer" className="ml-2 text-[#FF385C] underline text-xs md:text-sm">Learn More</a>
                                    )}
                                  </div>
                                  <ul className="ml-7 text-gray-700 text-sm md:text-base space-y-1">
                                    {details.map((d, idx) => (
                                      <li key={idx} className="flex items-start gap-2">
                                        <span className="inline-block w-1.5 h-1.5 mt-2 rounded-full bg-gray-400"></span>
                                        <span><span className="font-semibold">{d.label}:</span> {d.value}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              );
                            })
                          ) : (
                            <div className="text-gray-500 italic">No activities available for this day.</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : null}

              {/* Tips and Reminders */}
              {(Array.isArray(data?.tips) && data?.tips.length > 0) || (Array.isArray(data?.reminders) && data?.reminders.length > 0) ? (
                <div className="flex flex-col lg:flex-row gap-6 md:gap-8 mb-8">
                  {Array.isArray(data?.tips) && data?.tips.length > 0 && (
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span>{sectionIcons.tips || '✨'}</span> Personalized Tips</div>
                      <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm">
                        <ul className="list-disc pl-5 text-sm md:text-base text-gray-800 space-y-1">
                          {data?.tips.map((tip, i) => <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{tip}</span></li>)}
                        </ul>
                      </div>
                    </div>
                  )}
                  {Array.isArray(data?.reminders) && data?.reminders.length > 0 && (
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span>{sectionIcons.reminder || '✈️'}</span> Departure Reminder</div>
                      <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm">
                        <ul className="list-disc pl-5 text-sm md:text-base text-gray-800 space-y-1">
                          {data?.reminders.map((rem, i) => <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{rem}</span></li>)}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              ) : null}

              {/* Visa Requirements */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">📋</span> Visa Requirements</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  <p className="text-sm md:text-base text-gray-800 break-words">{data?.visa_requirements || "Not specified."}</p>
                </div>
              </div>

              {/* Health Advisories */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">🏥</span> Health Advisories</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  <p className="text-sm md:text-base text-gray-800 break-words">{data?.health_advisories || "Not specified."}</p>
                </div>
              </div>

              {/* Local Guides */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">👥</span> Local Guides</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  {data?.local_guides?.length
                    ? <ul className="pl-0 text-sm md:text-base text-gray-800 space-y-1">
                        {data?.local_guides.map((g, i) => (
                          <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{g.name} ({g.contact})</span></li>
                        ))}
                      </ul>
                    : <p className="text-sm md:text-base text-gray-800">No local guides specified.</p>}
                </div>
              </div>

              {/* Emergency Contacts */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">🚨</span> Emergency Contacts</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  {data?.emergency_contacts?.length
                    ? <ul className="pl-0 text-sm md:text-base text-gray-800 space-y-1">
                        {data?.emergency_contacts.map((c, i) => (
                          <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{c.name}: {c.phone}</span></li>
                        ))}
                      </ul>
                    : <p className="text-sm md:text-base text-gray-800">No emergency contacts specified.</p>}
                </div>
              </div>

              {/* Packing Suggestions */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">🧳</span> Packing Suggestions</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  <p className="text-sm md:text-base text-gray-800 break-words">{data?.packing_suggestions || "Not specified."}</p>
                </div>
              </div>

              {/* Local Events/Festivals */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-2 text-lg font-bold"><span className="text-red-600 text-xl md:text-2xl">🎉</span> Local Events & Festivals</div>
                <div className="bg-white rounded-2xl border border-[#ececec] p-4 md:p-6 shadow-sm overflow-hidden">
                  {data?.local_events?.length
                    ? <ul className="pl-0 text-sm md:text-base text-gray-800 space-y-1">
                        {data?.local_events.map((e, i) => (
                          <li key={i} className="flex items-start gap-2"><span className="inline-block w-2 h-2 mt-2 rounded-full bg-red-500"></span><span className="break-words">{e.name} ({e.date})</span></li>
                        ))}
                      </ul>
                    : <p className="text-sm md:text-base text-gray-800">No local events or festivals specified.</p>}
                </div>
              </div>

              {/* Chat with Travel Experts */}
              <div className="mb-8">
                      <button
                        onClick={() => router.push("/Itinerary?tab=travel-experts")}
                  className="w-full sm:w-auto bg-white cursor-pointer border border-[#FF385C] text-[#FF385C] hover:bg-gray-100 font-semibold px-6 md:px-8 py-3 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2 text-sm md:text-base"
                      >
                  <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                        Chat with Experts
                      </button>
              </div>
            </div>
            {/*
              Add more <div className="pdf-page">...</div> for additional pages as needed.
              You can split your itinerary sections into multiple .pdf-page divs for true multi-page PDF output.
            */}
          </div>
          {/* Right: Map */}
          <div className="hidden lg:block lg:w-[40%] sticky top-0 h-screen">
            <MapComponent destination={data?.city || ""} apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY} />
          </div>
        
        </main>
        <style jsx global>{`
          @media print {
            .no-print {
              display: none !important;
            }
          }
          .scrollbar-hide::-webkit-scrollbar {
            display: none;
          }
          .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
          .pdf-page {
            max-width: 100%;
            overflow-x: hidden;
          }
          @media (max-width: 640px) {
            .pdf-page {
              padding-left: 8px;
              padding-right: 8px;
            }
          }
        `}</style>
      </div>

      {/* Hidden PDF layout for export only */}
      <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0 }}>
        {/* Page 1: Trip Summary */}
        <div className="pdf-page" style={{ width: '794px', minHeight: '1123px', background: '#fff', padding: '50px', boxSizing: 'border-box', fontFamily: 'Arial, sans-serif' }}>
          {/* Header Section */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '30px', paddingBottom: '20px', border: 'none', boxShadow: 'none' }}>
            <div style={{ border: 'none', boxShadow: 'none' }}>
              <img src="/Main-logo.png" alt="TRAVELOURE Logo" style={{ width: 140, height: 'auto', marginBottom: '8px', border: 'none', boxShadow: 'none' }} />
              <div style={{ fontSize: '11px', color: '#666', marginTop: '4px', border: 'none', boxShadow: 'none' }}>Plan Less, Travel More</div>
            </div>
            <div style={{ textAlign: 'right', background: '#FF385C', color: '#fff', padding: '12px 16px', borderRadius: '6px', maxWidth: '200px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontWeight: 700, fontSize: '11px', marginBottom: '4px', letterSpacing: '0.5px' , border: 'none', boxShadow: 'none' }}>FOR ANY QUERY, CALL AT</div>
              <div style={{ fontSize: '14px', fontWeight: 600, border: 'none', boxShadow: 'none' }}>+1 (445) 6541 266</div>
            </div>
          </div>

          {/* Title Section */}
          <div style={{ marginBottom: '30px', border: 'none', boxShadow: 'none' }}>
            <h1 style={{ color: '#FF385C', fontWeight: 800, border: 'none', boxShadow: 'none', fontSize: '36px', margin: '0 0 8px 0', letterSpacing: '-0.5px' }}>TRAVEL ITINERARY</h1>
            <h2 style={{ fontWeight: 600, fontSize: '20px', margin: '0 0 0 0', color: '#333', letterSpacing: '0.3px', border: 'none', boxShadow: 'none' }}>
              TRIP TO: {data?.city?.toUpperCase() || 'N/A'}, {data?.country?.toUpperCase() || ''}
            </h2>
          </div>

          {/* Trip Summary Cards */}
          <div style={{ marginBottom: '30px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', border: 'none', boxShadow: 'none' }}>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Start & End Point</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 600, border: 'none', boxShadow: 'none' }}>{data?.start_point || 'Nazca Airport'}</div>
            </div>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Travel Dates</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 600, border: 'none', boxShadow: 'none' }}>{data?.start_date || '2025-12-06'} - {data?.end_date || '2025-12-13'}</div>
            </div>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Weather Forecast</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 500, border: 'none', boxShadow: 'none' }}>{data?.summary?.weather || data?.summary?.weather_impact || 'Optimal conditions expected'}</div>
            </div>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Trip Mode</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 500, border: 'none', boxShadow: 'none' }}>{data?.summary?.mode || data?.summary?.transport_plan || 'Private & Public Transport'}</div>
            </div>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Hotels</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 600, border: 'none', boxShadow: 'none' }}>{data?.summary?.total_hotels || '1'}</div>
            </div>
            <div style={{ background: '#f8f9fa', borderRadius: '8px', padding: '14px', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', border: 'none', boxShadow: 'none' }}>Coverage</div>
              <div style={{ fontSize: '14px', color: '#333', fontWeight: 500, border: 'none', boxShadow: 'none' }}>{data?.summary?.coverage || data?.summary?.service_coverage || 'All services assigned'}</div>
            </div>
          </div>

          {/* Statistics Boxes */}
          <div style={{ display: 'flex', gap: '12px', marginBottom: '30px', border: 'none', boxShadow: 'none' }}>
            <div style={{ flex: 1, background: 'linear-gradient(135deg, #FF385C 0%, #E02D50 100%)', borderRadius: '10px', padding: '18px', textAlign: 'center', color: '#fff', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontWeight: 700, fontSize: '28px', marginBottom: '4px', border: 'none', boxShadow: 'none' }}>{data?.summary?.total_services || '2'}</div>
              <div style={{ fontSize: '12px', opacity: 0.95, fontWeight: 500, border: 'none', boxShadow: 'none' }}>Drive Time (hrs)</div>
            </div>
            <div style={{ flex: 1, background: 'linear-gradient(135deg, #58AC00 0%, #4A8F00 100%)', borderRadius: '10px', padding: '18px', textAlign: 'center', color: '#fff', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontWeight: 700, fontSize: '28px', marginBottom: '4px', border: 'none', boxShadow: 'none' }}>{data?.summary?.total_places || '12'}</div>
              <div style={{ fontSize: '12px', opacity: 0.95, fontWeight: 500, border: 'none', boxShadow: 'none' }}>Places Visited</div>
            </div>
            <div style={{ flex: 1, background: 'linear-gradient(135deg, #FF385C 0%, #E02D50 100%)', borderRadius: '10px', padding: '18px', textAlign: 'center', color: '#fff', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontWeight: 700, fontSize: '28px', marginBottom: '4px', border: 'none', boxShadow: 'none' }}>{Array.isArray(data?.itinerary) ? data.itinerary.length : '8'}</div>
              <div style={{ fontSize: '12px', opacity: 0.95, fontWeight: 500, border: 'none', boxShadow: 'none' }}>Activities</div>
            </div>
            <div style={{ flex: 1, background: 'linear-gradient(135deg, #FF385C 0%, #E02D50 100%)', borderRadius: '10px', padding: '18px', textAlign: 'center', color: '#fff', border: 'none', boxShadow: 'none' }}>
              <div style={{ fontWeight: 700, fontSize: '28px', marginBottom: '4px', border: 'none', boxShadow: 'none' }}>{data?.summary?.budget_breakdown?.total_cost || '1200'} USD</div>
              <div style={{ fontSize: '12px', opacity: 0.95, fontWeight: 500, border: 'none', boxShadow: 'none' }}>Total Spend</div>
            </div>
          </div>

          {/* Booked Services Table */}
          <div style={{ marginBottom: '20px', border: 'none', boxShadow: 'none' }}>
            <h3 style={{ fontWeight: 700, fontSize: '18px', margin: '0 0 16px 0', color: '#333', paddingBottom: '8px', border: 'none', boxShadow: 'none' }}>BOOKED SERVICES SUMMARY</h3>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', pageBreakInside: 'auto' }}>
              <thead>
                <tr style={{ background: '#FF385C', color: '#fff' }}>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Service Type</th>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Date</th>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Vendor/ID</th>
                  <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(data?.itinerary) && data.itinerary.length > 0 ? (
                  data.itinerary.map((day, idx) => (
                    day.activities && day.activities.map((act, j) => (
                      <tr key={idx + '-' + j} style={{ background: idx % 2 === 0 ? '#fff' : '#f8f9fa', pageBreakInside: 'avoid' }}>
                        <td style={{ padding: '12px', color: '#333', fontWeight: 500, wordWrap: 'break-word', overflowWrap: 'break-word', hyphens: 'auto', lineHeight: '1.6', verticalAlign: 'top' }}>{act.activity || act.type || 'Activity'}</td>
                        <td style={{ padding: '12px', color: '#666', wordWrap: 'break-word', overflowWrap: 'break-word', lineHeight: '1.6', verticalAlign: 'top' }}>{day.title || `Day ${day.day_number || idx + 1}`}</td>
                        <td style={{ padding: '12px', color: '#666', wordWrap: 'break-word', overflowWrap: 'break-word', lineHeight: '1.6', verticalAlign: 'top' }}>{act.location || act.metadata?.vendor || '-'}</td>
                        <td style={{ padding: '12px', whiteSpace: 'nowrap', verticalAlign: 'top' }}>
                          <span style={{ 
                            background: act.metadata?.booking_required ? '#28a745' : '#ffc107', 
                            color: '#fff', 
                            padding: '4px 10px', 
                            borderRadius: '12px', 
                            fontSize: '11px', 
                            fontWeight: 600,
                            textTransform: 'uppercase',
                            display: 'inline-block'
                          }}>
                            {act.metadata?.booking_required ? 'Booked' : 'Planned'}
                          </span>
                        </td>
                      </tr>
                    ))
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" style={{ padding: '20px', textAlign: 'center', color: '#999', fontStyle: 'italic' }}>No services booked yet</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div style={{ position: 'absolute', bottom: '30px', left: '50px', right: '50px', textAlign: 'center', fontSize: '11px', color: '#999', paddingTop: '15px', border: 'none', boxShadow: 'none' }}>
            <div style={{ marginBottom: '4px', border: 'none', boxShadow: 'none' }}>
              <span style={{ fontWeight: 600, color: '#666', border: 'none', boxShadow: 'none' }}>INFO@TRAVELOURE.COM</span>
              <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
              <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>Page 1 of {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3}</span>
              <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
              <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>WWW.TRAVELOURE-BETA.COM</span>
            </div>
          </div>
        </div>
        {/* Page 2: Daily Itinerary */}
        {Array.isArray(data?.itinerary) && data.itinerary.map((day, idx) => (
          <div key={idx} className="pdf-page" style={{ width: '794px', minHeight: '1123px', background: '#fff', padding: '50px', boxSizing: 'border-box', fontFamily: 'Arial, sans-serif' }}>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px', paddingBottom: '15px', border: 'none', boxShadow: 'none' }}>
              <img src="/Main-logo.png" alt="TRAVELOURE Logo" style={{ width: 120, height: 'auto', border: 'none', boxShadow: 'none' }} />
              <div style={{ fontSize: '11px', color: '#999', border: 'none', boxShadow: 'none' }}>Page {idx + 2} of {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3}</div>
            </div>

            {/* Day Header */}
            <div style={{ marginBottom: '25px', border: 'none', boxShadow: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px', border: 'none', boxShadow: 'none' }}>
                <div style={{ background: '#FF385C', color: '#fff', width: '50px', height: '50px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '18px', border: 'none', boxShadow: 'none' }}>
                  {day.day_number || idx + 1}
                </div>
                <div style={{ border: 'none', boxShadow: 'none' }}>
                  <h2 style={{ fontWeight: 700, fontSize: '26px', margin: '0 0 4px 0', color: '#333', border: 'none', boxShadow: 'none' }}>{day.title || `Day ${day.day_number || idx + 1}`}</h2>
                  {day.description && (
                    <div style={{ fontSize: '14px', color: '#666', fontStyle: 'italic', border: 'none', boxShadow: 'none' }}>{day.description}</div>
                  )}
                </div>
              </div>
            </div>

            {/* Activities Table */}
            {day.activities && day.activities.length > 0 ? (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', marginBottom: '30px', pageBreakInside: 'auto' }}>
                <thead>
                  <tr style={{ background: '#FF385C', color: '#fff' }}>
                    <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Time</th>
                    <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Activity</th>
                    <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Location</th>
                    <th style={{ padding: '12px', textAlign: 'left', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {day.activities.map((act, j) => (
                    <tr key={j} style={{ background: j % 2 === 0 ? '#fff' : '#f8f9fa', pageBreakInside: 'avoid' }}>
                      <td style={{ padding: '12px', color: '#333', fontWeight: 600, fontSize: '12px', whiteSpace: 'nowrap', verticalAlign: 'top' }}>{act.time || '-'}</td>
                      <td style={{ padding: '12px', color: '#333', fontWeight: 500, wordWrap: 'break-word', overflowWrap: 'break-word', lineHeight: '1.6', verticalAlign: 'top' }}>{act.activity || '-'}</td>
                      <td style={{ padding: '12px', color: '#666', wordWrap: 'break-word', overflowWrap: 'break-word', lineHeight: '1.6', verticalAlign: 'top' }}>{act.location || '-'}</td>
                      <td style={{ padding: '12px', color: '#666', fontSize: '12px', wordWrap: 'break-word', overflowWrap: 'break-word', lineHeight: '1.6', verticalAlign: 'top' }}>{act.notes || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div style={{ padding: '40px', textAlign: 'center', color: '#999', fontStyle: 'italic', background: '#f8f9fa', borderRadius: '8px', marginBottom: '30px', border: 'none', boxShadow: 'none' }}>
                No activities scheduled for this day
              </div>
            )}

            {/* Footer */}
            <div style={{ position: 'absolute', bottom: '30px', left: '50px', right: '50px', textAlign: 'center', fontSize: '11px', color: '#999', paddingTop: '15px', border: 'none', boxShadow: 'none' }}>
              <div style={{ border: 'none', boxShadow: 'none' }}>
                <span style={{ fontWeight: 600, color: '#666', border: 'none', boxShadow: 'none' }}>INFO@TRAVELOURE.COM</span>
                <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
                <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>Page {idx + 2} of {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3}</span>
                <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
                <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>WWW.TRAVELOURE-BETA.COM</span>
              </div>
            </div>
          </div>
        ))}
        {/* Page: What's Included / Not Included */}
        <div className="pdf-page" style={{ width: '794px', minHeight: '1123px', background: '#fff', padding: '50px', boxSizing: 'border-box', fontFamily: 'Arial, sans-serif' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px', paddingBottom: '15px', border: 'none', boxShadow: 'none' }}>
            <img src="/Main-logo.png" alt="TRAVELOURE Logo" style={{ width: 120, height: 'auto', border: 'none', boxShadow: 'none' }} />
            <div style={{ fontSize: '11px', color: '#999', border: 'none', boxShadow: 'none' }}>Page {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3} of {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3}</div>
          </div>

          <h2 style={{ fontWeight: 700, fontSize: '28px', margin: '0 0 30px 0', color: '#333', textAlign: 'center', border: 'none', boxShadow: 'none' }}>What's Included / Not Included</h2>
          
          <div style={{ display: 'flex', gap: '24px', marginBottom: '30px', border: 'none', boxShadow: 'none' }}>
            {/* Included Section */}
            <div style={{ flex: 1, background: '#f0f9f4', borderRadius: '12px', padding: '24px', border: 'none', boxShadow: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', border: 'none', boxShadow: 'none' }}>
                <div style={{ width: '40px', height: '40px', background: '#58AC00', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', fontWeight: 700, border: 'none', boxShadow: 'none' }}>✓</div>
                <h3 style={{ color: '#58AC00', fontWeight: 700, fontSize: '20px', margin: 0, border: 'none', boxShadow: 'none' }}>Included</h3>
              </div>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, border: 'none', boxShadow: 'none' }}>
                {Array.isArray(data?.inclusive) && data.inclusive.length > 0 ? (
                  data.inclusive.map((item, i) => (
                    <li key={i} style={{ marginBottom: '12px', paddingLeft: '24px', position: 'relative', fontSize: '14px', color: '#333', lineHeight: '1.6', border: 'none', boxShadow: 'none' }}>
                      <span style={{ position: 'absolute', left: 0, top: '6px', width: '8px', height: '8px', background: '#58AC00', borderRadius: '50%', border: 'none', boxShadow: 'none' }}></span>
                      {item}
                    </li>
                  ))
                ) : (
                  <li style={{ color: '#999', fontStyle: 'italic', fontSize: '14px', border: 'none', boxShadow: 'none' }}>No items specified</li>
                )}
              </ul>
            </div>

            {/* Not Included Section */}
            <div style={{ flex: 1, background: '#fff5f5', borderRadius: '12px', padding: '24px', border: 'none', boxShadow: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', border: 'none', boxShadow: 'none' }}>
                <div style={{ width: '40px', height: '40px', background: '#FF385C', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', fontWeight: 700, border: 'none', boxShadow: 'none' }}>✗</div>
                <h3 style={{ color: '#FF385C', fontWeight: 700, fontSize: '20px', margin: 0, border: 'none', boxShadow: 'none' }}>Not Included</h3>
              </div>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, border: 'none', boxShadow: 'none' }}>
                {Array.isArray(data?.exclusive) && data.exclusive.length > 0 ? (
                  data.exclusive.map((item, i) => (
                    <li key={i} style={{ marginBottom: '12px', paddingLeft: '24px', position: 'relative', fontSize: '14px', color: '#333', lineHeight: '1.6', border: 'none', boxShadow: 'none' }}>
                      <span style={{ position: 'absolute', left: 0, top: '6px', width: '8px', height: '8px', background: '#FF385C', borderRadius: '50%', border: 'none', boxShadow: 'none' }}></span>
                      {item}
                    </li>
                  ))
                ) : (
                  <li style={{ color: '#999', fontStyle: 'italic', fontSize: '14px', border: 'none', boxShadow: 'none' }}>No items specified</li>
                )}
              </ul>
            </div>
          </div>

          {/* Footer */}
          <div style={{ position: 'absolute', bottom: '30px', left: '50px', right: '50px', textAlign: 'center', fontSize: '11px', color: '#999', paddingTop: '15px', border: 'none', boxShadow: 'none' }}>
            <div style={{ border: 'none', boxShadow: 'none' }}>
              <span style={{ fontWeight: 600, color: '#666', border: 'none', boxShadow: 'none' }}>INFO@TRAVELOURE.COM</span>
              <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
              <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>Page {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3} of {Array.isArray(data?.itinerary) ? data.itinerary.length + 2 : 3}</span>
              <span style={{ margin: '0 8px', color: '#ddd', border: 'none', boxShadow: 'none' }}>|</span>
              <span style={{ color: '#666', border: 'none', boxShadow: 'none' }}>WWW.TRAVELOURE-BETA.COM</span>
            </div>
          </div>
        </div>
      </div>
    </>
  )
} 