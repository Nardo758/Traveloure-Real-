"use client"

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from "../components/ui/carousel"
import { Card, CardContent } from "../components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar"
import { Star } from "lucide-react"
import { useState } from "react"

const testimonials = [
  {
    id: 1,
    content:
      "The travel expert recommendations made our trip to Portugal truly special. We discovered places we would have never found on our own!",
    author: "Sarah Johnson",
    location: "New York, USA",
    avatar: "/placeholder.svg?height=50&width=50",
    rating: 4,
  },
  {
    id: 2,
    content:
      "The AI itinerary planning saved me hours of research. It perfectly balanced tourist spots with authentic local experiences.",
    author: "David Chen",
    location: "Toronto, Canada",
    avatar: "/placeholder.svg?height=50&width=50",
    rating: 5,
  },
  {
    id: 3,
    content:
      "As someone who was unsure where to go, the 'Help Me Decide' feature was a game-changer. I ended up with the perfect vacation!",
    author: "Maria Rodriguez",
    location: "Madrid, Spain",
    avatar: "/placeholder.svg?height=50&width=50",
    rating: 4.5,
  },
  {
    id: 4,
    content:
      "The support team helped me even while I was on my trip. That kind of service is rare. Thank you!",
    author: "Liam O'Brien",
    location: "Dublin, Ireland",
    avatar: "/placeholder.svg?height=50&width=50",
    rating: 4,
  },
  {
    id: 5,
    content:
      "Affordable, smart, and so easy to use. I don't think I'll ever plan a trip manually again!",
    author: "Akira Tanaka",
    location: "Tokyo, Japan",
    avatar: "/placeholder.svg?height=50&width=50",
    rating: 5,
  },
]

export default function TestimonialSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  return (
    <div className="bg-[#F5F0E84D]">
    <div className="container mx-auto px-4 ">
    <section className="relative  py-20 overflow-hidden">
      <div className=" mb-10">
        <h2 className="text-3xl md:text-4xl font-bold mb-2">
          Customer <span className="text-green-600">Success</span> Stories
        </h2>
        <p className="text-muted-foreground ">
          Hear from travelers who have transformed their travel experiences with our platform.
        </p>
      </div>

      <div className="relative ">
        <Carousel
          opts={{ align: "center" }}
          className="w-full z-10"
        >
          <CarouselContent className="-ml-4">
            {testimonials.map((testimonial, index) => (
              <CarouselItem
                key={testimonial.id}
                className="pl-4 basis-full md:basis-1/3 transition-all duration-300"
              >
                <Card className="border  rounded-xl bg-white h-full">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-3">
                      {Array(Math.floor(testimonial.rating)).fill(0).map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                      ))}
                      {testimonial.rating % 1 !== 0 && (
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400 opacity-50" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-6">
                      {testimonial.content}
                    </p>
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={testimonial.avatar} alt={testimonial.author} />
                        <AvatarFallback>
                          {testimonial.author[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="text-left">
                        <p className="font-medium text-sm">{testimonial.author}</p>
                        <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>

          {/* Carousel Navigation Dots */}
          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full ${
                  index === currentSlide ? "bg-green-400" : "bg-green-200"
                }`}
              />
            ))}
          </div>

          {/* Navigation Arrows */}
          <div className="flex justify-center mt-6 md:absolute md:top-1 md:left-[90%] md:-translate-x-full md:-mt-8 md:space-x-3 md:z-10">
            <CarouselPrevious className="rounded-[12px]  border border-[#FF385C] text-pink-500 hover:bg-[#FF385C] w-11 h-11" />
            <CarouselNext className="rounded-[12px] bg-[#FF385C] text-white hover:bg-[#FF385C] w-11 h-11" />
          </div>
        </Carousel>

      
      </div>
    </section>
    </div>
    </div>
  )
}
