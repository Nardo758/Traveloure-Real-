"use client"

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { CheckCircle, CreditCard, Calendar } from 'lucide-react'
import { Button } from './ui/button'

export default function PaymentSuccessModal({ 
  isOpen, 
  onClose, 
  itineraryTitle,
  expertName,
  contractId,
  paymentAmount
}) {
  const [isLoading, setIsLoading] = useState(false)

  const handleClose = () => {
    if (!isLoading) {
      onClose()
    }
  }

  const handleContinue = () => {
    setIsLoading(true)
    // Add any additional logic here if needed
    setTimeout(() => {
      setIsLoading(false)
      onClose()
    }, 500)
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader className="text-center">
          {/* Success Icon */}
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <div className="absolute -inset-2 border-2 border-green-200 border-dashed rounded-full"></div>
            </div>
          </div>
          
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
            Payment Successful!
          </DialogTitle>
          
          <p className="text-gray-600 text-base">
            Your payment has been processed successfully and your itinerary has been confirmed.
          </p>
        </DialogHeader>

        {/* Details Section */}
        <div className="mt-6 space-y-4">
          {itineraryTitle && (
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Itinerary</span>
              </div>
              <p className="text-gray-900 font-medium">{itineraryTitle}</p>
            </div>
          )}

          {expertName && (
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Local Expert</span>
              </div>
              <p className="text-gray-900 font-medium">{expertName}</p>
            </div>
          )}

          {paymentAmount && (
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Amount Paid</span>
              </div>
              <p className="text-gray-900 font-medium">${paymentAmount}</p>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <Button
            onClick={handleContinue}
            disabled={isLoading}
            className="flex-1 bg-[#FF385C] hover:bg-[#FF385C] text-white"
          >
            {isLoading ? 'Processing...' : 'Continue'}
          </Button>
        </div>

        {/* Additional Info */}
        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">
            You will receive a confirmation email shortly with all the details.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}

















