"use client"

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { Button } from './ui/button'
import { Textarea } from './ui/textarea'
import { Star, CheckCircle } from 'lucide-react'
import { toast } from 'sonner'

export default function ContractApprovedModal({
  isOpen,
  onClose,
  expertName,
  itineraryTitle,
  onSubmitFeedback
}) {
  const [rating, setRating] = useState(0)
  const [feedback, setFeedback] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleStarClick = (starRating) => {
    setRating(starRating)
  }

  const handleSubmitFeedback = async () => {
    if (rating === 0) {
      toast.error('Please select a rating')
      return
    }

    setIsSubmitting(true)
    try {
      if (onSubmitFeedback) {
        await onSubmitFeedback({
          rating,
          feedback: feedback.trim()
        })
      }
      toast.success('Feedback submitted successfully!')
      handleClose()
    } catch (error) {
      console.error('Error submitting feedback:', error)
      toast.error('Failed to submit feedback. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSkip = () => {
    handleClose()
  }

  const handleClose = () => {
    setRating(0)
    setFeedback('')
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader className="text-center">
          {/* Success Icon */}
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <div className="absolute -inset-2 border-2 border-green-200 border-dashed rounded-full"></div>
            </div>
          </div>
          
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
            Contract Approved Successfully!
          </DialogTitle>
          
          <p className="text-gray-600 text-base">
            Your {itineraryTitle || 'adventure itinerary'} has been confirmed and your contract with the expert is now finalized.
          </p>
        </DialogHeader>

        {/* Feedback Section */}
        <div className="mt-6">
          <h3 className="font-semibold text-gray-900 mb-3">
            How was your experience with {expertName || 'the expert'}?
          </h3>
          
          {/* Star Rating */}
          <div className="flex gap-1 mb-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => handleStarClick(star)}
                className="focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 rounded"
                disabled={isSubmitting}
              >
                <Star
                  className={`w-6 h-6 ${
                    star <= rating
                      ? 'text-pink-500 fill-pink-500'
                      : 'text-gray-300'
                  }`}
                />
              </button>
            ))}
          </div>
          
          {/* Feedback Text Area */}
          <Textarea
            placeholder="Share Your Feedback Here"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            className="min-h-[100px] resize-none border-gray-300 focus:border-pink-500 focus:ring-pink-500"
            disabled={isSubmitting}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mt-6">
          <Button
            variant="outline"
            onClick={handleSkip}
            disabled={isSubmitting}
            className="flex-1 border-pink-500 text-pink-500 hover:bg-pink-50"
          >
            Skip for Now
          </Button>
          <Button
            onClick={handleSubmitFeedback}
            disabled={isSubmitting || rating === 0}
            className="flex-1 bg-pink-500 hover:bg-pink-600 text-white"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}


