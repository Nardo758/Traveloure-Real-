"use client";


import { Provider } from "react-redux";
import { store } from "../../lib/store"; // ✅ make sure this path is correct
import Providers from "../../app/Provider"; // ✅ wraps Header/Footer conditionally

export default function ReduxProvider({ children }) {
  return (
    <Provider store={store}>
      <Providers>{children}</Providers>
    </Provider>
  );
}
