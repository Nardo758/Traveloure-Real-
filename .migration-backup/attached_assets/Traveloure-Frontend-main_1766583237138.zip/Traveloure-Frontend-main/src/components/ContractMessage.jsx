"use client"

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { MapPin, Paperclip, CheckCircle, XCircle, CreditCard } from 'lucide-react'
import { Button } from './ui/button'
import { toast } from 'sonner'

export default function ContractMessage({ contract, onAccept, onReject, onPay, isOwnMessage = false }) {
  const [isLoading, setIsLoading] = useState(false)

  const { data: session } = useSession()
  
  const shouldShowAcceptedStatus = contract.status === 'accepted' || contract.is_accepted === true
  const shouldShowRejectedStatus = contract.status === 'rejected'
  
  // Show buttons when contract is pending
  const isContractPending = contract.status === 'pending' || !contract.status
  const shouldShowButtons = isContractPending && !isOwnMessage
  
  // Test props
  
  

  const handleAccept = async () => {
    if (onAccept) {
      setIsLoading(true)
      try {
        await onAccept(contract.id)
        // No toast - status will be shown in the message box
      } catch (error) {
        console.error("🔌 ContractMessage: Failed to accept contract:", error)
        toast.error('Failed to accept contract')
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handleReject = async () => {
    if (onReject) {
      setIsLoading(true)
      try {
        await onReject(contract.id)
        // No toast - status will be shown in the message box
      } catch (error) {
        console.error("🔌 ContractMessage: Failed to reject contract:", error)
        toast.error('Failed to reject contract')
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handlePay = async () => {
    console.log('🔌 ContractMessage - Payment attempt:', {
      contractId: contract.id,
      payment_url: contract.payment_url,
      contract: contract
    })
    
    // Check if contract has a payment URL
    if (contract.payment_url) {
      console.log('🔌 ContractMessage - Opening payment URL:', contract.payment_url)
      // Redirect to the payment URL
      window.open(contract.payment_url, '_blank')
    } else if (onPay) {
      console.log('🔌 ContractMessage - No payment URL, using onPay callback')
      // Fallback to onPay callback if no payment URL
      setIsLoading(true)
      try {
        await onPay(contract.id)
      } catch (error) {
        toast.error('Failed to process payment')
      } finally {
        setIsLoading(false)
      }
    } else {
      console.log('🔌 ContractMessage - No payment URL or onPay callback available')
      toast.error('Payment URL not available. Please accept the contract first.')
    }
  }

  // Format timestamp
  const formatTimeAgo = (timestamp) => {
    if (!timestamp) return 'Just now'
    
    try {
      const now = new Date()
      const contractTime = new Date(timestamp)
      
      // Check if the date is valid
      if (isNaN(contractTime.getTime())) {
        return 'Just now'
      }
      
      const diffInMinutes = Math.floor((now - contractTime) / (1000 * 60))
      
      if (diffInMinutes < 1) return 'Just now'
      if (diffInMinutes < 60) return `${diffInMinutes} Minute${diffInMinutes > 1 ? 's' : ''} Ago`
      
      const diffInHours = Math.floor(diffInMinutes / 60)
      if (diffInHours < 24) return `${diffInHours} Hour${diffInHours > 1 ? 's' : ''} Ago`
      
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays} Day${diffInDays > 1 ? 's' : ''} Ago`
    } catch (error) {
      console.error('Error formatting timestamp:', error)
      return 'Just now'
    }
  }

  // Debug logging for positioning and payment URL
 


  return (
    <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className="flex items-start gap-3 max-w-sm">
        {/* Profile Picture */}
        {!isOwnMessage && (
          <div className="w-10 h-10 rounded-full bg-gray-300 flex-shrink-0 mt-1">
            <img 
              src={contract.sender_image || "/dummypic.png"} 
              alt="Profile" 
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        )}
        
        {/* Contract Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 relative">
          {/* Header */}
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 text-sm">
                {contract.title}
              </h3>
              <div className="flex items-center gap-1 mt-1">
                <MapPin className="w-3 h-3 text-gray-500" />
                <span className="text-xs text-gray-500">{contract.trip_to}</span>
              </div>
            </div>
          </div>
          
          {/* Divider */}
          <div className="border-t border-gray-100 mb-3"></div>
          
          {/* Description */}
          <p className="text-sm text-gray-600 mb-3 leading-relaxed">
            {contract.description}
          </p>
          
          {/* File Attachment */}
          {contract.hasAttachment && contract.attachmentName && (
            <div className="mb-3 p-2 bg-gray-50 rounded border">
              <div className="flex items-center gap-2">
                <Paperclip className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">{contract.attachmentName}</span>
              </div>
            </div>
          )}
          
          {/* Proposal Amount */}
          <div className="mb-4">
            <p className="text-sm font-semibold text-gray-900 mb-1">
              Proposal Amount:
            </p>
            <p className="text-lg font-bold text-gray-900">
              ${(() => {
                try {
                  const amount = parseFloat(contract.amount)
                  if (isNaN(amount)) {
                    return '0.00'
                  }
                  return amount.toFixed(2)
                } catch (error) {
                  console.error('Error parsing amount:', error)
                  return '0.00'
                }
              })()}
            </p>
          </div>
          
          {/* Action Buttons or Status */}
          <>
            {/* Show Accept/Reject buttons if contract is pending and user is the receiver */}
            {/* Buttons only show when:
                1. Contract has no explicit status (pending)
                2. User is NOT the sender (i.e., is the receiver)
                
                Note: is_accepted: false from API might mean "pending", not "rejected"
            */}
            {shouldShowButtons && (
              <div className="flex gap-2">
                <Button
                  onClick={handleReject}
                  disabled={isLoading}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
                >
                  Reject
                </Button>
                <Button
                  onClick={handleAccept}
                  disabled={isLoading}
                  size="sm"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  Accept
                </Button>
              </div>
            )}
          
            {shouldShowAcceptedStatus && (() => {
              const userRoles = session?.user?.roles || session?.backendData?.roles || []
              const isLocalExpert = userRoles.includes('local_expert')
              
              // Special case: User/Traveler should see payment button for ANY accepted contract
              // This means: User is not local expert (regardless of who sent the contract)
              if (!isLocalExpert) {
                return (
                  <div className="flex justify-end">
                    <Button
                      onClick={handlePay}
                      disabled={isLoading}
                      size="sm"
                      className="bg-gradient-to-r from-[#F30131] to-[#BE35EB] hover:opacity-90 text-white"
                    >
                      Pay ${(() => {
                        try {
                          const amount = parseFloat(contract.amount)
                          if (isNaN(amount)) {
                            return '0.00'
                          }
                          return amount.toFixed(2)
                        } catch (error) {
                          return '0.00'
                        }
                      })()} to Confirm
                    </Button>
                  </div>
                )
              }
              
              // For all other cases (Local Expert), show the green status box
              return (
                <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-800">
                      {(() => {
                        if (isLocalExpert) {
                          // Local Expert: Show appropriate message
                          return isOwnMessage ? 'You have accepted the contract' : 'Traveler has accepted your contract'
                        } else {
                          // User/Traveler: Show "You have accepted" message (when they sent the contract)
                          return 'You have accepted the contract'
                        }
                      })()}
                    </p>
                  </div>
                </div>
              )
            })()}
            
            {/* Show Rejected status to both sender and receiver - only if status exists */}
            {shouldShowRejectedStatus && (
              <div className="flex-1 p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-600" />
                  <p className="text-sm font-medium text-red-800">
                    {(() => {
                      const userRoles = session?.user?.roles || session?.backendData?.roles || []
                      const isLocalExpert = userRoles.includes('local_expert')
                      
                      if (isLocalExpert) {
                        return isOwnMessage ? 'You have rejected the contract' : 'Local Expert has rejected your contract'
                      } else {
                        return isOwnMessage ? 'You have rejected the contract' : 'Traveler has rejected your contract'
                      }
                    })()}
                  </p>
                </div>
              </div>
            )}
          </>
        </div>
      </div>
      
      {/* Timestamp */}
      <div className={`text-xs text-gray-400 mt-1 ${isOwnMessage ? 'text-right' : 'text-left'}`}>
        {formatTimeAgo(contract.created_at)}
      </div>
    </div>
  )
}
