"use client"

export function StickerPicker({ 
  onStickerSelect, 
  onClose 
}) {
  // Sticker data
  const stickers = [
    '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
    '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
    '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
    '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
    '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
    '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗',
    '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😯', '😦', '😧',
    '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐', '🥴', '🤢',
    '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '💩', '🤡', '👹',
    '👺', '👻', '👽', '👾', '🤖', '😺', '😸', '😹', '😻', '😼'
  ]

  const handleStickerClick = (sticker) => {
    onStickerSelect(sticker)
    onClose()
  }

  return (
    <div className="mt-3 p-3 bg-white border border-gray-200 rounded-lg shadow-lg">
      <div className="grid grid-cols-10 gap-2 max-h-32 overflow-y-auto">
        {stickers.map((sticker, index) => (
          <button
            key={index}
            onClick={() => handleStickerClick(sticker)}
            className="p-2 hover:bg-gray-100 rounded-lg text-lg transition-colors"
          >
            {sticker}
          </button>
        ))}
      </div>
    </div>
  )
}
