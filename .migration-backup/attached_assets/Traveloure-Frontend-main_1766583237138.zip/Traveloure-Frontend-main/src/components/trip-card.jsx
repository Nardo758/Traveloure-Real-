import { Card, CardContent } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Badge } from "../components/ui/badge"
import { Switch } from "../components/ui/switch"
import { Calendar } from "lucide-react"
import { useRouter } from "next/navigation"

export function TripCard({ title, image, status, startDate, endDate, notificationsEnabled, tripData }) {
  const router = useRouter();
  const handleViewItinerary = () => {
    if (tripData) {
      localStorage.setItem("selectedTrip", JSON.stringify(tripData));
      // Navigate to AI optimization with trip ID in the URL
      router.push(`/ai-optimization/${tripData.id || tripData.trip}`);
    } else {
      router.push('/ai-optimization');
    }
  };
  return (
    <Card className="overflow-hidden bg-white border border-gray-200">
      <div className="aspect-video relative">
        <img src={image || "/articleimage.png"} alt={title} className="w-full h-full object-cover" />
      </div>
      <CardContent className="p-3 lg:p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm lg:text-base font-semibold text-gray-900">{title}</h3>
          <Badge
            variant={status === "Current" ? "default" : "secondary"}
            className={
              status === "Current"
                ? "bg-blue-500 text-white hover:bg-blue-600 text-xs"
                : "bg-orange-500 text-white hover:bg-orange-600 text-xs"
            }
          >
            {status}
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-xs lg:text-sm text-gray-500">
          <Calendar className="h-3 w-3 lg:h-4 lg:w-4" />
          <span className="truncate">
            {startDate} - {endDate}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Switch checked={notificationsEnabled} />
            <span className="text-xs lg:text-sm text-gray-600">
              Notifications {notificationsEnabled ? "Enabled" : "Disabled"}
            </span>
          </div>
        </div>
        <Button className="w-full bg-pink-500 hover:bg-pink-600 text-white text-sm" onClick={handleViewItinerary}>View Itinerary</Button>
      </CardContent>
    </Card>
  )
}
