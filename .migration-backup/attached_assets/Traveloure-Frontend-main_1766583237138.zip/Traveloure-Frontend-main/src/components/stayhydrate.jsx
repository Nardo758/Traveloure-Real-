"use client";
import { useEffect, useState } from "react";


export default function SafeHydrate({ children }) {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) return null;

  return <>{children}</>;
}
