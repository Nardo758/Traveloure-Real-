"use client";

import { Card, CardContent } from "../components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "../components/ui/carousel";
import { useState, useEffect } from "react";

const ImpactSection = () => {
  const [api, setApi] = useState(null);
  const [current, setCurrent] = useState(0);
  const [count, setCount] = useState(0);

  const stats = [
    {
      title: "8M+",
      subtitle: "Trips Planned",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "Join the millions who've used Wanderlog to seamlessly plan their journeys—whether it's a weekend getaway or a month-long adventure.",
    },
    {
      title: "500K+",
      subtitle: "Custom Itineraries Generated",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "Half a million unique, tailored itineraries built using real-time preferences and constraints—no two plans are the same.",
    },
    {
      title: "$500+",
      subtitle: "Saved on Multi-City Trips",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "All route optimization and bundled planning reduce spend dramatically, especially for longer or multi-destination travel.",
    },
    {
      title: "33K+",
      subtitle: "Reviews Received",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "With tens of thousands of 5-star reviews, our platform is trusted by travelers worldwide.",
    },
    {
      title: "200M+",
      subtitle: "Miles Traveled",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "Our users have collectively covered over 200 million miles, exploring the world one trip at a time.",
    },
    {
      title: "100K+",
      subtitle: "Destinations Explored",
      subtitle1: "Trusted by travellers worldwide.",
      description:
        "From iconic landmarks to hidden gems, our platform has guided travelers to over 100,000 unique destinations.",
    },
  ];

  useEffect(() => {
    if (!api) return;

    const updateState = () => {
      setCount(api.scrollSnapList().length);
      setCurrent(api.selectedScrollSnap());
    };

    api.on("select", updateState);
    api.on("reInit", updateState);
    updateState(); // initial

    return () => {
      api.off("select", updateState);
      api.off("reInit", updateState);
    };
  }, [api]);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto mb-10 px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-2">
          Our <span className="text-green-600">Impact</span> In Numbers
        </h2>
        <p className="text-gray-500">
          Plan your perfect trip with personalized suggestions, easy itineraries, and real-time travel tips.
        </p>
      </div>

      <div className="relative px-4 container mx-auto ">
        <Carousel setApi={setApi} opts={{ align: "start" }} className="w-full">
          <CarouselContent>
            {stats.map((stat, index) => (
              <CarouselItem key={index} className="pl-4 md:basis-1/2 lg:basis-1/4">
                <Card className="rounded-xl shadow-sm h-full">
                  <CardContent className="py-4 px-6">
                    <div className="flex flex-col">
                      <div className="border-l-4 border-[#101010] pl-4 mb-3">
                        <h3 className="text-[39px] font-extrabold leading-tight">{stat.title}</h3>
                        <h4 className="text-lg font-semibold text-gray-800">{stat.subtitle}</h4>
                      </div>
                      <p className="text-[#101010] text-sm mb-1">{stat.subtitle1}</p>
                      <p className="text-[#535556] text-sm">{stat.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>

        </Carousel>

        {/* Dots Indicator */}
        <div className="flex justify-center mt-8">
          {Array.from({ length: count }).map((_, index) => (
            <button
              key={index}
              onClick={() => api?.scrollTo(index)}
              className={`w-2 h-2 rounded-full mx-1 transition-colors duration-300 ${
                index === current ? "bg-green-500" : "bg-green-200"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImpactSection;
