"use client"

import { memo, useMemo } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import Image from "next/image"
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  FileText, 
  User, 
  HelpCircle, 
  MessageSquare,
  DollarSign,
  Settings,
  MessageSquareMore,
  Volume2,
  Users2,
  CalendarDays,
  Folder
} from "lucide-react"

// Local Expert menu items based on the image - ordered by red numbers
const localExpertMenuItems = [
  {
    title: "Dashboard",
    url: "/local-expert/dashboard",
    icon: LayoutDashboard
  },
  {
    title: "Bookings",
    url: "/local-expert/bookings",
    icon: FileText
  },
  {
    title: "Traveler Chats",
    url: "/local-expert/chats",
    icon: MessageSquare
  },
  {
    title: "All Services",
    url: "/local-expert/services",
    icon: Calendar
  },
  {
    title: "Earnings",
    url: "/local-expert/earnings",
    icon: DollarSign
  },
  {
    title: "Contract Categories",
    url: "/local-expert/contract-categories",
    icon: Folder
  },
  {
    title: "Business Profile",
    url: "/local-expert/business-profile",
    icon: User
  },
  {
    title: "FAQ's",
    url: "/local-expert/faqs",
    icon: Volume2
  }
]

// Memoized MenuItem component
const MenuItem = memo(({ item, isActive }) => {
  const IconComponent = item.icon
  
  return (
    <div className="relative px-2">
      {isActive && (
        <div className="absolute left-[-11px] top-1/2 -translate-y-1/2 h-10 w-1 rounded-r-full bg-[#FF385C] z-10" />
      )}
      <Link
        href={item.url}
        className={`flex items-center gap-3 px-3 py-2 ml-1 rounded-lg text-sm font-medium transition-colors relative z-20 ${
          isActive
            ? "bg-pink-50 text-pink-600"
            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        }`}
      >
        <IconComponent className="w-5 h-5" />
        <span>{item.title}</span>
      </Link>
    </div>
  )
})

MenuItem.displayName = 'MenuItem'

export const LocalExpertSidebar = memo(function LocalExpertSidebar({ isOpen, onClose }) {
  const pathname = usePathname()

  // Memoize the menu items rendering
  const renderedMenuItems = useMemo(() => {
    return localExpertMenuItems.map((item) => {
      // Check if current path starts with the menu item URL
      // This ensures sub-pages are also highlighted
      const isActive = pathname === item.url || pathname.startsWith(item.url + '/')
      return (
        <MenuItem
          key={item.title}
          item={item}
          isActive={isActive}
        />
      )
    })
  }, [pathname])

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
   
        
        {/* Navigation */}
        <div className="flex-1 p-3 pt-0 overflow-y-auto pr-0">
          <nav className="space-y-2 border-r border-gray-200">
            {renderedMenuItems}
          </nav>
        </div>
      </div>
    </>
  )
})

LocalExpertSidebar.displayName = 'LocalExpertSidebar' 