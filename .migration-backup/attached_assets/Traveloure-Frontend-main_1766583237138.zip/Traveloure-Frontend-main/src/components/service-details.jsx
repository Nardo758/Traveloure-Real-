"use client"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../ui/table"
import { Button } from "../../ui/button"
import { ArrowLeft } from "lucide-react"


export default function ServiceDetails({ service, onBack }) {
  if (!service) return null

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <Button variant="ghost" onClick={onBack} className="p-2">
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to services
        </Button>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h2 className="text-xl font-bold mb-4">{service.name} Details</h2>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Property</TableHead>
              <TableHead>Value</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Object.entries(service).map(([key, value]) => {
              // Skip image_url and complex objects
              if (key === "image_url" || typeof value === "object") return null

              return (
                <TableRow key={key}>
                  <TableCell className="font-medium capitalize">{key.replace(/_/g, " ")}</TableCell>
                  <TableCell>{String(value)}</TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>

        {service.description && (
          <div className="mt-4">
            <h3 className="font-semibold mb-2">Description</h3>
            <p className="text-gray-700">{service.description}</p>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <Button className="bg-[#FF385C] hover:bg-[#E02D50] text-white">Book {service.name}</Button>
        </div>
      </div>
    </div>
  )
}
