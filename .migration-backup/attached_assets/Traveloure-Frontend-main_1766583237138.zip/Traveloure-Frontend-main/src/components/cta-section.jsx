import Image from "next/image";
import { Button } from "./ui/button";
import { useRouter } from "next/navigation";

export default function CtaSection() {
  const router = useRouter();
  return (
    <div className="relative">
      <section className="container mx-auto relative py-16 overflow-hidden">
        <div className="relative rounded-[20px] overflow-hidden shadow-lg z-1">
          {/* Background image with dark overlay */}
          <div
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: "url('/ctasection-bg.png')",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          ></div>

          {/* Background “TRAVELTURE” image */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
            <Image
              src="/TRAVELTURE.png"
              alt="TRAVELTURE"
              layout="intrinsic"
              width={500}
              height={150}
              className="absolute bottom-[-2px] w-full"
            />
          </div>

          {/* Content */}
          <div className="relative z-10 text-white text-center px-6 py-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 max-w-4xl mx-auto leading-snug drop-shadow-md">
              Tired Of Complicated Travel Plans? Let AI Handle The Hard Part For You
            </h2>
            <p className="text-white/90 max-w-2xl mx-auto mb-8 drop-shadow-sm">
              From bookings to hidden gems — experience a new way to travel with our intelligent assistant.
            </p>
            <Button onClick={() => router.push("/Itinerary")} size="lg" className="bg-white text-[#FF385C]  hover:bg-[#FF385C] hover:text-[#fff] font-semibold">
              Create a New Trip
            </Button>
          </div>
        </div>
      </section>

      {/* Mountain Images */}
      <div className="absolute top-44 left-0 z-0 pointer-events-none">
      <Image
          src="/cloudicon-left.png"
          alt="cloudicon"
          width={100}
          height={150}
          className="w-[100px] md:w-[100px] h-auto"
        />
      </div>
      <div className="absolute top-5 right-6 z-0 pointer-events-none">
      <Image
          src="/cloudicon-right.png"
          alt="cloudicon"
          width={150}
          height={150}
          className="w-[150px] md:w-[150px] h-auto"
        />
      </div>











      <div className="absolute bottom-0 left-0 z-0 pointer-events-none">
        <Image
          src="/mountleft.png"
          alt="Left Mountain"
          width={458}
          height={200}
          className="w-[200px] md:w-[458px] h-auto"
        />
      </div>
      <div className="absolute bottom-0 right-0 z-0 pointer-events-none">
        <Image
          src="/mountright.png"
          alt="Right Mountain"
          width={458}
          height={200}
          className="w-[200px] md:w-[458px] h-auto"
        />
      </div>
    </div>
  );
}
