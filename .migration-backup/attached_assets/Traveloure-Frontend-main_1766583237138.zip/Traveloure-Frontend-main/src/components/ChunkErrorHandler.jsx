"use client"

import { useEffect } from "react"

export default function ChunkErrorHandler() {
  useEffect(() => {
    if (typeof window === "undefined") return

    let reloadTimeout = null

    const handleChunkError = (event) => {
      const error = event.error || event.reason
      const errorMessage = error?.message || ""
      const errorName = error?.name || ""

      // Check if it's a ChunkLoadError
      const isChunkError =
        errorMessage.includes("Loading chunk") ||
        errorMessage.includes("ChunkLoadError") ||
        errorMessage.includes("Failed to fetch dynamically imported module") ||
        errorName === "ChunkLoadError"

      if (isChunkError) {
        console.warn("ChunkLoadError detected, clearing cache and reloading...", error)

        // Prevent multiple reloads
        if (reloadTimeout) return

        // Clear all caches
        const clearCaches = async () => {
          try {
            // Clear service worker cache
            if ("serviceWorker" in navigator) {
              const registrations = await navigator.serviceWorker.getRegistrations()
              await Promise.all(
                registrations.map((registration) => registration.unregister())
              )
            }

            // Clear browser cache
            if ("caches" in window) {
              const cacheNames = await caches.keys()
              await Promise.all(cacheNames.map((name) => caches.delete(name)))
            }
          } catch (err) {
            console.warn("Error clearing caches:", err)
          }

          // Reload the page
          reloadTimeout = setTimeout(() => {
            window.location.reload()
          }, 500)
        }

        clearCaches()
      }
    }

    // Listen for unhandled errors and promise rejections
    window.addEventListener("error", handleChunkError, true)
    window.addEventListener("unhandledrejection", handleChunkError)

    return () => {
      if (reloadTimeout) {
        clearTimeout(reloadTimeout)
      }
      window.removeEventListener("error", handleChunkError, true)
      window.removeEventListener("unhandledrejection", handleChunkError)
    }
  }, [])

  return null
}

