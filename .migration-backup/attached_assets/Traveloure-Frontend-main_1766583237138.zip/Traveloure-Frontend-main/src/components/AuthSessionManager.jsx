"use client"

import { useEffect } from 'react'
import { useSession, signOut } from 'next-auth/react'
import { registerSignOut } from '../lib/authUtils'

/**
 * This component registers the NextAuth signOut function globally
 * so it can be called when token expiration is detected anywhere in the app
 */
export default function AuthSessionManager() {
  const { data: session, status } = useSession()

  useEffect(() => {
    // Register the NextAuth signOut function globally
    registerSignOut(signOut)
    
    console.log('🔒 AuthSessionManager: NextAuth signOut registered')
  }, [])

  // This component doesn't render anything
  return null
}












