"use client"

import { memo, useMemo, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  LayoutDashboard,
  StickyNote,
  Users,
  Volume2,
  Home,
  MessageCircle,
  DollarSign,
  Star,
  FileText,
  BarChart3,
  Calendar,
  Settings,
  CreditCard,
  Search,
  Briefcase,
} from "lucide-react"
import { BsAirplane } from "react-icons/bs";
// Regular user menu items
const userMenuItems = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    url: "/dashboard",
  },
  {
    title: "My Trips",
    icon: BsAirplane ,
    url: "/dashboard/all-trips",
  },
  {
    title: "Services",
    icon: Briefcase,
    url: "/dashboard/services",
  },
  {
    title: "Browse Expert",
    icon: Search,
    url: "/experts",
  },
  {
    title: "Help Me Decide",
    icon: Users,
    url: "/help-me-decide",
  },
  {
    title: "FAQ's",
    icon: Volume2,
    url: "/dashboard/faq",
  },
  {
    title: "Messages",
    icon: MessageCircle,
    url: "/dashboard/expert-chats",
  },
  {
    title: "Credits & Billing",
    icon: CreditCard,
    url: "/dashboard/credits-billing",
  },
  {
    title: "Settings",
    icon: Settings,
    url: "/dashboard/profile",
  },
]

// Service provider menu items
const serviceProviderMenuItems = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    url: "/service-provider-panel/dashboard",
  },
  {
    title: "All Services",
    icon: Calendar,
    url: "/service-provider-panel/services",
  },
  {
    title: "Earnings",
    icon: Users,
    url: "/service-provider-panel/earnings",
  },
  {
    title: "Bookings",
    icon: FileText,
    url: "/service-provider-panel/bookings",
  },
  
 
  {
    title: "Business Profile",
    icon: Users,
    url: "/service-provider-panel/profile",
  },
  {
    title: "FAQ's",
    icon: Volume2,
    url: "/service-provider-panel/faq",
  },
]

// Memoized MenuItem component
const MenuItem = memo(({ item, isActive }) => (
  <div className="relative">
    {isActive && (
      <div className="absolute left-[-11px] top-1/2 -translate-y-1/2 h-10 w-1 rounded-r-full bg-[#FF385C] z-10" />
    )}
    <Link
      href={item.url}
      className={`flex items-center gap-3 px-3 py-2 ml-1 rounded-lg text-sm font-medium transition-colors relative z-20 ${
        isActive
          ? "bg-pink-50 text-pink-600"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
      }`}
    >
      <item.icon className="h-4 w-4" />
      <span>{item.title}</span>
    </Link>
  </div>
))

MenuItem.displayName = 'MenuItem'

export const AppSidebar = memo(function AppSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const [showTooltip, setShowTooltip] = useState(false)
  
  // Determine which menu items to use based on current route
  const isServiceProvider = pathname.startsWith('/service-provider-panel')
  const menuItems = isServiceProvider ? serviceProviderMenuItems : userMenuItems
  
  // Memoize the menu items rendering
  const renderedMenuItems = useMemo(() => {
    return menuItems.map((item) => (
      <MenuItem
        key={item.title}
        item={item}
        isActive={pathname === item.url}
      />
    ))
  }, [pathname, menuItems])

  return (
    <div className="p-3 pl-3 h-full relative">
      {/* Home Icon with Tooltip - Only show for regular users, not service providers */}
      {!isServiceProvider && (
        <div className="absolute top-0 right-[-37px]">
          <div
            className="relative"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
          >
            <Home 
              onClick={() => router.push("/")} 
              className="h-9 w-9 text-gray-600 hover:text-gray-900 bg-white border shadow-sm border-gray-200 pr-[8px] p-[4px] pl-[8px] cursor-pointer transition-colors rounded-tr-[20px] rounded-br-[20px]"
              />
            
            {/* Tooltip */}
            {showTooltip && (
              <div className="absolute left-full ml-2 top-1/2 transform -translate-y-1/2 z-50">
                <div className="bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                  Home
                  {/* Tooltip arrow */}
                  <div className="absolute right-full top-1/2 transform -translate-y-1/2 w-0 h-0 border-l-0 border-r-4 border-t-2 border-b-2 border-transparent border-r-gray-900"></div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      
      <nav className="space-y-2">
        {renderedMenuItems}
      </nav>
    </div>
  )
})

AppSidebar.displayName = 'AppSidebar'
