import Image from "next/image"
import { Card } from "./ui/card"
import { Button } from "./ui/button"
import { TbContract } from "react-icons/tb"

// Static fallback data for missing API fields
const staticExpertData = {
  rating: "4.8/5.0",
  reviews: 650,
  languages: ["English", "French", "Spanish"],
  countries: ["Italy", "France", "Spain", "Britain"],
  specialization: "Specializing in Coastal Adventures and Hidden Gems",
  image: "/dealperson.png",
}

export const ExpertCard = ({ 
  expert, 
  idx, 
  isConnected, 
  onOpenChat, 
  onContractModal,
  getDisplayName,
  getExpertData 
}) => {
  const expertData = getExpertData(expert)

  return (
    <Card className="border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all p-5 flex flex-col">
      <div className="flex items-center gap-4 mb-3">
        <Image
          src={expertData.image}
          alt={getDisplayName(expert)}
          width={60}
          height={60}
          className="rounded-full object-cover"
        />
        <div className="text-left">
          <h3 className="font-semibold text-base">{getDisplayName(expert)}</h3>
          <p className="text-sm text-yellow-600">
            ⭐ {expertData.rating} ({expertData.reviews} Reviews)
          </p>
          <p className="text-sm text-[#FF385C] font-medium cursor-pointer mt-1">
            View Profile
          </p>
        </div>
      </div>

      <div className="text-sm text-muted-foreground space-y-1 mb-4">
        <p>📍 {expertData.countries.join(", ")}</p>
        <p>🗣️ {staticExpertData.languages.join(", ")}</p>
        <p>{expertData.specialization}</p>
        {expertData.preferredMonths && (
          <p className="text-xs text-blue-600">{expertData.preferredMonths}</p>
        )}
        {expert.about_me?.trim() && (
          <p className="text-xs text-gray-500 mt-2">{expert.about_me}</p>
        )}
        {expert.city && (
          <p className="text-xs text-gray-600">🏙️ {expert.city}</p>
        )}
        
      </div>

      <div className="flex justify-between gap-2 mt-auto">
        <Button
          variant="ghost"
          className="text-[#FF385C] w-1/2 relative"
          onClick={() => onOpenChat(expert)}
          disabled={!isConnected}
          title={!isConnected ? 'WebSocket not connected' : 'Send Message'}
        >
          <div className="flex items-center gap-1">
            <div className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            Send Message
          </div>
        </Button>
        <Button
          className="bg-[#FF385C] hover:bg-[#e23350] text-white w-1/2"
          onClick={(e) => {
            console.log('ExpertCard - Hire button clicked')
            console.log('ExpertCard - expert object:', expert)
            console.log('ExpertCard - event object:', e)
            onContractModal(expert)
          }}
        >
          Hire
        </Button>
      </div>
    </Card>
  )
}


