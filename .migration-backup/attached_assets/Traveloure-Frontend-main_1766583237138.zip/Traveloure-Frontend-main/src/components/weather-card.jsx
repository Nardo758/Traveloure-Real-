"use client"

import { useState, useEffect } from "react"
import { Sun } from "lucide-react"

export function WeatherCard() {
  const [weather, setWeather] = useState({
    temperature: "24° C",
    location: "New York, USA",
    condition: "Perfect Weather for Sight Seeing!"
  })
  const [loading, setLoading] = useState(true)
  const [showLocationInput, setShowLocationInput] = useState(false)
  const [manualLocation, setManualLocation] = useState("")

  useEffect(() => {
    // Get user's current location and fetch weather data
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude } = position.coords
            
            // Try to get location name using reverse geocoding
            let locationName = "Current Location"
            try {
              const geoResponse = await fetch(
                `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
              )
              if (geoResponse.ok) {
                const geoData = await geoResponse.json()
                locationName = `${geoData.city || geoData.locality || 'Current Location'}, ${geoData.countryName || 'Unknown'}`
              }
            } catch (geoError) {
              locationName = "Current Location"
            }
            
            // Fetch weather data using wttr.in (free, no API key needed)
            try {
              const response = await fetch(
                `https://wttr.in/${latitude},${longitude}?format=j1`
              )
              
              if (response.ok) {
                const data = await response.json()
                const current = data.current_condition[0]
                const temp = current.temp_C
                const weatherDesc = current.weatherDesc[0].value
                const humidity = current.humidity
                const windSpeed = current.windspeedKmph
                
                setWeather({
                  temperature: `${temp}° C`,
                  location: locationName,
                  condition: getWeatherConditionFromDescription(weatherDesc, temp),
                  humidity: `${humidity}%`,
                  windSpeed: `${windSpeed} km/h`
                })
              } else {
                // Fallback to mock weather data
                setWeather({
                  temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
                  location: locationName,
                  condition: "Perfect Weather for Sight Seeing!"
                })
              }
            } catch (apiError) {
              console.error("Error fetching weather from wttr.in:", apiError)
              // Fallback to mock weather data
              setWeather({
                temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
                location: locationName,
                condition: "Perfect Weather for Sight Seeing!"
              })
            }
          } catch (error) {
            console.error("Error fetching weather:", error)
            // Fallback to default values
            setWeather({
              temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
              location: "Current Location",
              condition: "Perfect Weather for Sight Seeing!"
            })
          } finally {
            setLoading(false)
          }
        },
        (error) => {
          console.error("Error getting location:", error)
          // Fallback to default values
          setWeather({
            temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
            location: "Current Location",
            condition: "Perfect Weather for Sight Seeing!"
          })
          setLoading(false)
        }
      )
    } else {
      // Fallback for browsers that don't support geolocation
      setWeather({
        temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
        location: "Current Location",
        condition: "Perfect Weather for Sight Seeing!"
      })
      setLoading(false)
    }
  }, [])

  const getWeatherConditionFromDescription = (weatherDesc, temp) => {
    // Add temperature-based recommendations to the weather description
    if (temp >= 20 && temp <= 30) {
      return `${weatherDesc} - Perfect Weather for Sight Seeing!`
    } else if (temp < 10) {
      return `${weatherDesc} - Bundle up for your adventure!`
    } else if (temp > 30) {
      return `${weatherDesc} - Stay hydrated and cool!`
    } else {
      return `${weatherDesc} - Great weather for exploring!`
    }
  }

  const getWeatherCondition = (weatherMain, temp) => {
    if (temp >= 20 && temp <= 30) {
      return "Perfect Weather for Sight Seeing!"
    } else if (temp < 10) {
      return "Bundle up for your adventure!"
    } else if (temp > 30) {
      return "Stay hydrated and cool!"
    } else {
      return "Great weather for exploring!"
    }
  }

  const handleManualLocationSubmit = async () => {
    if (manualLocation.trim()) {
      setLoading(true)
      
      try {
        // Fetch weather data for manual location using wttr.in (free, no API key needed)
        const response = await fetch(
          `https://wttr.in/${encodeURIComponent(manualLocation.trim())}?format=j1`
        )
        
        if (response.ok) {
          const data = await response.json()
          const current = data.current_condition[0]
          const temp = current.temp_C
          const weatherDesc = current.weatherDesc[0].value
          const humidity = current.humidity
          const windSpeed = current.windspeedKmph
          
          setWeather({
            temperature: `${temp}° C`,
            location: manualLocation.trim(),
            condition: getWeatherConditionFromDescription(weatherDesc, temp),
            humidity: `${humidity}%`,
            windSpeed: `${windSpeed} km/h`
          })
        } else {
          // Fallback to mock weather data
          setWeather({
            temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
            location: manualLocation.trim(),
            condition: "Perfect Weather for Sight Seeing!"
          })
        }
      } catch (error) {
        console.error("Error fetching weather for manual location:", error)
        // Fallback to mock weather data
        setWeather({
          temperature: `${Math.floor(Math.random() * 15) + 15}° C`,
          location: manualLocation.trim(),
          condition: "Perfect Weather for Sight Seeing!"
        })
      } finally {
        setLoading(false)
        setShowLocationInput(false)
        setManualLocation("")
      }
    }
  }

  if (loading) {
    return (
      <div 
        className="rounded-xl p-4 text-white relative overflow-hidden"
        style={{
          background: "linear-gradient(135deg, #F30131 0%, #BE35EB 100%)"
        }}
      >
        <div className="animate-pulse">
          <div className="h-6 bg-white/20 rounded mb-2"></div>
          <div className="h-4 bg-white/20 rounded mb-2"></div>
          <div className="h-4 bg-white/20 rounded"></div>
        </div>
      </div>
    )
  }

  return (
    <div 
      className="rounded-xl p-4 text-white relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #F30131 0%, #BE35EB 100%)"
      }}
    >
      {/* Sun icon and refresh button in top right */}
      <div className="absolute top-3 right-3 flex items-center gap-2">
        <button 
          onClick={() => window.location.reload()}
          className="text-white/70 hover:text-white transition-colors"
          title="Refresh weather"
        >
          <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
        <Sun className="h-6 w-6 text-yellow-300" />
      </div>
      
      {/* Temperature */}
      <div className="text-2xl font-bold mb-1">
        {weather.temperature}
      </div>
      
      {/* Location with edit button */}
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm">
          {weather.location}
        </div>
        <button 
          onClick={() => setShowLocationInput(!showLocationInput)}
          className="text-xs bg-white/20 hover:bg-white/30 rounded px-2 py-1 transition-colors"
        >
          Edit
        </button>
      </div>
      
      {/* Manual location input */}
      {showLocationInput && (
        <div className="mb-3 p-2 bg-white/10 rounded">
          <input
            type="text"
            value={manualLocation}
            onChange={(e) => setManualLocation(e.target.value)}
            placeholder="Enter your location..."
            className="w-full bg-white/20 text-white placeholder-white/70 rounded px-2 py-1 text-sm"
            onKeyPress={(e) => e.key === 'Enter' && handleManualLocationSubmit()}
          />
          <div className="flex gap-2 mt-2">
            <button 
              onClick={handleManualLocationSubmit}
              className="text-xs bg-white/20 hover:bg-white/30 rounded px-2 py-1 transition-colors"
            >
              Save
            </button>
            <button 
              onClick={() => {
                setShowLocationInput(false)
                setManualLocation("")
              }}
              className="text-xs bg-white/20 hover:bg-white/30 rounded px-2 py-1 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      {/* Divider line */}
      <div className="w-full h-px bg-white/30 mb-3"></div>
      
      {/* Weather condition */}
      <div className="text-sm font-medium mb-2">
        {weather.condition}
      </div>
      
      {/* Additional weather info */}
      {(weather.humidity || weather.windSpeed) && (
        <div className="text-xs space-y-1">
          {weather.humidity && (
            <div className="flex justify-between">
              <span>Humidity:</span>
              <span>{weather.humidity}</span>
            </div>
          )}
          {weather.windSpeed && (
            <div className="flex justify-between">
              <span>Wind:</span>
              <span>{weather.windSpeed}</span>
            </div>
          )}
        </div>
      )}
    </div>
  )
} 