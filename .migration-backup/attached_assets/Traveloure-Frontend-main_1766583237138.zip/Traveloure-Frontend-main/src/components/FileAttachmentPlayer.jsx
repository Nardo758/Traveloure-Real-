"use client"

import { Paperclip, FileText, FileImage, FileVideo, FileAudio, Download } from "lucide-react"

export function FileAttachmentPlayer({ 
  attachment, 
  isOutgoing 
}) {
  // Handle both API URLs and file objects
  const getFileUrl = () => {
    if (!attachment) {
      return null
    }
    
    if (typeof attachment === 'string') {
      return attachment.startsWith('http') 
        ? attachment 
        : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment}`
    } else if (attachment instanceof File || attachment instanceof Blob) {
      return URL.createObjectURL(attachment)
    } else {
      // Handle case where attachment is an object but not a File/Blob
      // Try to extract URL from the object
      if (attachment.url) {
        return attachment.url.startsWith('http') 
          ? attachment.url 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.url}`
      } else if (attachment.attachment) {
        return attachment.attachment.startsWith('http') 
          ? attachment.attachment 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.attachment}`
      }
      return null
    }
  }

  const fileUrl = getFileUrl()
  
  // Don't render if no valid URL
  if (!fileUrl) {
    return null
  }
  const fileName = typeof attachment === 'string' 
    ? attachment.split('/').pop() || 'Attachment'
    : attachment.name || 'Attachment'
  
  // Get file extension
  const fileExtension = fileName.split('.').pop()?.toLowerCase() || ''
  
  // Get file size if available
  const fileSize = typeof attachment === 'object' && attachment.size 
    ? formatFileSize(attachment.size)
    : null

  // Get appropriate icon based on file type
  const getFileIcon = () => {
    if (fileExtension.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)) {
      return <FileImage className="w-4 h-4" />
    } else if (fileExtension.match(/\.(mp4|avi|mov|wmv|flv|webm|mkv)$/i)) {
      return <FileVideo className="w-4 h-4" />
    } else if (fileExtension.match(/\.(mp3|wav|ogg|m4a|aac)$/i)) {
      return <FileAudio className="w-4 h-4" />
    } else if (fileExtension.match(/\.(pdf|doc|docx|txt|rtf)$/i)) {
      return <FileText className="w-4 h-4" />
    } else {
      return <Paperclip className="w-4 h-4" />
    }
  }

  // Get file type text
  const getFileTypeText = () => {
    if (fileExtension.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)) {
      return 'Image file'
    } else if (fileExtension.match(/\.(mp4|avi|mov|wmv|flv|webm|mkv)$/i)) {
      return 'Video file'
    } else if (fileExtension.match(/\.(mp3|wav|ogg|m4a|aac)$/i)) {
      return 'Audio file'
    } else if (fileExtension.match(/\.(pdf|doc|docx|txt|rtf)$/i)) {
      return 'Document file'
    } else {
      return 'File attachment'
    }
  }

  // Format file size
  function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <div className="mt-2">
      <div className={`flex items-center gap-3 p-3 rounded-lg border ${
        isOutgoing 
          ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-opacity-10 border-pink-200' 
          : 'bg-gray-50 border-gray-200'
      }`}>
        <div className={`p-2 rounded-lg ${
          isOutgoing 
            ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] text-white' 
            : 'bg-white text-gray-600 border border-gray-200'
        }`}>
          {getFileIcon()}
        </div>
        
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium ${
            isOutgoing ? 'text-white' : 'text-gray-900'
          }`}>
            {getFileTypeText()}
          </p>
          {fileSize && (
            <p className={`text-xs ${
              isOutgoing ? 'text-white opacity-80' : 'text-gray-500'
            }`}>
              {fileSize}
            </p>
          )}
        </div>
        
        <a 
          href={fileUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className={`p-1.5 rounded-md transition-colors ${
            isOutgoing 
              ? 'text-white hover:bg-white hover:text-[#F30131]' 
              : 'text-gray-500 hover:bg-gray-200'
          }`}
          title="Download file"
        >
          <Download className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  )
}
