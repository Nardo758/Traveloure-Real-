

export function ReminderItem({ title, description, time, onClick, ...props }) {
  return (
    <div
      className="flex justify-between items-start p-3 border-b border-gray-100 last:border-b-0 hover:bg-gray-50 transition cursor-pointer"
      onClick={onClick}
      {...props}
    >
      <div className="space-y-1">
        <h4 className="text-sm font-medium text-gray-900">{title}</h4>
        <p className="text-xs text-gray-500">{description}</p>
      </div>
      <span className="text-xs text-gray-400">{time}</span>
    </div>
  )
}
