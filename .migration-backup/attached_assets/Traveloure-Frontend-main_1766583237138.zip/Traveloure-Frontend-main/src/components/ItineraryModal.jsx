"use client"

import { useState, useRef } from "react"
import { Paperclip, X } from "lucide-react"
import { toast } from "sonner"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Label } from "./ui/label"

export default function ItineraryModal({ 
  isOpen, 
  onClose, 
  onSubmit,
  initialData = {
    title: "",
    description: "",
    location: ""
  }
}) {
  
  const [formData, setFormData] = useState(initialData)
  const [selectedFile, setSelectedFile] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const fileInputRef = useRef(null)

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      // Validate file type
      const allowedTypes = [
        'application/pdf',
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/msword', 
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ]
      
      if (!allowedTypes.includes(file.type)) {
        toast.error('File type not supported. Please upload PDF, Word document, or image files.')
        e.target.value = ''
        return
      }
      
      // Validate file size (50MB limit)
      if (file.size > 50 * 1024 * 1024) {
        toast.error('File size too large. Maximum 50MB allowed.')
        e.target.value = ''
        return
      }
      
      setSelectedFile(file)
      toast.success('File selected successfully')
    }
  }

  const handleAttachFile = () => {
    fileInputRef.current?.click()
  }

  const handleRemoveFile = () => {
    setSelectedFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const handleSubmit = async () => {
    if (!formData.title.trim()) {
      toast.error('Please enter a title for the itinerary')
      return
    }
    
    if (!formData.description.trim()) {
      toast.error('Please enter a description for the itinerary')
      return
    }
    
    if (!formData.location.trim()) {
      toast.error('Please enter a location for the itinerary')
      return
    }

    setIsSubmitting(true)
    
    try {
      // Create FormData for file upload
      const submitData = new FormData()
      submitData.append('title', formData.title)
      submitData.append('description', formData.description)
      submitData.append('location', formData.location)
      
      if (selectedFile) {
        submitData.append('attachment', selectedFile)
      }

      await onSubmit(submitData)
      
      // Reset form
      setFormData(initialData)
      setSelectedFile(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
      
    } catch (error) {
      console.error('Itinerary submission error:', error)
      toast.error(error.message || 'Failed to submit itinerary')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClose = () => {
    if (!isSubmitting) {
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">Share Itinerary</h2>
          <button
            onClick={handleClose}
            disabled={isSubmitting}
            className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <div className="p-6 space-y-4">
          {/* Title */}
          <div>
            <Label htmlFor="title" className="text-sm font-medium text-gray-700">
              Itinerary Title *
            </Label>
            <Input
              id="title"
              type="text"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              placeholder="e.g., 3-Day Cultural Tour in Kyoto"
              className="mt-1"
              disabled={isSubmitting}
            />
          </div>

          {/* Location */}
          <div>
            <Label htmlFor="location" className="text-sm font-medium text-gray-700">
              Location *
            </Label>
            <Input
              id="location"
              type="text"
              value={formData.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              placeholder="e.g., Kyoto, Japan"
              className="mt-1"
              disabled={isSubmitting}
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description" className="text-sm font-medium text-gray-700">
              Description *
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Describe the itinerary details, activities, and what's included..."
              rows={4}
              className="mt-1"
              disabled={isSubmitting}
            />
          </div>

          {/* File Attachment */}
          <div>
            <Label className="text-sm font-medium text-gray-700">
              Attachment (Optional)
            </Label>
            <div className="mt-1 space-y-2">
              {selectedFile ? (
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Paperclip className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-700 truncate">
                      {selectedFile.name}
                    </span>
                  </div>
                  <button
                    onClick={handleRemoveFile}
                    disabled={isSubmitting}
                    className="text-red-500 hover:text-red-700 disabled:opacity-50"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleAttachFile}
                  disabled={isSubmitting}
                  className="flex items-center space-x-2 p-3 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors disabled:opacity-50"
                >
                  <Paperclip className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">Attach file (PDF, Word, Image, max 50MB)</span>
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileChange}
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.webp"
                className="hidden"
                disabled={isSubmitting}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t bg-gray-50">
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-green-600 hover:bg-green-700"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Itinerary'}
          </Button>
        </div>
      </div>
    </div>
  )
}
