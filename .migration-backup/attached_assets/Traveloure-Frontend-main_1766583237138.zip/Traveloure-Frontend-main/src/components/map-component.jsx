"use client"

import { useState, useEffect, useRef } from "react"
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api"
import { AlertCircle, Map } from "lucide-react"
import { Button } from "../components/ui/button"

// Global flag to track if Google Maps script is already loaded
let googleMapsScriptLoaded = false

const MapComponent = ({ destination, apiKey }) => {
  const [center, setCenter] = useState({ lat: 48.8566, lng: 2.3522 }) // Default to Paris
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapError, setMapError] = useState(null)
  const [googleLoaded, setGoogleLoaded] = useState(false)
  const [shouldLoadMaps, setShouldLoadMaps] = useState(true)
  const [billingErrorDetected, setBillingErrorDetected] = useState(false)
  const geocodeTimeoutRef = useRef(null)
  const previousDestination = useRef(null)

  // Check if Google Maps API is available and detect billing errors early
  useEffect(() => {
    const checkGoogleMaps = () => {
      if (typeof window !== 'undefined' && window.google && window.google.maps) {
        setGoogleLoaded(true)
        googleMapsScriptLoaded = true
      }
    }

    // Check immediately
    checkGoogleMaps()

    // Set up an interval to check periodically
    const interval = setInterval(checkGoogleMaps, 1000)

    return () => clearInterval(interval)
  }, [])

  // Early detection of billing errors - check localStorage for previous errors
  useEffect(() => {
    const checkForPreviousBillingErrors = () => {
      const hasBillingError = localStorage.getItem('googleMapsBillingError')
      if (hasBillingError === 'true') {
        setBillingErrorDetected(true)
        setMapError("Google Maps billing is not enabled. Please enable billing for your API key.")
        setShouldLoadMaps(false)
      }
    }

    checkForPreviousBillingErrors()
  }, [])

  // Global error handler for Google Maps
  useEffect(() => {
    const handleMapError = (event) => {
      if (event.error && event.error.message && event.error.message.includes('BillingNotEnabledMapError')) {
        setMapError("Google Maps billing is not enabled. Please enable billing for your API key.")
        setShouldLoadMaps(false)
        setBillingErrorDetected(true)
        // Store billing error in localStorage to prevent future loading
        localStorage.setItem('googleMapsBillingError', 'true')
        // Prevent further Google Maps loading
        googleMapsScriptLoaded = false
      }
    }

    // Listen for Google Maps errors
    window.addEventListener('error', handleMapError)
    
    return () => {
      window.removeEventListener('error', handleMapError)
    }
  }, [])

  // Check for existing Google Maps errors on component mount
  useEffect(() => {
    // Check if there are any existing Google Maps errors in the console
    const originalConsoleError = console.error
    console.error = (...args) => {
      const message = args.join(' ')
      if (message.includes('BillingNotEnabledMapError') || message.includes('billing')) {
        setMapError("Google Maps billing is not enabled. Please enable billing for your API key.")
        setShouldLoadMaps(false)
        setBillingErrorDetected(true)
        // Store billing error in localStorage to prevent future loading
        localStorage.setItem('googleMapsBillingError', 'true')
        googleMapsScriptLoaded = false
      }
      originalConsoleError.apply(console, args)
    }

    return () => {
      console.error = originalConsoleError
    }
  }, [])

  // Only geocode when destination changes and is different from previous
  useEffect(() => {
    // Don't do anything if destination is empty or the same as before
    if (!destination || destination === previousDestination.current) return

    // Update previous destination
    previousDestination.current = destination

    // Clear any existing timeout
    if (geocodeTimeoutRef.current) {
      clearTimeout(geocodeTimeoutRef.current)
    }

    setIsLoading(true)
    setError(null)

    // Set a timeout to avoid too many API calls
    geocodeTimeoutRef.current = setTimeout(() => {
      const geocodeAddress = async () => {
        try {
          // Check if we have a valid API key
          if (!apiKey || apiKey === "YOUR_API_KEY" || apiKey.includes("undefined")) {
            setError("Invalid Google Maps API key. Please check your environment variables.")
            setIsLoading(false)
            return
          }

          const response = await fetch(
            `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(destination)}&key=${apiKey}`,
          )

          const data = await response.json()

          if (data.status === "OK" && data.results && data.results.length > 0) {
            const { lat, lng } = data.results[0].geometry.location
            setCenter({ lat, lng })
            setMapLoaded(true)
          } else if (data.status === "REQUEST_DENIED") {
            setError(
              `API key error: ${data.error_message || "Your Google Maps API key may not have the Geocoding API enabled."}`,
            )
            console.error("Geocoding API error:", data)
          } else {
            setError(`Could not find location: ${data.status || "Unknown error"}`)
            console.error("Geocoding error:", data)
          }
        } catch (error) {
          setError("Error fetching location data. Please check your internet connection.")
          console.error("Error fetching geocoding data:", error)
        } finally {
          setIsLoading(false)
        }
      }

      geocodeAddress()
    }, 500) // 500ms delay to avoid too many API calls

    return () => {
      if (geocodeTimeoutRef.current) {
        clearTimeout(geocodeTimeoutRef.current)
      }
    }
  }, [destination, apiKey])

  const handleRetry = () => {
    setError(null)
    setMapError(null)
    // Force re-geocoding by clearing the previous destination
    previousDestination.current = null
  }

  const containerStyle = {
    width: "100%",
    height: "100%",
  }

  // Don't render anything if we don't have an API key or if there's a billing error
  if (!apiKey || apiKey === "YOUR_API_KEY" || apiKey.includes("undefined") || mapError || billingErrorDetected) {
    return (
      <div className="w-full h-full bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {mapError ? "Google Maps Unavailable" : "Google Maps API Key Required"}
          </h3>
          <p className="text-gray-600">
            {mapError ? "Google Maps is currently unavailable. Please try again later." : "Please configure your Google Maps API key in the environment variables."}
          </p>
          <p className="text-sm text-gray-500 mt-2">
            {mapError ? "Billing or API configuration issue" : `Current API Key: ${apiKey ? 'Present' : 'Missing'}`}
          </p>
          {mapError && (
            <Button 
              onClick={() => {
                setMapError(null)
                setShouldLoadMaps(true)
                setBillingErrorDetected(false)
                // Clear the billing error flag from localStorage
                localStorage.removeItem('googleMapsBillingError')
              }} 
              className="mt-4 bg-[#FF385C] hover:bg-[#E02D50] text-white"
            >
              Try Again
            </Button>
          )}
        </div>
      </div>
    )
  }

  // If we have a destination but can't load Google Maps, show a simple fallback
  if (destination && (mapError || billingErrorDetected)) {
    return (
      <div className="w-full h-full bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center p-6">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Map className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Map Unavailable</h3>
          <p className="text-gray-600 mb-4">Location: {destination}</p>
          <p className="text-sm text-gray-500 mb-4">
            Google Maps is currently unavailable due to billing configuration.
          </p>
          <Button 
            onClick={() => {
              setMapError(null)
              setBillingErrorDetected(false)
              setShouldLoadMaps(true)
              localStorage.removeItem('googleMapsBillingError')
            }} 
            className="bg-[#FF385C] hover:bg-[#E02D50] text-white"
          >
            Try Again
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="relative w-full h-full">
      {isLoading && !error && (
        <div className="absolute inset-0 bg-white/90 z-10 flex items-center justify-center">
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 border-4 border-[#FF385C] border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-2 text-gray-600">Loading map for {destination}...</p>
          </div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 bg-white/90 z-10 flex items-center justify-center p-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-red-600 mr-2 mt-0.5" />
              <div>
                <h3 className="text-red-800 font-medium mb-2">Map Error</h3>
                <p className="text-red-600 mb-4">{error}</p>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Possible solutions:</p>
                  <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                    <li>Check if your Google Maps API key is valid</li>
                    <li>Ensure the Geocoding API is enabled for your API key</li>
                    <li>Try a different destination</li>
                    <li>Check your internet connection</li>
                  </ul>
                  <Button onClick={handleRetry} className="mt-4 bg-[#FF385C] hover:bg-[#E02D50] text-white">
                    Retry
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {!error && !mapError && shouldLoadMaps && !billingErrorDetected && (
        <LoadScript 
          googleMapsApiKey={apiKey || ""}
          onLoad={() => {
            setGoogleLoaded(true)
            googleMapsScriptLoaded = true
          }}
          onError={(error) => {
            console.error("Google Maps LoadScript error:", error)
            setMapError("Failed to load Google Maps. Please check your API key and billing settings.")
            setShouldLoadMaps(false)
            setBillingErrorDetected(true)
            // Store billing error in localStorage to prevent future loading
            localStorage.setItem('googleMapsBillingError', 'true')
            googleMapsScriptLoaded = false
          }}
        >
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={12}
            options={{
              fullscreenControl: true,
              zoomControl: true,
              streetViewControl: true,
              mapTypeControl: true,
            }}
            onLoad={() => {
              setMapLoaded(true)
            }}
            onError={(error) => {
              console.error("Google Maps error:", error)
              setMapError("Failed to load Google Maps. Please check your API key and billing settings.")
            }}
          >
            <Marker position={center} />
          </GoogleMap>
        </LoadScript>
      )}



      {mapError && (
        <div className="absolute inset-0 bg-white/90 z-10 flex items-center justify-center p-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-red-600 mr-2 mt-0.5" />
              <div>
                <h3 className="text-red-800 font-medium mb-2">Google Maps Error</h3>
                <p className="text-red-600 mb-4">{mapError}</p>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Possible solutions:</p>
                  <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                    <li>Check if your Google Maps API key is valid</li>
                    <li>Ensure billing is enabled for your Google Cloud project</li>
                    <li>Verify the Maps JavaScript API is enabled</li>
                    <li>Check your internet connection</li>
                  </ul>
                  <div className="flex gap-2 mt-4">
                    <Button onClick={() => window.location.reload()} className="bg-[#FF385C] hover:bg-[#E02D50] text-white">
                    Reload Page
                  </Button>
                    <Button onClick={() => {
                      setMapError(null)
                      setBillingErrorDetected(true)
                      setShouldLoadMaps(false)
                      // Store billing error in localStorage to prevent future loading
                      localStorage.setItem('googleMapsBillingError', 'true')
                    }} className="bg-gray-500 hover:bg-gray-600 text-white">
                      Continue Without Map
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default MapComponent
