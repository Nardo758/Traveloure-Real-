import { Card, CardContent } from "../components/ui/card"


export function StatsCard({ title, value, subtitle, trend }) {
  return (
    <Card className="bg-white border border-gray-200">
      <CardContent className="p-4 lg:p-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs lg:text-sm font-medium text-gray-600">{title}</p>
            <span className="text-xs text-gray-400">{trend}</span>
          </div>
          <div className="space-y-1">
            <p className="text-xl lg:text-2xl font-bold text-gray-900">{value}</p>
            <p className="text-xs text-gray-500">{subtitle}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
