"use client"

import { Lightbulb, RefreshCw } from "lucide-react"
import { useState } from "react"

export function ProTipCard() {
  const proTips = [
    "Travel during off-peak days or seasons - Flights and stays are cheaper, and you'll avoid crowds too.",
    "Book flights on Tuesdays and Wednesdays for the best deals.",
    "Use incognito mode when searching for flights to avoid price increases.",
    "Pack a portable charger and universal adapter for all your devices.",
    "Download offline maps before traveling to avoid data charges.",
    "Book accommodations with free cancellation for flexibility.",
    "Travel light - you can always buy essentials at your destination.",
    "Learn a few basic phrases in the local language before your trip."
  ]

  const [currentTip, setCurrentTip] = useState(0)

  const refreshTip = () => {
    setCurrentTip((prev) => (prev + 1) % proTips.length)
  }

  return (
    <div 
      className="bg-white rounded-xl p-4 border-2 relative overflow-hidden"
      style={{
        borderImage: "linear-gradient(135deg, #F30131 0%, #BE35EB 100%) 1"
      }}
    >
      {/* Refresh icon in top right */}
      <button 
        onClick={refreshTip}
        className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 transition-colors"
      >
        <RefreshCw className="h-4 w-4" />
      </button>
      
      {/* Lightbulb icon with glow effect */}
      <div className="flex items-center gap-2 mb-3">
        <div className="relative">
          <Lightbulb className="h-5 w-5 text-yellow-400" />
          <div className="absolute inset-0 h-5 w-5 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
        </div>
        <span 
          className="font-semibold text-lg"
          style={{
            background: "linear-gradient(135deg, #F30131 0%, #BE35EB 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text"
          }}
        >
          Pro Tip
        </span>
      </div>
      
      {/* Tip content */}
      <p className="text-gray-700 text-sm leading-relaxed">
        {proTips[currentTip]}
      </p>
    </div>
  )
} 