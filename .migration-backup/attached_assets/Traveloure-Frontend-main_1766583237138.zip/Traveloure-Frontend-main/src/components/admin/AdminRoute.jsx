"use client"

import { useEffect } from 'react'
import { useAdmin } from '../../hooks/useAdmin'
import { useRouter } from 'next/navigation'

export default function AdminRoute({ children }) {
  const { isAdmin, isAuthenticated, isLoading } = useAdmin()
  const router = useRouter()

  useEffect(() => {
    if (isLoading) return

    if (!isAuthenticated) {
      router.push('/login')
      return
    }

    if (!isAdmin) {
      router.push('/dashboard')
      return
    }
  }, [isAdmin, isAuthenticated, isLoading, router])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-[#fcfbfa]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking admin permissions...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated || !isAdmin) {
    return null
  }

  return children
}

