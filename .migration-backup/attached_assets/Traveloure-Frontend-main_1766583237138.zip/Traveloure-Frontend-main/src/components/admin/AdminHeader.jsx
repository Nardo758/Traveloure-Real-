"use client"

import { useSession } from 'next-auth/react'
import { ChevronDown, Plus, Menu, Send } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { Button } from '../ui/button'
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from '../ui/dropdown-menu'
import { signOut } from 'next-auth/react'

export function AdminHeader({ onMenuToggle }) {
  const { data: session } = useSession()
  const user = session?.user || {}

  // Provide a default function if onMenuToggle is not passed
  const handleMenuToggle = onMenuToggle || (() => {
    // Silent fallback - all admin pages should now have proper implementation
  })



  return (
    <>
      {/* Beta Banner */}
      <div className="w-full bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white py-2 px-4 text-center relative overflow-hidden border-b border-orange-300">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10 container mx-auto flex items-center justify-center gap-2">
          <span className="inline-flex items-center px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold animate-pulse">
            🚀 BETA
          </span>
          <span className="text-xs md:text-sm font-medium">
            Admin Panel - Testing new features • Your feedback helps us improve
          </span>
        </div>
      </div>
      
      <header className="bg-white text-black border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Left side - Hamburger menu and logo */}
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden p-2"
              onClick={handleMenuToggle}
            >
              <Menu className="h-5 w-5" />
            </Button>
            
            {/* Beta Badge */}
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white shadow-md border border-orange-300">
              🚀 BETA
            </span>
           
          </div>

        {/* Right side - User profile */}
        <div className="flex items-center gap-4">
          {/* User Profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="flex items-center gap-2 px-3 py-2 h-9 rounded-full border-gray-200 shadow-sm"
              >
                <Avatar className="h-6 w-6">
                  <AvatarImage src={user?.image || "/placeholder.svg"} alt={user?.username} />
                                                <AvatarFallback className="text-xs bg-rose-500 text-white">
                                {user?.name?.charAt(0) || "M"}
                              </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-gray-800 max-w-20 truncate">
                  {user?.name || 'Mathew Wade'}
                </span>
                <ChevronDown className="h-4 w-4 text-gray-500" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-48" align="end">
              
              <DropdownMenuItem 
                onClick={() => signOut({ callbackUrl: '/' })}
                className="text-red-600"
              >
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
    </>
  )
} 