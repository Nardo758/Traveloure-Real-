"use client"

import { memo, useMemo } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import Image from "next/image"

// Admin menu items based on the image
const adminMenuItems = [
  {
    title: "Dashboard",
    url: "/admin/dashboard",
  },
  {
    title: "Travelers",
    url: "/admin/travelers",
  },
  {
    title: "Local Experts",
    url: "/admin/local-experts",
  },
  {
    title: "Service Providers",
    url: "/admin/service-providers",
  },
  {
    title: "Itinerary Management",
    url: "/admin/itineraries",
  },
  {
    title: "Bookings & Services",
    url: "/admin/bookings",
  },
  {
    title: "Reviews & Feedback",
    url: "/admin/reviews",
  },
  {
    title: "Platform Settings",
    url: "/admin/settings",
  },
  {
    title: "Content Management",
    url: "/admin/content",
  },
  {
    title: "Admin Users & Roles",
    url: "/admin/users",
  },
  {
    title: "Analytics & Reports",
    url: "/admin/analytics",
  },
  {
    title: "Add Contract Category",
    url: "/admin/contract-categories",
  },
  {
    title: "Manage FAQ",
    url: "/admin/faqs",
  },
]

// Memoized MenuItem component
const MenuItem = memo(({ item, isActive }) => {
  
  return (
    <div className="relative px-2">
      {isActive && (
        <div className="absolute left-[-11px] top-1/2 -translate-y-1/2 h-10 w-1 rounded-r-full bg-[#FF385C] z-10" />
      )}
      <Link
        href={item.url}
        className={`flex items-center gap-3 px-3 py-2 ml-1 rounded-lg text-sm font-medium transition-colors relative z-20 ${
          isActive
            ? "bg-pink-50 text-pink-600"
            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        }`}
      >
    
        <span>{item.title}</span>
      </Link>
    </div>
  )
})

MenuItem.displayName = 'MenuItem'

export const AdminSidebar = memo(function AdminSidebar({ isOpen, onClose }) {
  const pathname = usePathname()

  // Memoize the menu items rendering
  const renderedMenuItems = useMemo(() => {
    return adminMenuItems.map((item) => {
      // Check if current path starts with the menu item URL
      // This ensures sub-pages are also highlighted
      const isActive = pathname === item.url || pathname.startsWith(item.url + '/')
      return (
        <MenuItem
          key={item.title}
          item={item}
          isActive={isActive}
        />
      )
    })
  }, [pathname])

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-[9998] lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-[9999] w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo Section */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex justify-center items-center mb-[1px]">
            <Image src="/Main-logo.png" alt="Logo" width={150} height={150} />
          </div>
        </div>
        
        {/* Navigation */}
        <div className="flex-1 p-3 pt-0 overflow-y-auto pr-0">
          <nav className="space-y-2 border-r border-gray-200">
            {renderedMenuItems}
          </nav>
        </div>
      </div>
    </>
  )
})

AdminSidebar.displayName = 'AdminSidebar' 