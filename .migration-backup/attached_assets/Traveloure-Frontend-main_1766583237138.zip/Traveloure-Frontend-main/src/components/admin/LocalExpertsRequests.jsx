"use client"

import { useState, useEffect } from "react"
import { useSession } from 'next-auth/react'
import { useDispatch, useSelector } from 'react-redux'
import { Search, ArrowLeft, ChevronDown, MoreVertical, ChevronLeft, ChevronRight, AlertCircle } from "lucide-react"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar"
import Link from "next/link"
import { Card } from "../ui/card"
import { CommonDataTable } from "./CommonDataTable"
import { getCountriesForFilter, getLanguagesForFilter, applyFilters } from "../../lib/countryUtils"
import { getPendingLocalExperts, updateLocalExpert } from "../../app/redux-features/Travelexperts/travelexpertsSlice"
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog"

// Static fallback data
const staticExpertsData = [
  {
    id: 1,
    name: "Jacob Jones",
    email: "jacobjones@gmail.com",
    contact: "(603) 555-0123",
    country: "Australia",
    languages: "English, Spanish, French",
    requestDate: "May 10, 2025 02:00 PM",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 2,
    name: "Brooklyn Simmons",
    email: "brooklynsimmons@gmail.com",
    contact: "(603) 555-0124",
    country: "Canada",
    languages: "English, French",
    requestDate: "May 9, 2025 03:30 PM",
    avatar: "/placeholder.svg?height=32&width=32",
  }
]

export function LocalExpertsRequests() {
  const { data: session } = useSession()
  const dispatch = useDispatch()
  
  // Redux state
  const { pendingExperts, pendingLoading, pendingError } = useSelector((state) => state.travelExperts)
  
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("recent")
  const [countryFilter, setCountryFilter] = useState("all")
  const [languageFilter, setLanguageFilter] = useState("all")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState([])
  const [countries] = useState(getCountriesForFilter())
  const [languages] = useState(getLanguagesForFilter())
  const [isStaticData, setIsStaticData] = useState(false)
  
  // Confirmation modal states
  const [showApproveModal, setShowApproveModal] = useState(false)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [selectedExpertId, setSelectedExpertId] = useState(null)
  const [selectedExpertName, setSelectedExpertName] = useState("")

  // Transform API data to component format
  const transformApiData = (data) => {
    if (!data || !Array.isArray(data)) return staticExpertsData

    return data.map(expert => ({
      id: expert.id,
      name: `${expert.user?.first_name || ''} ${expert.user?.last_name || ''}`.trim() || 'Unknown',
      email: expert.user?.email || 'No email',
      contact: expert.user?.phone_number || 'No contact',
      country: expert.user?.country || 'Unknown',
      languages: expert.languages?.join(', ') || 'Not specified',
      requestDate: new Date(expert.created_at).toLocaleString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      avatar: expert.user?.image || null,
      // Additional data for actions
      status: expert.status,
      yearsInCity: expert.years_in_city,
      services: expert.services,
      priceExpectation: expert.price_expectation,
      serviceAvailability: expert.service_availability,
      govId: expert.gov_id,
      travelLicence: expert.travel_licence,
      instagramLink: expert.instagram_link,
      facebookLink: expert.facebook_link,
      linkedinLink: expert.linkedin_link,
      aboutMe: expert.user?.about_me,
      tripPlanned: expert.user?.trip_planned,
      currentTripCount: expert.user?.current_trip_count,
      upcomingTripCount: expert.user?.upcoming_trip_count
    }))
  }

  // Fetch data using Redux
  useEffect(() => {
    if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
      dispatch(getPendingLocalExperts({ token: session.backendData.accessToken }))
    }
  }, [dispatch])

  // Update component state when Redux data changes
  useEffect(() => {
    if (pendingExperts && pendingExperts.length > 0) {
      const transformedData = transformApiData(pendingExperts)
      setFilteredData(transformedData)
      setIsStaticData(false)
    } else if (pendingError) {
      // Fallback to static data on error
      setFilteredData(staticExpertsData)
      setIsStaticData(true)
    }
  }, [pendingExperts, pendingError])

  const handleApprove = async (id) => {
    try {
      if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
        await dispatch(updateLocalExpert({ 
          token: session.backendData.accessToken, 
          id: id, 
          payload: { status: 'approved' } 
        })).unwrap()
        
        // Refresh the pending experts list after approval
        dispatch(getPendingLocalExperts({ token: session.backendData.accessToken }))
      }
    } catch (error) {
      console.error("Error approving expert:", error)
    }
  }

  const handleReject = async (id) => {
    try {
      if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
        await dispatch(updateLocalExpert({ 
          token: session.backendData.accessToken, 
          id: id, 
          payload: { status: 'rejected' } 
        })).unwrap()
        
        // Refresh the pending experts list after rejection
        dispatch(getPendingLocalExperts({ token: session.backendData.accessToken }))
      }
    } catch (error) {
      console.error("Error rejecting expert:", error)
    }
  }

  const openApproveModal = (id, name) => {
    setSelectedExpertId(id)
    setSelectedExpertName(name)
    setShowApproveModal(true)
  }

  const openRejectModal = (id, name) => {
    setSelectedExpertId(id)
    setSelectedExpertName(name)
    setShowRejectModal(true)
  }

  const confirmApprove = async () => {
    if (selectedExpertId) {
      await handleApprove(selectedExpertId)
      setShowApproveModal(false)
      setSelectedExpertId(null)
      setSelectedExpertName("")
    }
  }

  const confirmReject = async () => {
    if (selectedExpertId) {
      await handleReject(selectedExpertId)
      setShowRejectModal(false)
      setSelectedExpertId(null)
      setSelectedExpertName("")
    }
  }

  // Apply filters when search or filters change
  useEffect(() => {
    const dataToFilter = pendingExperts && pendingExperts.length > 0 
      ? transformApiData(pendingExperts) 
      : staticExpertsData

    const filters = {
      search: searchQuery,
      country: countryFilter,
      languages: languageFilter,
      sortBy: sortBy
    }
    const filtered = applyFilters(dataToFilter, filters)
    setFilteredData(filtered)
  }, [searchQuery, countryFilter, languageFilter, sortBy, pendingExperts])

  // Table configuration
  const columns = [
    {
      key: 'name',
      label: 'Local Expert Name',
      render: (expert, index) => (
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500 w-6">{index + 1}.</span>
          <Avatar className="h-10 w-10">
            <AvatarImage src={expert.avatar || "/placeholder.svg"} alt={expert.name} />
            <AvatarFallback className="bg-[#FF385C] text-white text-sm font-medium">
              {expert.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-gray-900">{expert.name}</span>
        </div>
      )
    },
    { key: 'email', label: 'Email' },
    { key: 'contact', label: 'Contact Number' },
    { key: 'country', label: 'Country' },
    { key: 'languages', label: 'Languages Spoken'},
    { key: 'requestDate', label: 'Request Date & Time'}
  ]

  const filters = [
    {
      key: 'sortBy',
      label: 'Sort By',
      placeholder: 'Recent',
      options: [
        { value: 'recent', label: 'Recent' },
        { value: 'all', label: 'All' },
        { value: 'older', label: 'Older' }
      ]
    },
    {
      key: 'country',
      label: 'By Country',
      placeholder: 'All Countries',
      options: countries,
      searchable: true,
      maxHeight: '200px'
    },
    {
      key: 'languages',
      label: 'Languages Spoken',
      placeholder: 'All Languages',
      options: languages,
      searchable: true,
      maxHeight: '200px'
    }
  ]

  const actions = [
    {
      type: 'button',
      key: 'approve',
      label: 'Approve',
      variant: 'default',
      className: 'bg-[#58AC00] hover:bg-[#4A8F00] text-white text-xs px-3 py-1.5'
    },
    {
      type: 'button',
      key: 'reject',
      label: 'Reject',
      variant: 'outline',
      className: 'text-xs px-3 py-1.5 border-[#FF385C] text-[#FF385C] hover:bg-[#FF385C] hover:text-white bg-transparent'
    },
    {
      type: 'dropdown',
      key: 'more',
      items: [
        { key: 'viewDetails', label: 'View Details' },
        { key: 'editDetails', label: 'Edit Details' },
        { key: 'sendMail', label: 'Send Mail' }
      ]
    }
  ]

  const handleTableAction = (actionKey, itemId) => {
    const expert = filteredData.find(e => e.id === itemId)
    const expertName = expert?.name || 'this expert'
    
    switch (actionKey) {
      case 'approve':
        openApproveModal(itemId, expertName)
        break
      case 'reject':
        openRejectModal(itemId, expertName)
        break
      case 'viewDetails':
        console.log("View details for expert:", itemId)
        break
      case 'editDetails':
        console.log("Edit details for expert:", itemId)
        break
      case 'sendMail':
        console.log("Send mail to expert:", itemId)
        break
      default:
        break
    }
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Static Data Label */}
      {isStaticData && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <span className="text-sm text-yellow-800">Showing static data - API unavailable</span>
        </div>
      )}

      {/* Header Section */}
      <div className="mb-6">
        <div className="mb-4">
          <Link href="/admin/local-experts" className="flex items-center gap-2 text-[#FF385C] hover:text-red-700">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Previous Page</span>
          </Link>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-2xl font-bold text-gray-900">
            Local Experts Requests ({filteredData.length})
          </h1>
          <Link href="/admin/rejected-local-experts">
            <Button
              variant="outline"
              className="border-[#FF385C] text-[#FF385C] hover:bg-[#FF385C] hover:text-white bg-transparent"
            >
              Rejected
            </Button>
          </Link>
        </div>
      </div>

      {/* Loading State */}
      {pendingLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF385C]"></div>
          <span className="ml-3 text-gray-600">Loading pending requests...</span>
        </div>
      )}

      {/* Error State */}
      {pendingError && !isStaticData && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <span className="text-red-800">Error loading data: {pendingError}</span>
          </div>
        </div>
      )}

      {/* Common Data Table */}
      {!pendingLoading && (
        <CommonDataTable
          data={filteredData}
          columns={columns}
          filters={filters}
          actions={actions}
          searchPlaceholder="Search by Local Expert Name"
          onAction={handleTableAction}
          onSearch={(value) => setSearchQuery(value)}
          onFilterChange={(filters) => {
            setSortBy(filters.sortBy || 'recent')
            setCountryFilter(filters.country || 'all')
            setLanguageFilter(filters.languages || 'all')
          }}
        />
      )}

      {/* Approve Confirmation Modal */}
      <Dialog open={showApproveModal} onOpenChange={setShowApproveModal}>
        <DialogContent className="sm:max-w-md">
          <DialogTitle className="text-lg font-semibold text-gray-900">
            Confirm Approval
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            Are you sure you want to approve <span className="font-semibold text-gray-900">{selectedExpertName}</span> as a Local Expert?
           
          </DialogDescription>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowApproveModal(false)
                setSelectedExpertId(null)
                setSelectedExpertName("")
              }}
            >
              Cancel
            </Button>
            <Button
              className="bg-[#58AC00] hover:bg-[#4A8F00] text-white"
              onClick={confirmApprove}
            >
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Confirmation Modal */}
      <Dialog open={showRejectModal} onOpenChange={setShowRejectModal}>
        <DialogContent className="sm:max-w-md">
          <DialogTitle className="text-lg font-semibold text-gray-900">
            Confirm Rejection
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            Are you sure you want to reject <span className="font-semibold text-gray-900">{selectedExpertName}</span>'s Local Expert application?
       
          </DialogDescription>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowRejectModal(false)
                setSelectedExpertId(null)
                setSelectedExpertName("")
              }}
            >
              Cancel
            </Button>
            <Button
              variant="outline"
              className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
              onClick={confirmReject}
            >
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
