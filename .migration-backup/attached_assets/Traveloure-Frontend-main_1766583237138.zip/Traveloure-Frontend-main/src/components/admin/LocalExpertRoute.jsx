"use client"

import { useEffect } from 'react'
import { useAdmin } from '../../hooks/useAdmin'
import { useRouter } from 'next/navigation'

export default function LocalExpertRoute({ children }) {
  const { isLocalExpert, isAuthenticated, isLoading } = useAdmin()
  const router = useRouter()

  useEffect(() => {
    if (isLoading) return

    if (!isAuthenticated) {
      router.push('/login')
      return
    }

    if (!isLocalExpert) {
      router.push('/dashboard')
      return
    }
  }, [isLocalExpert, isAuthenticated, isLoading, router])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-[#fcfbfa]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto mb-4"></div>
        </div>
      </div>
    )
  }

  if (!isAuthenticated || !isLocalExpert) {
    return null
  }

  return children
}
