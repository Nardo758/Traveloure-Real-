"use client"

import { useState } from "react"
import { Search, ChevronDown, ChevronLeft, ChevronRight, MoreVertical } from "lucide-react"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"
import { SearchableSelect } from "../ui/searchable-select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table"
import { Card } from "../ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu"

export function CommonDataTable({
  title,
  data,
  columns,
  searchPlaceholder = "Search...",
  filters = [],
  actions = [],
  onSearch,
  onFilterChange,
  onAction,
  pagination = true,
  itemsPerPage = 10,
  className = ""
}) {
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filterValues, setFilterValues] = useState({})

  // Initialize filter values
  useState(() => {
    const initialFilters = {}
    filters.forEach(filter => {
      initialFilters[filter.key] = filter.defaultValue || "all"
    })
    setFilterValues(initialFilters)
  }, [filters])

  const handleSearch = (value) => {
    setSearchQuery(value)
    setCurrentPage(1)
    if (onSearch) {
      onSearch(value)
    }
  }

  const handleFilterChange = (filterKey, value) => {
    const newFilters = { ...filterValues, [filterKey]: value }
    setFilterValues(newFilters)
    setCurrentPage(1)
    if (onFilterChange) {
      onFilterChange(newFilters)
    }
  }

  const handleAction = (actionKey, itemId, item) => {
    if (onAction) {
      onAction(actionKey, itemId, item)
    }
  }

  const totalPages = Math.ceil(data.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentData = data.slice(startIndex, endIndex)

  return (
    <div className={className}>
      {/* Search and Filter Section */}
      <Card className="rounded-lg p-6 mb-6 shadow-sm">
        <div className="space-y-4 lg:space-y-0 lg:flex lg:flex-wrap lg:items-end lg:gap-6">
          {/* Search Input */}
          <div className="flex-1 min-w-[280px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder={searchPlaceholder}
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 h-10"
              />
            </div>
          </div>
          
          {/* Search Button */}
          <div className="lg:ml-2">
            <Button className="w-full lg:w-auto h-10 px-8 bg-[#FF385C] hover:bg-[#e83555] text-white">
              Search
            </Button>
          </div>

          {/* Filters Row */}
          {filters.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:flex lg:gap-6 lg:flex-wrap">
              {filters.map((filter) => (
                <div key={filter.key} className="min-w-[140px]">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <label className="text-sm text-gray-600 whitespace-nowrap">{filter.label}:</label>
                    {filter.searchable ? (
                      <SearchableSelect
                        value={filterValues[filter.key] || "all"}
                        onValueChange={(value) => handleFilterChange(filter.key, value)}
                        placeholder={filter.placeholder}
                        options={filter.options}
                        searchable={true}
                        maxHeight={filter.maxHeight || "200px"}
                        className="w-full"
                      />
                    ) : (
                      <Select 
                        value={filterValues[filter.key] || "all"} 
                        onValueChange={(value) => handleFilterChange(filter.key, value)}
                      >
                        <SelectTrigger className="h-10 border-none">
                          <SelectValue placeholder={filter.placeholder} />
                        </SelectTrigger>
                        <SelectContent>
                          {filter.options.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>

      {/* Table Section */}
      <Card className="rounded-lg p-6 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b">
                {columns.map((column) => (
                  <TableHead key={column.key} className="font-semibold text-gray-900 py-4">
                    {column.sortable ? (
                      <div className="flex items-center gap-1 cursor-pointer">
                        {column.label}
                        <ChevronDown className="h-4 w-4" />
                      </div>
                    ) : (
                      column.label
                    )}
                  </TableHead>
                ))}
                {actions.length > 0 && (
                  <TableHead className="font-semibold text-gray-900 py-4">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentData.map((item, index) => (
                <TableRow key={item.id || index} className="hover:bg-gray-50 border-b border-gray-100">
                  {columns.map((column) => (
                    <TableCell key={column.key} className="py-4">
                      {column.render ? column.render(item, index) : item[column.key]}
                    </TableCell>
                  ))}
                  {actions.length > 0 && (
                    <TableCell className="py-4">
                      <div className="flex items-center gap-2">
                        {actions.map((action) => (
                          action.type === 'button' ? (
                            <Button
                              key={action.key}
                              size="sm"
                              variant={action.variant || "outline"}
                              className={action.className || ""}
                              onClick={() => handleAction(action.key, item.id, item)}
                            >
                              {action.label}
                            </Button>
                          ) : action.type === 'dropdown' ? (
                            <DropdownMenu key={action.key}>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="ghost" className="p-1.5">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-48">
                                {action.items.map((dropdownItem) => (
                                  <DropdownMenuItem 
                                    key={dropdownItem.key}
                                    onClick={() => handleAction(dropdownItem.key, item.id, item)}
                                    className={dropdownItem.className || "flex items-center gap-2"}
                                  >
                                    {dropdownItem.icon && <dropdownItem.icon className="h-4 w-4" />}
                                    {dropdownItem.label}
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          ) : null
                        ))}
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Pagination */}
      {pagination && totalPages > 1 && (
        <div className="flex justify-center items-center gap-2 mt-6">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1 bg-transparent"
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>

          <div className="flex items-center gap-1">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const pageNum = i + 1
              return (
                <Button
                  key={pageNum}
                  size="sm"
                  className={pageNum === currentPage ? "bg-[#FF385C] text-white hover:bg-red-700" : ""}
                  variant={pageNum === currentPage ? "default" : "outline"}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Button>
              )
            })}
            {totalPages > 5 && (
              <>
                <span className="px-2 text-gray-500">...</span>
                <Button size="sm" variant="outline" onClick={() => setCurrentPage(totalPages)}>
                  {totalPages}
                </Button>
              </>
            )}
          </div>

          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1 bg-transparent"
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
} 