"use client"

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useDispatch, useSelector } from 'react-redux'
import { useRouter } from 'next/navigation'
import { Search, ChevronDown, TrendingUp, TrendingDown, Check, ArrowRight, PlusIcon, PlusCircle, AlertCircle } from 'lucide-react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import Link from 'next/link'
import { getLocalExpertDashboard, getLocalExpertsByCountry } from '../../app/redux-features/Travelexperts/travelexpertsSlice'

// Static fallback data
const staticSummaryData = [
  {
    title: "Total Experts",
    value: "246",
    trend: "+13",
    trendDirection: "up",
    period: "vs Last Month"
  },
  {
    title: "New Experts",
    value: "46",
    trend: "+08",
    trendDirection: "up",
    period: "THIS MONTH"
  },
  {
    title: "Pending Approval",
    value: "67",
    trend: "-11",
    trendDirection: "down",
    period: "vs Last Month"
  },
  {
    title: "Total Active Experts",
    value: "106",
    trend: "-14",
    trendDirection: "down",
    period: "vs Last Month"
  }
]

const staticCountryData = [
  {
    country: "Spain",
    totalExperts: 86,
    cities: [
      { name: "Barcelona", experts: 18 },
      { name: "Madrid", experts: 18 },
      { name: "Seville", experts: 18 }
    ],
    totalCities: 6
  },
  {
    country: "India",
    totalExperts: 78,
    cities: [
      { name: "Delhi", experts: 21 },
      { name: "Mumbai", experts: 18 },
      { name: "Jaipur", experts: 17 }
    ],
    totalCities: 5
  },
  {
    country: "Italy",
    totalExperts: 66,
    cities: [
      { name: "Rome", experts: 33 },
      { name: "Florence", experts: 20 },
      { name: "Venice", experts: 14 }
    ],
    totalCities: 3
  },
  {
    country: "Thailand",
    totalExperts: 60,
    cities: [
      { name: "Bangkok", experts: 30 },
      { name: "Chiang Mai", experts: 17 },
      { name: "Phuket", experts: 13 }
    ],
    totalCities: 3
  },
  {
    country: "France",
    totalExperts: 24,
    cities: [
      { name: "Spas", experts: 14 },
      { name: "Fitness", experts: 10 }
    ],
    totalCities: 2
  },
  {
    country: "Japan",
    totalExperts: 20,
    cities: [
      { name: "Tokyo", experts: 16 },
      { name: "Kyoto", experts: 4 }
    ],
    totalCities: 2
  }
]

export function LocalExpertsManagement() {
  const { data: session } = useSession()
  const dispatch = useDispatch()
  const router = useRouter()
  
  // Redux state
  const { dashboardData, dashboardLoading, dashboardError } = useSelector((state) => state.travelExperts)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterBy, setFilterBy] = useState("most-experts")
  const [summaryData, setSummaryData] = useState(staticSummaryData)
  const [countryData, setCountryData] = useState(staticCountryData)
  const [isStaticData, setIsStaticData] = useState(false)
  const [visibleCount, setVisibleCount] = useState(6) // Show first 6 cards initially

  // Transform API data to component format
  const transformApiData = (data) => {
    if (!data) return { summaryData: staticSummaryData, countryData: staticCountryData }

    const transformedSummaryData = [
      {
        title: "Total Experts",
        value: data.count?.toString() || "0",
        trend: "+0",
        trendDirection: "up",
        period: "vs Last Month"
      },
      {
        title: "New Experts",
        value: data.total_new_last_30_days?.toString() || "0",
        trend: "+0",
        trendDirection: "up",
        period: "THIS MONTH"
      },
      {
        title: "Pending Approval",
        value: data.total_pending?.toString() || "0",
        trend: "-0",
        trendDirection: "down",
        period: "vs Last Month"
      },
      {
        title: "Total Active Experts",
        value: data.total_active?.toString() || "0",
        trend: "-0",
        trendDirection: "down",
        period: "vs Last Month"
      }
    ]

    const transformedCountryData = data.summary?.map((item, index) => ({
      country: item.country || `Country ${index + 1}`,
      totalExperts: item.total_experts || 0,
      cities: item.cities?.map((city, cityIndex) => ({
        name: city.city || `City ${cityIndex + 1}`,
        experts: city.experts || 0
      })) || [],
      totalCities: item.cities?.length || 0
    })) || []

    return { summaryData: transformedSummaryData, countryData: transformedCountryData }
  }

  // Fetch data using Redux
  useEffect(() => {
    if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
      dispatch(getLocalExpertDashboard({ token: session.backendData.accessToken }))
    }
  }, [dispatch])

  // Update component state when Redux data changes
  useEffect(() => {
    if (dashboardData) {
      const { summaryData: newSummaryData, countryData: newCountryData } = transformApiData(dashboardData)
      setSummaryData(newSummaryData)
      setCountryData(newCountryData)
      setIsStaticData(false)
    } else if (dashboardError) {
      // Fallback to static data on error
      setSummaryData(staticSummaryData)
      setCountryData(staticCountryData)
      setIsStaticData(true)
    }
  }, [dashboardData, dashboardError])

  // Filter and search functionality
  const filteredCountryData = countryData
    .filter(country => {
      if (!searchQuery) return true
      const query = searchQuery.toLowerCase()
      return (
        country.country.toLowerCase().includes(query) ||
        country.cities.some(city => city.name.toLowerCase().includes(query))
      )
    })
    .sort((a, b) => {
      switch (filterBy) {
        case "most-experts":
          return b.totalExperts - a.totalExperts
        case "least-experts":
          return a.totalExperts - b.totalExperts
        case "alphabetical":
          return a.country.localeCompare(b.country)
        default:
          return 0
      }
    })

  // Get visible countries for pagination
  const visibleCountries = filteredCountryData.slice(0, visibleCount)
  const hasMoreCountries = visibleCount < filteredCountryData.length

  // Handle "Read More" click
  const handleReadMore = () => {
    setVisibleCount(prev => prev + 6)
  }

  // Handle "Show Less" click
  const handleShowLess = () => {
    setVisibleCount(6)
  }

  const handleViewAllByCountry = async (countryName) => {
    try {
      if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
        await dispatch(getLocalExpertsByCountry({ 
          token: session.backendData.accessToken, 
          countryName: countryName.toLowerCase() 
        })).unwrap()
        
        // Navigate to the country-specific page after successful API call
        router.push(`/admin/local-experts-country/${countryName.toLowerCase()}`)
      }
    } catch (error) {
      console.error("Error fetching country experts:", error)
    }
  }

  // Reset visible count when search or filter changes
  useEffect(() => {
    setVisibleCount(6)
  }, [searchQuery, filterBy])

  // Check if we should show the "Show Less" button
  const shouldShowLess = visibleCount > 6

  return (
    <div className="p-6">
      {/* Static Data Label */}
      {isStaticData && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <span className="text-sm text-yellow-800">Showing static data - API unavailable</span>
        </div>
      )}

      {/* Header Section with Title and Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Local Experts Management</h1>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <Link href="/admin/local-experts-requests">
            <Button
              variant="outline"
              className="bg-white border-[#FF385C] text-[#FF385C] hover:bg-red-50 text-sm sm:text-base"
            >
              Requests ({summaryData[2]?.value || 0})
            </Button>
          </Link>
          {/* <Button className="bg-[#FF385C] hover:bg-red-700 text-white text-sm sm:text-base">
            Add New <PlusCircle className="h-4 w-4 ml-2" />
          </Button> */}
        </div>
      </div>

      {/* Loading State */}
      {dashboardLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF385C]"></div>
          <span className="ml-3 text-gray-600">Loading data...</span>
        </div>
      )}

      {/* Error State */}
      {dashboardError && !isStaticData && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <span className="text-red-800">Error loading data: {dashboardError}</span>
          </div>
        </div>
      )}

      {/* Summary Cards */}
      {!dashboardLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {summaryData.map((item, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-gray-700">{item.title}</h3>
                {item.period === "THIS MONTH" && (
                  <div className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                    {item.period}
                  </div>
                )}
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">{item.value}</div>
              <div className={`flex items-center gap-1 text-sm ${item.trendDirection === "up" ? "text-green-600" : "text-red-600"
                }`}>
                {item.trendDirection === "up" ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                <span className="font-medium">{item.trend} vs Last Month</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <Card className="border border-gray-200 shadow-sm">
        <CardContent className="p-6">
          <div className="mb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              <div className='flex items-end gap-2'>
                <label className="block text-sm font-bold text-gray-700 mb-2">Search:</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Search by Country or City"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-full border border-gray-200 rounded-lg"
                  />
                 
                </div> <Button className="bg-[#FF385C] hover:bg-red-700 text-white rounded-md px-6">
                    Search
                  </Button>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Filter by:</label>
                <Select value={filterBy} onValueChange={setFilterBy}>
                  <SelectTrigger className="w-full border border-gray-200 rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="most-experts">
                      <div className="flex items-center gap-2">
                        <span>Most Experts</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="least-experts">Least Experts</SelectItem>
                    <SelectItem value="alphabetical">Alphabetical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Experts By Countries Section */}
          {!dashboardLoading && (
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4">Experts By Countries</h2>
              {visibleCountries.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No countries found matching your search criteria.
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {visibleCountries.map((country, index) => (
                      <div key={index} className="bg-gray-50 p-6 rounded-lg border border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-900">{country.country}</h3>
                          <div className="bg-[#fff] text-[#FF385C] px-3 py-1 rounded-full text-sm font-medium">
                            {country.totalExperts} Experts
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-2 mb-4">
                          {country.cities.map((city, cityIndex) => (
                            <div key={cityIndex} className="bg-white p-3 flex justify-center items-center rounded-lg border border-gray-200 text-center">
                              <div className="text-[12px] font-medium text-gray-900 mb-1">{city.name}{" "}{city.experts}</div>

                              {cityIndex === country.cities.length - 1 && (
                                <ArrowRight className="h-4 w-4 text-gray-400 mx-auto mt-1" />
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                          <span className="text-sm text-gray-500">Total Cities: {country.totalCities}</span>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-[#FF385C] border-[#FF385C] hover:bg-[#FF385C]/10"
                            onClick={() => handleViewAllByCountry(country.country)}
                          >
                            View All
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Read More / Show Less Buttons */}
                  {(hasMoreCountries || shouldShowLess) && (
                    <div className="flex justify-center mt-8 gap-4">
                      {hasMoreCountries && (
                        <Button 
                          onClick={handleReadMore}
                          className="bg-[#FF385C] hover:bg-red-700 text-white px-8 py-3 rounded-lg"
                        >
                          Read More
                        </Button>
                      )}
                      {shouldShowLess && (
                        <Button 
                          onClick={handleShowLess}
                          variant="outline"
                          className="border-[#FF385C] text-[#FF385C] hover:bg-[#FF385C]/10 px-8 py-3 rounded-lg"
                        >
                          Show Less
                        </Button>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
} 