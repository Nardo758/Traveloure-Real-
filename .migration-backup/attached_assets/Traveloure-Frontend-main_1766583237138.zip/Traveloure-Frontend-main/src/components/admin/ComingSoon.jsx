"use client"

import { Clock, Construction } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'

export function ComingSoon({ pageTitle = "This Page" }) {
  return (
    <div className="flex-1 overflow-y-auto bg-white p-6">
      <div className="max-w-2xl mx-auto">
        <div className="text-center space-y-6">
          {/* Icon */}
          <div className="flex justify-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center">
              <Construction className="h-12 w-12 text-gray-400" />
            </div>
          </div>

          {/* Title */}
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{pageTitle}</h1>
            <p className="text-xl text-gray-600">Coming Soon</p>
          </div>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Under Development
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                We're working hard to bring you this feature. This page is currently under development and will be available soon.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>What to expect:</strong> This section will provide comprehensive management tools and analytics for {pageTitle.toLowerCase()}.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progress indicator */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-500">
              <span>Development Progress</span>
              <span>25%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '25%' }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 