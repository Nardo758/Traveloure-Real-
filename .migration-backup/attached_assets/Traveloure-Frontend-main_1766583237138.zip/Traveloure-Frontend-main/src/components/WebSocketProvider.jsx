"use client"

import { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react'
import { useSession } from 'next-auth/react'

const WebSocketContext = createContext()

export const useWebSocketContext = () => {
  const context = useContext(WebSocketContext)
  if (!context) {
    throw new Error('useWebSocketContext must be used within a WebSocketProvider')
  }
  return context
}

export const WebSocketProvider = ({ children }) => {
  const { data: session } = useSession()
  const [isConnected, setIsConnected] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState('disconnected')
  const [connectionError, setConnectionError] = useState(null)
  const [userId, setUserId] = useState(null)
  const wsRef = useRef(null)
  const reconnectTimeoutRef = useRef(null)
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5
  const messageListeners = useRef(new Set())

  // Add message listener
  const addMessageListener = useCallback((listener) => {
    messageListeners.current.add(listener)
    return () => {
      messageListeners.current.delete(listener)
    }
  }, [])

  // Notify all listeners
  const notifyListeners = useCallback((message) => {
    messageListeners.current.forEach(listener => {
      try {
        listener(message)
      } catch (error) {
        console.error('🔌 WebSocket: Error in message listener:', error)
      }
    })
  }, [])

  const connect = () => {
 
    const accessToken = session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken
    const userId = session?.user?.id
    

    if (!accessToken || !userId) {
      return
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return
    }

    try {
      // Determine WebSocket protocol based on the API base URL
      const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
      const isSecure = apiBaseUrl.startsWith('https://')
      const wsProtocol = isSecure ? 'wss://' : 'ws://'
      const wsUrl = `${wsProtocol}${apiBaseUrl.replace('http://', '').replace('https://', '')}/ws/chat/${userId}/?token=${accessToken}&EIO=4&transport=websocket`
      
     
      
      wsRef.current = new WebSocket(wsUrl)
      setConnectionStatus('connecting')
      setConnectionError(null)

      wsRef.current.onopen = () => {
        setIsConnected(true)
        setConnectionStatus('connected')
        setUserId(userId)
        reconnectAttempts.current = 0
      }

      wsRef.current.onclose = (event) => {
        setIsConnected(false)
        setConnectionStatus('disconnected')
        
        // Attempt to reconnect if not a normal closure
        if (event.code !== 1000 && reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000)
          
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++
            connect()
          }, delay)
        }
      }

      wsRef.current.onerror = (error) => {
        console.error('🔌 WebSocket: Error:', error)
        console.error('🔌 WebSocket: Error details:', {
          readyState: wsRef.current?.readyState,
          url: wsRef.current?.url,
          protocol: wsRef.current?.protocol,
          apiBaseUrl: process.env.NEXT_PUBLIC_API_BASE_URL,
          fallbackUrl: 'http://localhost:8000'
        })
        setConnectionError(`WebSocket connection failed. URL: ${wsRef.current?.url}`)
        setConnectionStatus('error')
      }

      wsRef.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
        
          
          // Notify all listeners
          notifyListeners(data)
          
          // Handle different message types
          if (data.type === 'chat_message') {
            // Handle incoming chat message
          
          } else if (data.type === 'joined_chat') {
          } else if (data.type === 'send_message_response') {
          } else if (data.type === 'leave_chat_response') {
          } else if (data.type === 'message_sent') {
          
          } else if (data.type === 'notification') {
           
          } else {
          }
        } catch (error) {
        
        }
      }

    } catch (error) {
      setConnectionError(error.message)
      setConnectionStatus('error')
    }
  }

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
      reconnectTimeoutRef.current = null
    }
    
    if (wsRef.current) {
      wsRef.current.close(1000, 'Manual disconnect')
      wsRef.current = null
    }
    
    setIsConnected(false)
    setConnectionStatus('disconnected')
    setConnectionError(null)
    setUserId(null)
  }

  const sendMessage = (message) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message))
      return true
    } else {
      console.error('🔌 WebSocket: Cannot send message - not connected')
      return false
    }
  }

  const joinChat = (receiverId) => {
    const payload = {
      action: "joined_chat",
      receiver_id: receiverId
    }
    
    return sendMessage(payload)
  }

  const sendChatMessage = (receiverId, message) => {
    const payload = {
      action: "send_message",
      receiver_id: receiverId,
      message: message
    }
    
    return sendMessage(payload)
  }

  const leaveChat = (receiverId) => {
    const payload = {
      action: "leave_chat",
      receiver_id: receiverId
    }
    return sendMessage(payload)
  }

  // Connect when session is available
  useEffect(() => {
    const accessToken = session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken
    const userId = session?.user?.id
    
    if (accessToken && userId) {
      connect()
    } else {
      disconnect()
    }

    return () => {
      disconnect()
    }
  }, [session?.backendData?.accessToken, session?.backendData?.backendData?.accessToken, session?.user?.id])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect()
    }
  }, [])

  const value = {
    isConnected,
    connectionStatus,
    connectionError,
    userId,
    connect,
    disconnect,
    sendMessage,
    joinChat,
    sendChatMessage,
    leaveChat,
    addMessageListener
  }

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  )
} 