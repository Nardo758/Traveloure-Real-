export const clientRedirect = (path) => {
  if (typeof window !== "undefined") {
    window.location.href = path;
  }
};

// For server-side redirect (getServerSideProps, middleware, etc.)
export const serverRedirect = (res, path, permanent = false) => {
  res.writeHead(302, { Location: path });
  res.end();
};