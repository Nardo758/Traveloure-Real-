"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "../components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog"
import { Sheet, SheetContent, SheetTrigger } from "../components/ui/sheet"
import { cn } from "../lib/utils"
import { Menu, User, ChevronDown, ChevronRight } from "lucide-react"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useToast } from "../components/ui/use-toast"
import { useSession, signOut } from "next-auth/react"
import { useDispatch } from "react-redux"
import { getlocalexperts } from "../app/redux-features/TalktoExpert/TalktoExpert"
import { toast } from "sonner"


const schema = z.object({
  trip: z.string().min(1, "Trip destination is required"),
})

const navItems = [
  { name: "Home", href: "/" },
  {
    name: "Features",
    icon: ChevronDown,
    children: [
      { name: "Create a New Trip", href: "/Itinerary" },
      { name: "Build with an Expert", href: "/experts" },
      { name: "Help Me Decide", href: "/help-me-decide" },
    ],
  },
  { name: "Deals", href: "/deals" },
  { name: "Partner With Us", href: "/partner-with-us" },
  { name: "Contact Us", href: "/contact" },
]

const tripFormSchema = z.object({
  trip: z.string().min(2, { message: "Please enter a valid trip location." }),
})

function DealsModal({ isOpen, onClose, onSuccess, isPartnerModal,  onExpertSubmit, isSubmitting }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm({ resolver: zodResolver(schema) })

  const { toast } = useToast()

 

  // Reset form when modal closes
  useEffect(() => {
    if (!isOpen) {
      reset()
    }
  }, [isOpen, reset])

  if (isPartnerModal) {
    const router = useRouter();
    return (
      <Dialog open={isOpen} onOpenChange={onClose} className="mx-2">
        <DialogContent className="w-full max-w-sm sm:max-w-md text-center rounded-2xl px-4 sm:px-6 pt-6 pb-8">
          <DialogHeader className="mb-4">
            <DialogTitle className="text-xl font-bold text-left">Partner With Us</DialogTitle>
          </DialogHeader>
          <div className="mb-6 text-lg font-medium text-gray-700 text-left">
            Are you a travel expert or a services provider?
          </div>
          <div className="flex flex-col gap-4">
            <Button
              className="bg-[#fff] border-2 border-[#FF385C] text-[#FF385C] hover:bg-[#ffe3e8] w-full py-3 rounded-xl font-semibold"
              onClick={() => {
                onClose(false)
                router.push("/travel-experts")
              }}
            >
              Travel Expert
            </Button>
            <Button
              className="bg-[#FF385C] hover:bg-[#e23350] text-white w-full py-3 rounded-xl font-semibold"
              onClick={() => {
                onClose(false)
                router.push("/services-provider")
              }}
            >
              Services Provider
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    )
  }


}



function NestedMenuItem({ item, level = 0, onItemClick }) {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const isActive = pathname === item.href

  const handleToggle = () => setIsOpen(!isOpen)

  const handleClick = (e) => {
    if (item.isModal) {
      e.preventDefault()
      onItemClick()
    } else if (item.href === "#") {
      e.preventDefault()
    } else {
      onItemClick()
    }
  }

  return (
    <div>
      <div className="w-full">
        <div className="flex items-center justify-between w-full">
          {item.children ? (
            <Button
              onClick={handleToggle}
              className={cn(
                "flex items-center justify-between w-full text-left py-2 px-3 rounded-md transition-colors hover:bg-gray-100",
                level > 0 && "ml-4",
                isActive && "text-[#FF385C] bg-[#ffe3e8]",
                "bg-transparent text-foreground font-medium",
              )}
            >
              <span className="text-base font-medium">{item.name}</span>
              <ChevronRight className={cn("h-4 w-4 transition-transform", isOpen && "rotate-90")} />
            </Button>

          ) : item.isModal ? (
            <Button
              onClick={handleClick}
              className={cn(
                "w-full py-2 px-3 rounded-md transition-colors hover:bg-gray-100",
                level > 0 && "ml-4",
                isActive && "text-[#FF385C] bg-[#ffe3e8]",
                "bg-transparent text-foreground justify-start font-medium",
              )}
            >
              <span className="text-base font-medium">{item.name}</span>
            </Button>
          ) : (
            <Link
              href={item.href || "#"}
              onClick={handleClick}
              className={cn(
                "block w-full py-2 px-3 rounded-md transition-colors hover:bg-gray-100",
                level > 0 && "ml-4",
                isActive && "text-[#FF385C] bg-[#ffe3e8]",
              )}
            >
              <span className="text-base font-medium">{item.name}</span>
            </Link>
          )}
        </div>
        {item.children && isOpen && (
          <div className="mt-1 space-y-1">
            {item.children.map((child) => (
              <NestedMenuItem
                key={child.name}
                item={child}
                level={level + 1}
                onItemClick={onItemClick}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function DesktopDropdown({ item, isActive }) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef(null)
  const timeoutRef = useRef(null)

  const handleMouseEnter = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    setIsOpen(true)
  }

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setIsOpen(false), 150)
  }

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  return (
    <div className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave} ref={dropdownRef}>
      <button
        className={cn(
          "flex items-center text-sm font-medium px-2 transition-colors hover:text-[#FF385C]",
          isActive ? "text-[#FF385C]" : "text-muted-foreground",
        )}
        type="button"
      >
        {item.name}
        {item.icon && <item.icon className={cn("ml-1 transition-transform", isOpen ? "rotate-180" : "")} size={16} />}
      </button>

      {isOpen && item.children && (
        <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
          <div className="py-2">
            {item.children.map((child) =>
              child.isExpertModal ? (
                <button
                  key={child.name}
                  className="block w-full px-4 py-2 text-sm hover:bg-gray-50 text-left"
                  onClick={() => { setIsOpen(false); }}
                  type="button"
                >
                  {child.name}
                </button>
              ) : (
                <Link
                  key={child.name}
                  href={child.href || "#"}
                  className="block px-4 py-2 text-sm hover:bg-gray-50"
                >
                  {child.name}
                </Link>
              )
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function NestedDesktopItem({ item }) {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()
  const isActive = pathname === item.href

  return (
    <div className="relative">
      {item.children ? (
        <div className="group" onMouseEnter={() => setIsOpen(true)} onMouseLeave={() => setIsOpen(false)}>
          <div
            className={cn(
              "flex items-center justify-between px-4 py-2 text-sm hover:bg-gray-50 cursor-pointer",
              isActive && "text-[#FF385C] bg-[#ffe3e8]",
            )}
          >
            <span>{item.name}</span>
            <ChevronRight className="h-4 w-4" />
          </div>

          {isOpen && (
            <div className="absolute left-full top-0 ml-1 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
              <div className="py-2">
                {item.children.map((child) => (
                  <NestedDesktopItem key={child.name} item={child} />
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <Link
          href={item.href || "#"}
          className={cn("block px-4 py-2 text-sm hover:bg-gray-50", isActive && "text-[#FF385C] bg-[#ffe3e8]")}
        >
          {item.name}
        </Link>
      )}
    </div>
  )
}

export default function Header() {
  const pathname = usePathname()
  const router = useRouter()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isDealsModalOpen, setIsDealsModalOpen] = useState(false)
  const [isPartnerModal, setIsPartnerModal] = useState(false)

  const [showUserMenu, setShowUserMenu] = useState(false)
  const userMenuRef = useRef(null)
  const { toast } = useToast()
  const { data: session } = useSession()
  const dispatch = useDispatch()

  const isLoggedIn = session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(tripFormSchema),
  })

  const handleDealsClick = (e) => {
    if (e) {
      e.preventDefault()
    }
    setIsDealsModalOpen(true)
  }



  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    if (!showUserMenu) return
    const handleClickOutside = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setShowUserMenu(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [showUserMenu])

  const handleLogout = () => {
    setShowUserMenu(false)
    // Dispatch logout event to prevent toast errors in protected routes
    window.dispatchEvent(new CustomEvent('logout'))
    
    // Use a small delay to ensure all cleanup is done before signOut
    setTimeout(() => {
      signOut({ callbackUrl: "/" })
    }, 50)
  }

  // Add a dummy function to avoid ReferenceError if needed
  const handleFormSuccess = () => {}



  return (
    <>
      <DealsModal 
        isOpen={isDealsModalOpen} 
        onClose={setIsDealsModalOpen} 
        onSuccess={handleFormSuccess} 
        isPartnerModal={isPartnerModal}
      />

      <header className={cn("sticky top-0 z-[60] w-full bg-white py-4 shadow-sm", isScrolled && "shadow-md")}>
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Image src="/Main-logo.png" alt="Main Logo" width={150} height={50} />
            <span className="ml-2 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white shadow-lg border-2 border-orange-300 animate-pulse">
              <span className="mr-1">🚀</span>
              BETA
            </span>
          </Link>

          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item, index) => {
              const isActive = pathname === item.href
              const isLast = index === navItems.length - 1

              return (
                <div key={item.name} className="relative flex items-center">
                  <div className="flex flex-col items-center h-full">
                    <div className="h-5">
                      {item.isModal ? (
                        <button
                          onClick={handleDealsClick}
                          className={cn(
                            "flex items-center text-sm font-medium px-2 transition-colors hover:text-[#FF385C] bg-transparent border-none cursor-pointer",
                            isActive ? "text-[#FF385C]" : "text-muted-foreground",
                          )}
                        >
                          {item.name}
                        </button>
                      ) : item.children ? (
                        <DesktopDropdown item={item} isActive={isActive}/>
                      ) : item.isExpertModal ? (
                        <button
                     
                          className={cn(
                            "flex items-center text-sm font-medium px-2 transition-colors hover:text-[#FF385C] bg-transparent border-none cursor-pointer",
                            isActive ? "text-[#FF385C]" : "text-muted-foreground",
                          )}
                          type="button"
                        >
                          {item.name}
                        </button>
                      ) : (
                        <Link
                          href={item.href}
                          className={cn(
                            "flex items-center text-sm font-medium px-2 transition-colors hover:text-[#FF385C]",
                            isActive ? "text-[#FF385C]" : "text-muted-foreground",
                          )}
                        >
                          {item.name}
                        </Link>
                      )}
                    </div>
                    <div className="h-1">
                      {isActive && (
                        <div className="flex space-x-1">
                          <div className="h-1 w-1 rounded-full bg-[#FF385C]"></div>
                          <div className="h-1 w-1 rounded-full bg-[#FF385C]"></div>
                          <div className="h-1 w-1 rounded-full bg-[#FF385C]"></div>
                        </div>
                      )}
                    </div>
                  </div>
                  {!isLast && <div className="h-5 w-[1px] bg-gray-300 mx-4"></div>}
                </div>
              )
            })}
          </nav>

          <div className="hidden lg:flex items-center space-x-3">
            {!isLoggedIn ? (
              <>
             
                <Button
                  variant="outline"
                  size="sm"
                  className="border-2 border-[#FF385C] text-[#FF385C] rounded-[10px] px-5 py-2 hover:bg-[#ffe3e8]"
                  onClick={() => router.push("/login")}
                >
                  <User className="w-4 h-4 mr-2" />
                  Login
                </Button>
                <Button
                  size="sm"
                  className="bg-[#FF385C] hover:bg-[#e23350] text-white rounded-[10px] px-5 py-2"
                  onClick={() => router.push("/signup")}
                >
                  Sign Up
                </Button>
              </>
            ) : (
              <div className="relative">
                <Button
                  variant="outline"
                  size="icon"
                  className=" border-2 border-[#FF385C] text-[#FF385C]"
                  onClick={() => setShowUserMenu((prev) => !prev)}
                >
                  <Menu className="h-6 w-6" />
                </Button>
                {showUserMenu && (
                  <div
                    ref={userMenuRef}
                    className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50"
                  >
                    <Button
                      variant="ghost"
                      className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                      onClick={() => {
                        setShowUserMenu(false)
                        router.push("/dashboard/profile")
                      }}
                    >
                    User Profile
                    </Button>
                    <Button
                      variant="ghost"
                      className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                      onClick={handleLogout}
                    >
                      Logout
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>

          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="flex flex-col w-80">
              <div className="flex flex-col space-y-6 mt-6 w-full">
                <Link href="/" className="flex items-center justify-center">
                  <Image src="/Main-logo.png" alt="Main Logo" width={150} height={50} />
                </Link>
                <div className="space-y-2">
                  {navItems.map((item) => (
                    <NestedMenuItem
                      key={item.name}
                      item={item}
                      onItemClick={() => setIsMobileMenuOpen(false)}
             
                    />
                  ))}
                </div>
                <div className="mt-6 flex flex-col gap-3 px-3">
                  {!isLoggedIn ? (
                    <>
                      <Button
                        variant="outline"
                        className="border-2 border-[#FF385C] text-[#FF385C] rounded-[10px] w-full"
                        onClick={() => {
                          router.push("/login")
                          setIsMobileMenuOpen(false)
                        }}
                      >
                        <User className="w-4 h-4 mr-2" />
                        Login
                      </Button>
                      <Button
                        className="bg-[#FF385C] hover:bg-[#e23350] text-white rounded-[10px] w-full"
                        onClick={() => {
                          router.push("/signup")
                          setIsMobileMenuOpen(false)
                        }}
                      >
                        Sign Up
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        variant="ghost"
                        className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                        onClick={() => {
                          setIsMobileMenuOpen(false)
                          router.push("/dashboard/profile")
                        }}
                      >
                       User Profile
                      </Button>
                      <Button
                        variant="ghost"
                        className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                        onClick={() => {
                          setIsMobileMenuOpen(false)
                          handleLogout()
                        }}
                      >
                        Logout
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>
   
    </>
  )
}