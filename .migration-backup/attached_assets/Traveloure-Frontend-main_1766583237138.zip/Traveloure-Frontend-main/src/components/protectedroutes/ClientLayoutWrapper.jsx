// src/components/ClientLayoutWrapper.jsx
"use client";

import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";
import ProtectedRoute from "./ProtectedRoutes";

export default function ClientLayoutWrapper({ children }) {
  const pathname = usePathname();
  const previousPathRef = useRef(pathname);

  const publicRoutes = ["/login", "/signup", "/", "/ai-optimization"]; // add more as needed
  const adminRoutes = ["/admin"]; // admin routes should bypass protection
  const isPublic = publicRoutes.some((route) => pathname.startsWith(route));
  const isAdmin = adminRoutes.some((route) => pathname.startsWith(route));
  
  // Only log in development
  if (process.env.NODE_ENV === 'development') {
    console.log('[ClientLayoutWrapper] pathname:', pathname, 'isPublic:', isPublic, 'isAdmin:', isAdmin);
  }

  // TEMP: Remove all protection for debugging
  // return <>{children}</>;

  // Global cleanup for help-me-decide localStorage items
  useEffect(() => {
    const currentPath = pathname;
    const previousPath = previousPathRef.current;

    // Check if we're navigating away from help-me-decide
    const wasInHelpMeDecide = previousPath.startsWith('/help-me-decide');
    const isInHelpMeDecide = currentPath.startsWith('/help-me-decide');

    // If we were in help-me-decide but now we're not, clean up localStorage
    if (wasInHelpMeDecide && !isInHelpMeDecide) {
      // Only log in development
      if (process.env.NODE_ENV === 'development') {
        console.log('Global cleanup: Cleaning up help-me-decide localStorage items');
      }
      
      // Remove all help-me-decide related localStorage items
      const itemsToRemove = [
        'savedActivities',
        'savedPlaces',
        'savedActivities'
      ];

      itemsToRemove.forEach(item => {
        if (localStorage.getItem(item)) {
          localStorage.removeItem(item);
          if (process.env.NODE_ENV === 'development') {
            console.log(`Global cleanup: Removed ${item} from localStorage`);
          }
        }
      });

      // Dispatch custom events to notify other components about the cleanup
      window.dispatchEvent(new CustomEvent('helpMeDecideCleanup', {
        detail: { 
          action: 'cleanup',
          removedItems: itemsToRemove,
          fromPath: previousPath,
          toPath: currentPath,
          source: 'global'
        }
      }));
    }

    // Update the previous path reference
    previousPathRef.current = currentPath;
  }, [pathname]);

  if (isPublic || isAdmin) {
    return <>{children}</>;
  }

  return <ProtectedRoute>{children}</ProtectedRoute>;
}
