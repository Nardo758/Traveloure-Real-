"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

const allowPublicPaths = [
  "/verify-email",
  "/Itinerary",
  "/help-me-decide",
  "/forgot-password",
  "/reset-password",
  "/deals",
  "/experts",
  "/token-callback",
  "/debug",
  "/partner-with-us",
  "/ai-optimization"
];

export default function ProtectedRoute({ children }) {
  const router = useRouter();
  const { data: session, status } = useSession();
  const token = session?.backendData?.accessToken || (typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null);

  useEffect(() => {
    const currentPath = window.location.pathname;
    const isAllowed = allowPublicPaths.some((path) => currentPath.startsWith(path));
    
    // Only log in development
    if (process.env.NODE_ENV === 'development') {
      console.log('[ProtectedRoutes] currentPath:', currentPath, 'status:', status, 'hasSession:', !!session, 'hasToken:', !!token, 'isAllowed:', isAllowed);
    }

    // TEMP: Remove all protection for debugging
    // return <>{children}</>;

    if (isAllowed) return;

    if (status === "loading") return;

    if (status === "unauthenticated" || !token) {
      router.push("/");
    }
  }, [router, status, session?.backendData?.accessToken, token]); // More specific dependencies

  return <>{children}</>;
}
