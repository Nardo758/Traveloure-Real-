"use client"

import { Paperclip, FileImage, Download } from "lucide-react"

export function ImageAttachmentPlayer({ 
  attachment, 
  isOutgoing 
}) {
  // Handle both API URLs and file objects
  const getImageUrl = () => {
    if (!attachment) {
      return null
    }
    
    if (typeof attachment === 'string') {
      return attachment.startsWith('http') 
        ? attachment 
        : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment}`
    } else if (attachment instanceof File || attachment instanceof Blob) {
      return URL.createObjectURL(attachment)
    } else {
      // Handle case where attachment is an object but not a File/Blob
      // Try to extract URL from the object
      if (attachment.url) {
        return attachment.url.startsWith('http') 
          ? attachment.url 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.url}`
      } else if (attachment.attachment) {
        return attachment.attachment.startsWith('http') 
          ? attachment.attachment 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.attachment}`
      }
      return null
    }
  }

  const imageUrl = getImageUrl()
  
  // Don't render if no valid URL
  if (!imageUrl) {
    return null
  }

  return (
    <div className="mt-2">
      <div className={`flex items-center gap-3 p-3 rounded-lg border ${
        isOutgoing 
          ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-opacity-10 border-pink-200' 
          : 'bg-gray-50 border-gray-200'
      }`}>
        <div className={`p-2 rounded-lg ${
          isOutgoing 
            ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] text-white' 
            : 'bg-white text-gray-600 border border-gray-200'
        }`}>
          <FileImage className="w-4 h-4" />
        </div>
        
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium ${
            isOutgoing ? 'text-white' : 'text-gray-900'
          }`}>
            Image file
          </p>
        </div>
        
        <a 
          href={imageUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className={`p-1.5 rounded-md transition-colors ${
            isOutgoing 
              ? 'text-white hover:bg-white hover:text-[#F30131]' 
              : 'text-gray-500 hover:bg-gray-200'
          }`}
          title="Download image"
        >
          <Download className="w-3.5 h-3.5" />
        </a>
      </div>
      
      {/* Image preview */}
      <div className="mt-2">
        <img 
          src={imageUrl} 
          alt="Attachment" 
          className="max-w-full h-auto rounded-lg max-h-32 object-cover"
          onError={(e) => {
            e.target.style.display = 'none'
          }}
        />
      </div>
    </div>
  )
}
