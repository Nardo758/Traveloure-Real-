"use client";

import { useState, useEffect, useMemo } from "react";
import { MapPin, Search, ChevronDown, Check, Plus, ExternalLink } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import Image from "next/image";
import { toast } from "sonner";
import { useSelector } from "react-redux";

export default function HotelsContent({ hotelData }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [displayedHotels, setDisplayedHotels] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [selectedHotels, setSelectedHotels] = useState([]);
  const hotelsPerPage = 3;
  const HotelData = useSelector((state) => state?.itinerary?.tripDetailData)
  const alldata = HotelData || hotelData || [];
  
  useEffect(() => {
    const savedHotels = localStorage.getItem("selectedHotels");
    if (savedHotels) {
      try {
        setSelectedHotels(JSON.parse(savedHotels));
      } catch (e) {
        console.error("Error parsing saved hotels:", e);
        localStorage.removeItem("selectedHotels");
      }
    }
  }, []);

  const filteredHotels = useMemo(() => {
    return (
      alldata?.hotels?.filter(
        (hotel) => {
          const hotelName = hotel.name || hotel.title || '';
          const hotelAddress = hotel.address || '';
          return hotelName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                 hotelAddress.toLowerCase().includes(searchTerm.toLowerCase());
        }
      ) || []
    );
  }, [alldata?.hotels, searchTerm]);

  useEffect(() => {
    setDisplayedHotels(filteredHotels.slice(0, page * hotelsPerPage));
  }, [filteredHotels, page]);

  useEffect(() => {
    setPage(1);
  }, [searchTerm]);

  const loadMore = () => {
    setLoading(true);
    setTimeout(() => {
      setPage((prev) => prev + 1);
      setLoading(false);
    }, 500);
  };

  const hasMoreHotels = displayedHotels.length < filteredHotels.length;

  const isHotelSelected = (hotelId) =>
    selectedHotels.some((hotel) => (hotel.name || hotel.title) === hotelId);

  const handleToggleHotel = (hotel) => {
    let newSelectedHotels = [];
    const hotelName = hotel.name || hotel.title || 'Hotel';

    if (isHotelSelected(hotelName)) {
      newSelectedHotels = selectedHotels.filter((h) => (h.name || h.title) !== hotelName);
      toast.success(`${hotelName} removed from selection`);
    } else {
      newSelectedHotels = [...selectedHotels, hotel];
      toast.success(`${hotelName} added to selection`);
    }

    setSelectedHotels(newSelectedHotels);
    localStorage.setItem("hotels", JSON.stringify(newSelectedHotels));

    if (alldata?.trip_id) {
      localStorage.setItem("trip_id", alldata.trip_id);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h2 className="text-2xl font-bold">Book Hotels</h2>
        <div className="relative w-full md:max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search booking platforms..."
            className="pl-10 rounded-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Hotels List */}
      <div className="flex flex-col gap-6">
        {displayedHotels.length > 0 ? (
          <>
            {displayedHotels.map((hotel) => {
              const hotelName = hotel.name || hotel.title || 'Hotel';
              const hotelImage = hotel.thumbnail || hotel.image_url || "/placeholder.svg?height=200&width=300";
              const hotelPrice = hotel.price || '';
              const hotelReviews = hotel.reviews || 0;
              const hotelRating = hotel.rating || '';
              
              return (
                <div key={hotelName} className="border rounded-lg overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="w-full md:w-64 h-48 md:h-auto relative">
                      <Image
                        src={hotelImage}
                        alt={hotelName}
                        fill
                        className="object-cover"
                        unoptimized={hotelImage.startsWith('http')}
                      />
                    </div>

                    <div className="flex-1 p-4">
                      <div className="flex flex-col md:flex-row justify-between">
                        <div>
                          <h3 className="text-xl font-bold">{hotelName}</h3>
                          {hotel.address && (
                            <div className="flex items-center text-sm text-muted-foreground mt-1">
                              <MapPin className="h-4 w-4 mr-1" />
                              {hotel.address}
                            </div>
                          )}
                          <div className="flex items-center gap-2 mt-2">
                            {hotelPrice && (
                              <Badge variant="outline" className="text-xs">
                                {hotelPrice}
                              </Badge>
                            )}
                            {hotelRating && (
                              <Badge variant="outline" className="text-xs">
                                ⭐ {hotelRating}
                              </Badge>
                            )}
                            {hotelReviews > 0 && (
                              <span className="text-xs text-muted-foreground">
                                ({hotelReviews} reviews)
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mt-4">
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            className={`${isHotelSelected(hotelName)
                                ? "bg-green-600 hover:bg-green-700"
                                : "bg-[#FF385C] hover:bg-red-600"
                              } text-white rounded-full px-6`}
                            onClick={() => handleToggleHotel(hotel)}
                          >
                            {isHotelSelected(hotelName) ? (
                              <span className="flex items-center">
                                <Check className="h-4 w-4 mr-1" /> Selected
                              </span>
                            ) : (
                              <>
                                <Plus /> Add
                              </>
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-[#FF385C] border-[#FF385C] hover:bg-red-100 rounded-full px-6"
                            onClick={() => {
                              const link = hotel.affiliate_link || hotel.booking_url;
                              if (link) {
                                window.open(link, "_blank");
                              } else {
                                console.warn("No booking link available");
                              }
                            }}
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            Visit Platform
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Load More */}
            {hasMoreHotels && (
              <div className="flex justify-center mt-4">
                <Button
                  onClick={loadMore}
                  variant="outline"
                  className="rounded-full border-[#FF385C] text-[#FF385C] hover:bg-red-50"
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-[#FF385C] border-t-transparent rounded-full animate-spin mr-2" />
                      Loading...
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <span>Load More Platforms</span>
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </div>
                  )}
                </Button>
              </div>
            )}
          </>
        ) : searchTerm ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No booking platforms match your search criteria.</p>
            <Button
              onClick={() => setSearchTerm("")}
              variant="outline"
              className="mt-4 rounded-full border-[#FF385C] text-[#FF385C] hover:bg-red-50"
            >
              Clear Search
            </Button>
          </div>
        ) : alldata?.hotels ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No booking platforms available for this destination.</p>
          </div>
        ) : (
          <div className="flex items-center justify-center bg-[#FF385C] text-white rounded-lg p-4 max-w-[400px] mx-auto mt-4 shadow-lg space-x-3">
            <p className="font-semibold text-lg">You need to fill in the trip detail box first.</p>
          </div>
        )}
      </div>
    </div>
  );
}
