"use client"

import { useState, useEffect } from "react"
import { X, Rocket } from "lucide-react"
import { useRouter } from "next/navigation"
import { Button } from "./ui/button"

export default function BetaBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const router = useRouter()

  // Cities and countries from the goals list
  const markets = [
    "Mumbai- India",
    "Bogota- Colombia", 
    "Gao- India",
    "Kyoto- Japan",
    "Edinburgh- UK"
  ]

  useEffect(() => {
    // Check if banner was dismissed
    const dismissed = localStorage.getItem("betaBannerDismissed")
    if (!dismissed) {
      setIsVisible(true)
    }
  }, [])

  const handleDismiss = () => {
    setIsVisible(false)
    localStorage.setItem("betaBannerDismissed", "true")
  }

  const handleApplyNow = () => {
    router.push("/partner-with-us")
  }

  if (!isVisible) return null

  return (
    <div className="w-full bg-gradient-to-r from-orange-500 via-orange-400 to-red-500 text-white relative z-40">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Left Side - Icon and Text */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <Rocket className="h-5 w-5 text-blue-300 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm md:text-base whitespace-nowrap">
                  Join Our Beta Launch in 8 Cities Worldwide
                </span>
                <span className="text-xs md:text-sm opacity-90 whitespace-nowrap">
                  • Limited Expert Spots Available
                </span>
              </div>
              {/* First 5 Markets */}
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className="text-xs opacity-80">Launching in:</span>
                {markets.map((market, index) => (
                  <span key={market} className="text-xs font-medium">
                    {market}
                    {index < markets.length - 1 && <span className="opacity-60">,</span>}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Side - Apply Button and Close */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <Button
              onClick={handleApplyNow}
              className="bg-white text-orange-600 hover:bg-gray-100 font-medium px-4 py-1.5 text-sm rounded-md whitespace-nowrap"
            >
              Apply Now →
            </Button>
            <button
              onClick={handleDismiss}
              className="p-1 hover:bg-white/20 rounded-full transition-colors flex-shrink-0"
              aria-label="Close banner"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

