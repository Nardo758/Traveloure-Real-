import Image from "next/image"
import { Bell, Paperclip, Mic, Send, ArrowLeft } from "lucide-react"
import { TbContract } from "react-icons/tb"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { AttachmentDisplay } from "./AttachmentDisplay"
import { StickerPicker } from "./StickerPicker"
import ContractMessage from "./ContractMessage"
import ItineraryMessage from "./ItineraryMessage"

export const ChatInterface = ({
  selectedExpert,
  isConnected,
  messages,
  chatMessage,
  selectedFile,
  showStickers,
  recordingState,
  contractStatusData,
  showContract,
  onCloseChat,
  onSendMessage,
  onFileSelect,
  onKeyPress,
  onStickerSelect,
  onStartRecording,
  onStopRecording,
  onSendVoiceMessage,
  onCancelVoiceMessage,
  onContractModal,
  onContractAccept,
  onContractReject,
  onContractPay,
  onItineraryApprove,
  onItineraryRequestEdit,
  onChatMessageChange,
  formatTime,
  getDisplayName,
  getExpertData
}) => {
  return (
    <div className="flex flex-col h-[600px] bg-white border border-gray-200 rounded-lg shadow-sm">
      {/* Chat Header */}
      <div className="flex items-center justify-between p-3 sm:p-4 border-b border-gray-200">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
          <button
            onClick={onCloseChat}
            className="p-1.5 sm:p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-600 flex-shrink-0"
          >
            <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            <Image
              src={getExpertData(selectedExpert).image}
              alt={getDisplayName(selectedExpert)}
              width={40}
              height={40}
              className="rounded-full object-cover w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0"
            />
            <div className="min-w-0 flex-1">
              <h2 className="font-semibold text-gray-900 text-sm sm:text-base truncate">
                {getDisplayName(selectedExpert)}
              </h2>
              <div className="flex items-center gap-1 sm:gap-2 mt-1">
                <div className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className="text-xs sm:text-sm text-gray-600 truncate">
                  {isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <Bell className="w-5 h-5" />
          </button>
          {/* Show Send Contract button only if showContract is true */}
          {showContract && (
            <>
              <div className="hidden sm:block">
                <Button
                  onClick={() => onContractModal(selectedExpert)}
                  className="bg-[#FF385C] hover:bg-[#e23350] text-white px-4 py-2 rounded-lg text-sm font-medium"
                >
                  Send Contract
                </Button>
              </div>
              <div className="sm:hidden">
                <Button
                  onClick={() => onContractModal(selectedExpert)}
                  className="bg-[#FF385C] hover:bg-[#e23350] text-white p-2 rounded-lg"
                  title="Send Contract"
                >
                  <TbContract className="w-5 h-5" />
                </Button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        <div className="space-y-4">
          {/* Date Separator */}
          <div className="flex justify-center">
            <span className="text-sm text-gray-400 bg-white px-3 py-1 rounded-full shadow-sm">Today</span>
          </div>

          {/* Messages */}
          {messages.map((message, index) => {
            const isOutgoingMessage = message.type === 'sent' || message.sender === 'user'


            return (
              <div key={message.id}>
                {(message.isContract || message.contract) ? (
                  (() => {
                    const contractData = {
                      ...(message.contract || message),
                      title: message.contract?.contract_title || message.contract_title,
                      status: message.contract?.status || null,
                      is_accepted: message.contract?.is_accepted || false,
                      is_paid: message.contract?.is_paid || false,
                      payment_url: message.contract?.payment_url || null
                    }

                    return (
                      <ContractMessage
                        contract={contractData}
                        onAccept={(id) => onContractAccept(id, 'accept')}
                        onReject={(id) => onContractReject(id, 'reject')}
                        onPay={onContractPay}
                        isOwnMessage={isOutgoingMessage}
                      />
                    )
                  })()
                ) : (message.isItinerary || message.itinerary) ? (
                  (() => {
                    const itineraryData = message.itinerary || message
                    const processedItinerary = {
                      id: itineraryData.id,
                      title: itineraryData.title,
                      description: itineraryData.description,
                      location: itineraryData.location,
                      status: itineraryData.status || 'pending',
                      attachment: itineraryData.attachment,
                      created_at: itineraryData.created_at || message.timestamp,
                      receiver: itineraryData.receiver,
                      sender: itineraryData.sender
                    }
                    return (
                      <ItineraryMessage
                        itinerary={processedItinerary}
                        onApprove={(id) => onItineraryApprove(id, 'approve')}
                        onRequestEdit={(id) => onItineraryRequestEdit(id, 'requestEdit')}
                        isOwnMessage={isOutgoingMessage}
                      />
                    )
                  })()
                ) : (
                  <div
                    className={`flex ${isOutgoingMessage ? 'justify-end' : 'justify-start'} mb-3 sm:mb-4`}
                  >
                    <div className={`max-w-[85%] sm:max-w-[70%] ${isOutgoingMessage ? 'text-right' : 'text-left'}`}>
                      <div className={`rounded-lg px-3 py-2 shadow-sm ${isOutgoingMessage
                        ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] text-white'
                        : 'bg-white border border-gray-200'
                        }`}>
                        <p className="text-sm break-words">{message.content}</p>

                        {/* Display attachment using common component */}
                        <AttachmentDisplay
                          message={message}
                          attachment={message.attachment}
                          messageId={message.id}
                          index={index}
                          isOutgoing={isOutgoingMessage}
                        />
                      </div>
                      <p className={`text-xs text-gray-500 mt-1 ${isOutgoingMessage ? 'text-right' : 'text-left'
                        }`}>
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Message Input */}
      <div className="p-3 sm:p-4 border-t border-gray-200">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* File Upload Button */}
          <label className={`p-1.5 sm:p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0 cursor-pointer ${selectedFile ? 'text-pink-500 bg-pink-50' : 'text-gray-400'
            }`}>
            <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
            <input
              key={selectedFile ? 'file-selected' : 'file-empty'}
              type="file"
              className="hidden"
              onChange={onFileSelect}
              accept="image/*,.pdf,.doc,.docx,video/*"
              onClick={(e) => {
                e.target.value = ''
              }}
            />
          </label>

          {/* Sticker Button */}
          <button
            onClick={() => onStickerSelect('toggle')}
            className={`p-1.5 sm:p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0 ${showStickers ? 'text-pink-500 bg-pink-50' : 'text-gray-400'
              }`}
            title="Stickers"
          >
            <span className="text-sm sm:text-base">😀</span>
          </button>

          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type your message here"
              value={chatMessage}
              onChange={(e) => onChatMessageChange(e.target.value)}
              onKeyPress={onKeyPress}
              className="w-full border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 pr-10 sm:pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white"
            />
            {/* Microphone Button */}
            <button
              onClick={onStartRecording}
              disabled={recordingState.isRecording}
              className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full transition-colors text-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Voice message"
            >
              <Mic className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>

          {/* Send Button */}
          <button
            onClick={onSendMessage}
            disabled={(!chatMessage.trim() && !selectedFile) || !isConnected}
            className="bg-gradient-to-r from-[#F30131] to-[#BE35EB] hover:opacity-90 text-white p-2 sm:p-3 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
            title="Send message"
          >
            <Send className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Voice Message Controls */}
        {recordingState.isRecording && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-red-700">
                  Recording... {Math.floor(recordingState.time / 60)}:{(recordingState.time % 60).toString().padStart(2, '0')}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={onStopRecording}
                  className="px-3 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600"
                >
                  Stop
                </button>
                <button
                  onClick={onCancelVoiceMessage}
                  className="px-3 py-1 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Voice Message Preview */}
        {recordingState.blob && !recordingState.isRecording && (
          <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Mic className="w-5 h-5 text-blue-600" />
                <span className="text-sm text-blue-700">
                  Voice message ({Math.floor(recordingState.time / 60)}:{(recordingState.time % 60).toString().padStart(2, '0')})
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={onSendVoiceMessage}
                  className="px-3 py-1 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600"
                >
                  Send
                </button>
                <button
                  onClick={onCancelVoiceMessage}
                  className="px-3 py-1 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Sticker Picker */}
        {showStickers && (
          <StickerPicker
            onStickerSelect={onStickerSelect}
            onClose={() => onStickerSelect('close')}
          />
        )}

        {/* Selected file indicator */}
        {selectedFile && (
          <div className="mt-2 flex items-center gap-2 text-sm text-gray-600">
            <Paperclip className="w-4 h-4" />
            <span>{selectedFile.name}</span>
            <button
              onClick={() => onFileSelect({ target: { files: [] } })}
              className="text-red-500 hover:text-red-700"
            >
              ×
            </button>
          </div>
        )}
      </div>
    </div>
  )
} 