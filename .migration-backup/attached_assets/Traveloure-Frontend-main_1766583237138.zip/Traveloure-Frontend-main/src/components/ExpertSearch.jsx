import { useState, useCallback, useMemo } from 'react'
import { Search } from 'lucide-react'
import { Button } from './ui/button'
import { ExpertCard } from './ExpertCard'

// Static fallback data for missing API fields
const staticExpertData = {
  rating: "4.8/5.0",
  reviews: 650,
  languages: ["English", "French", "Spanish"],
  countries: ["Italy", "France", "Spain", "Britain"],
  specialization: "Specializing in Coastal Adventures and Hidden Gems",
  image: "/dealperson.png",
}

export const ExpertSearch = ({
  Expertlist,
  loading,
  error,
  isConnected,
  onOpenChat,
  onContractModal,
  onSearch,
  onClearSearch,
  dispatch,
  session
}) => {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchLoading, setSearchLoading] = useState(false)

  // Helper functions for expert data
  const getDisplayName = useCallback((expert) => {
    if (expert.first_name && expert.last_name) {
      return `${expert.first_name} ${expert.last_name}`
    } else if (expert.first_name) {
      return expert.first_name
    } else if (expert.username) {
      return expert.username
    }
    return "Unknown Expert"
  }, [])

  // Consolidated helper functions
  const getExpertData = useCallback((expert) => {
    const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1)
    
    return {
      rating: expert.average_rating > 0 ? `${expert.average_rating.toFixed(1)}/5.0` : staticExpertData.rating,
      reviews: expert.reviews?.length || staticExpertData.reviews,
      countries: expert.country ? [expert.country] : staticExpertData.countries,
      specialization: expert.travel_style?.length 
        ? `Specializing in ${expert.travel_style.map(capitalize).join(", ")}`
        : staticExpertData.specialization,
      image: expert.image || expert.cover_image || staticExpertData.image,
      preferredMonths: expert.preferred_months?.length 
        ? `Preferred: ${expert.preferred_months.map(capitalize).join(", ")}`
        : ""
    }
  }, [])

  // Memoized filtered experts list
  const filteredExperts = useMemo(() => {
    if (!searchQuery.trim()) return Expertlist || []

    const query = searchQuery.toLowerCase()
    return (Expertlist || []).filter(expert => {
      const name = getDisplayName(expert).toLowerCase()
      const username = (expert.username || '').toLowerCase()
      const country = (expert.country || '').toLowerCase()
      const specialization = (expert.specialization || '').toLowerCase()

      return name.includes(query) ||
        username.includes(query) ||
        country.includes(query) ||
        specialization.includes(query)
    })
  }, [Expertlist, searchQuery, getDisplayName])

  // Handle search functionality
  const handleSearch = useCallback(async () => {
    if (!session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
      return
    }

    setSearchLoading(true)
    try {
      await dispatch(onSearch({ token: session.backendData.accessToken, query: searchQuery })).unwrap()
    } catch (error) {
      // Removed console logs for performance optimization
    } finally {
      setSearchLoading(false)
    }
  }, [session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken, dispatch, onSearch, searchQuery])

  // Handle search on Enter key press
  const handleSearchKeyPress = useCallback((e) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }, [handleSearch])

  // Handle clear search
  const handleClearSearch = useCallback(() => {
    setSearchQuery("")
    if (session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken) {
      dispatch(onSearch({ token: session.backendData.accessToken, query: "" }))
    }
  }, [session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken, dispatch, onSearch])

  return (
    <div className="space-y-6">
      {/* Search Box */}
      <div className="mb-8">
        <div className="max-w-md mx-auto md:mx-0">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by country name"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleSearchKeyPress}
              className="block w-full pl-10 pr-20 py-3 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-pink-500 focus:border-pink-500 text-sm"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-2">
              {searchQuery && (
                <button
                  onClick={handleClearSearch}
                  className="p-1 hover:bg-gray-100 rounded-full transition-colors text-gray-400 mr-2"
                  title="Clear search"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
              <Button
                onClick={handleSearch}
                disabled={searchLoading}
                className="bg-[#FF385C] hover:bg-[#e23350] text-white px-4 py-1 text-sm rounded-md disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {searchLoading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  'Search'
                )}
              </Button>
            </div>
          </div>
          {searchQuery && (
            <p className="text-xs text-gray-500 mt-2 text-center md:text-left">
              Searching for experts in: <span className="font-medium text-[#FF385C]">{searchQuery}</span>
            </p>
          )}
        </div>
      </div>

      <p className="text-sm text-muted-foreground text-center md:text-left mb-10">
        {searchQuery
          ? `Showing experts for ${searchQuery}`
          : 'Based on your trip details and Preferences, Here are the best matches'
        }
      </p>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500"></div>
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="text-center py-12">
          <p className="text-red-500 mb-4">{error}</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              onClick={() => dispatch(onSearch({ token: session?.backendData?.accessToken || session?.backendData?.backendData?.accessToken, query: searchQuery }))}
              className="bg-[#FF385C] hover:bg-[#e23350] text-white"
            >
              Try Again
            </Button>
            {searchQuery && (
              <Button
                onClick={handleClearSearch}
                variant="outline"
                className="border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Clear Search
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Experts Grid */}
      {!loading && !error && filteredExperts && filteredExperts?.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredExperts?.map((expert, idx) => (
            <ExpertCard
              key={expert.id || idx}
              expert={expert}
              idx={idx}
              isConnected={isConnected}
              onOpenChat={onOpenChat}
              onContractModal={onContractModal}
              getDisplayName={getDisplayName}
              getExpertData={getExpertData}
            />
          ))}
        </div>
      ) : !loading && !error && (!filteredExperts || filteredExperts.length === 0) ? (
        <div className="text-center py-12">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchQuery ? `No experts found for "${searchQuery}"` : 'No experts found'}
            </h3>
            <p className="text-gray-500 text-sm mb-4">
              {searchQuery
                ? `Try searching for a different country or clear your search to see all experts.`
                : 'No travel experts are currently available.'
              }
            </p>
            {searchQuery && (
              <Button
                onClick={handleClearSearch}
                className="bg-[#FF385C] hover:bg-[#e23350] text-white"
              >
                Clear Search
              </Button>
            )}
          </div>
        </div>
      ) : null}
    </div>
  )
}


