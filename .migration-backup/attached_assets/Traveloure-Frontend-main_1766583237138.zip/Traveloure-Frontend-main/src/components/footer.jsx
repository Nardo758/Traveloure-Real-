import Link from "next/link"
import Image from "next/image"
import { Youtube, Facebook, Instagram, Linkedin } from "lucide-react"
import footerIcon from "../../public/footer-icon.png"

export default function Footer() {
  return (
    <footer className="bg-[#192100] text-white w-full">
      {/* Top Banner */}
      <div className="w-full relative px-4 py-16 flex flex-col md:flex-row justify-between items-center container mx-auto">
        <div className="max-w-lg mb-6 md:mb-0 ">
          <h2 className="text-2xl md:text-3xl font-bold leading-tight text-center md:text-left">
            Start Your Thrilling Nature Filled Adventure Today
          </h2>
        </div>
        <div className=" w-full md:w-auto flex items-center justify-center md:justify-end">
          <Image
            src="/footer-icon2.png"
            alt="Curved line"
            width={442}
            height={70}
            className="absolute hidden md:block  pointer-events-none"
            style={{
              position: "absolute",
              top: "50%",
              right: "195px",
              transform: "translateY(-50%)",
            }}
          />
          <Link
            href="/contact"
            className="bg-white text-[#192100] px-6 py-3 rounded-md font-medium hover:bg-opacity-90 transition relative z-10"
          >
            Get In Touch
          </Link>
        </div>
      </div>

      {/* Main Footer */}
      <div className="border-t border-[#2a3200]">
        <div className="w-full px-4 py-8 flex flex-col md:flex-row justify-between items-center container mx-auto">
          {/* Logo */}
          <Link href="/" className="mb-6 md:mb-0 ">
            <Image src={footerIcon || "/placeholder.svg"} alt="Traveloure" className="w-[180px]" />
          </Link>

          {/* Navigation */}
          <nav className="flex flex-wrap justify-center gap-4 md:gap-8 mb-6 md:mb-0">
            <Link href="/features" className="text-white hover:text-gray-300 transition">
              Features
            </Link>
            <Link href="/deals" className="text-white hover:text-gray-300 transition">
              Deals
            </Link>
            <Link href="/about" className="text-white hover:text-gray-300 transition">
              About Us
            </Link>
            <Link href="/expert" className="text-white hover:text-gray-300 transition">
              Talk to Expert
            </Link>
          </nav>

          {/* Social Icons */}
          <div className="flex items-center space-x-4 ">
            <Link href="#" className="text-white hover:text-gray-300 transition">
              <Youtube className="w-5 h-5" />
              <span className="sr-only">Youtube</span>
            </Link>
            <Link href="#" className="text-white hover:text-gray-300 transition">
              <Facebook className="w-5 h-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link href="#" className="text-white hover:text-gray-300 transition">
              <Instagram className="w-5 h-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="#" className="text-white hover:text-gray-300 transition">
              <Linkedin className="w-5 h-5" />
              <span className="sr-only">LinkedIn</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="border-t border-[#2a3200]">
        <div className="w-full px-4 py-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400 container mx-auto">
          <p className=" ">
            2025 - All Rights Reserved.{" "}
            <Link href="https://www.traveloure-beta.com" className="hover:text-gray-300">
              www.traveloure-beta.com
            </Link>
          </p>
          <div className="flex items-center mt-4 md:mt-0">
            <Link href="/privacy-policy" className="hover:text-gray-300" target="_blank">
              Privacy Policy
            </Link>
            <span className="mx-2">•</span>
            <Link href="/terms-conditions" className="hover:text-gray-300" target="_blank">
              Terms & Conditions
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
