"use client"

import { useState } from 'react'
import { Button } from './ui/button'
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react'

export default function ItineraryDecisionModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  action, 
  itineraryTitle,
  isLoading = false 
}) {
  if (!isOpen) return null

  const isAccept = action === 'accept'
  const isReject = action === 'reject'

  const handleConfirm = () => {
    onConfirm()
  }

  const handleCancel = () => {
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50  flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          {isAccept && <CheckCircle className="w-6 h-6 text-green-600" />}
          {isReject && <XCircle className="w-6 h-6 text-red-600" />}
          <h3 className="text-lg font-semibold text-gray-900">
            {isAccept ? 'Approve Itinerary' : 'Reject Itinerary'}
          </h3>
        </div>

        {/* Content */}
        <div className="mb-6">
          <p className="text-gray-700 mb-4">
            {isAccept 
              ? `Are you sure you want to approve this itinerary?`
              : `Are you sure you want to reject this itinerary?`
            }
          </p>
          
          {itineraryTitle && (
            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <p className="text-sm text-gray-600 mb-1">Itinerary:</p>
              <p className="font-medium text-gray-900">{itineraryTitle}</p>
            </div>
          )}

          {/* Warning for accept */}
          {isAccept && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-yellow-800">Important Notice</p>
                  <p className="text-sm text-yellow-700 mt-1">
                    By clicking "Yes, Approve & Finish Contract," you agree to the proposed plan, and your contract with the expert will be finalized.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Warning for reject */}
          {isReject && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-red-800">Rejection Notice</p>
                  <p className="text-sm text-red-700 mt-1">
                    Rejecting this itinerary will request the expert to make changes. The expert will be notified and can submit a revised itinerary.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-3 justify-end">
          <Button
            onClick={handleCancel}
            variant="outline"
            disabled={isLoading}
            className="border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={isLoading}
            className={`${
              isAccept 
                ? 'bg-green-600 hover:bg-green-700 text-white' 
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Processing...
              </div>
            ) : (
              isAccept ? 'Yes, Approve & Finish Contract' : 'Yes, Reject Itinerary'
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}


