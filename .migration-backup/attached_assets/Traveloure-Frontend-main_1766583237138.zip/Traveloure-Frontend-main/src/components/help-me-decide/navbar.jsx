"use client"

import { useEffect, useState, useCallback } from "react"
import { ChevronDown, Menu, MapPin, Calendar, Tag, Loader2, Minus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "../../components/ui/avatar"
import { Button } from "../../components/ui/button"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "../../components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../../components/ui/dialog"
import Image from "next/image"
import { useDispatch, useSelector } from "react-redux"
import { deletePlacesData, prefrencePlacesData, createTrip, deletePlacesDatapopular, prefrencePlacesDatapopular, prefrenceeventDatapopular, deleteeventsDatapopular } from "../../app/redux-features/help-me-decide/HelpmeDecideSlice"
import { usePathname } from "next/navigation"
import { userProfile } from "../../app/redux-features/auth/auth"
import { toast } from "sonner"
import { clientRedirect } from "../commonfunctions/page"
import { signOut, useSession } from "next-auth/react"
import { useRouter } from 'next/navigation';
import { FaCoins } from "react-icons/fa"

export function Navbar() {
  const { data: session } = useSession();
  const token = session?.backendData?.accessToken;
  const [menuOpen, setMenuOpen] = useState(false);
  const [isPreferenceModalOpen, setPreferenceModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingActivityIds, setLoadingActivityIds] = useState({});
  const [localSavedPlaces, setLocalSavedPlaces] = useState([]);
  const [localSavedActivities, setLocalSavedActivities] = useState([]);
  // Add a state to track localStorage changes
  const [localStorageChanged, setLocalStorageChanged] = useState(0);
  const [showCreditsModal, setShowCreditsModal] = useState(false);

  const dispatch = useDispatch();

  const pathname = usePathname()
  const isDashboard = pathname.startsWith("/dashboard")
  const isServiceProviderPannel = pathname.startsWith("/service-provider-panel")
  const isLocalExpertPannel = pathname.startsWith("/local-expert/")
  const populargetData = useSelector((state) => state?.helpme?.prefrencesDatapopular?.data)
  const category = useSelector((state) => state?.helpme?.prefrencesData?.data)
  const eventsData = useSelector((state) => state?.helpme?.prefrenceeventpopular?.data)
  const mustGoPlaces = useSelector((state) => state?.helpme?.placeandactivitiesData?.must_go_places)
  const userinfo = useSelector((state) => state?.auth?.profile?.data || [])
  const user = userinfo[0] 

  // Get user credits
  const userCredits = user?.credits || 0

  // Handle credits modal
  const handleAddCredits = () => {
    setShowCreditsModal(true)
  }

  const handleConfirmAddCredits = () => {
    setShowCreditsModal(false)
    router.push('/payment')
  }

  const handleCancelAddCredits = () => {
    setShowCreditsModal(false)
  }
  // Add a function to refresh localStorage data
  const refreshLocalStorageData = useCallback(() => {
    if (!token) {
      // Load saved places
      const savedPlaces = localStorage.getItem("savedPlaces");
      if (savedPlaces) {
        try {
          setLocalSavedPlaces(JSON.parse(savedPlaces));
        } catch {
          localStorage.removeItem("savedPlaces");
          setLocalSavedPlaces([]);
        }
      } else {
        setLocalSavedPlaces([]);
      }

      // Load saved activities
      const savedActivities = localStorage.getItem("savedActivities");
      if (savedActivities) {
        try {
          setLocalSavedActivities(JSON.parse(savedActivities));
        } catch {
          localStorage.removeItem("savedActivities");
          setLocalSavedActivities([]);
        }
      } else {
        setLocalSavedActivities([]);
      }
    }
  }, [token]);
  const router = useRouter()
  // Load localStorage data for non-authenticated users
  useEffect(() => {
    refreshLocalStorageData();
  }, [refreshLocalStorageData, isPreferenceModalOpen]);

  // Add event listener for storage events (when localStorage changes in other tabs)
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === "savedPlaces" || e.key === "savedActivities") {
        refreshLocalStorageData();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [refreshLocalStorageData]);

  // Calculate total preferences count
  const getTotalPreferencesCount = () => {
    if (token) {
      return (category?.length || 0) + (populargetData?.length || 0) + (eventsData?.length || 0);
    } else {
      return localSavedPlaces.length + localSavedActivities.length;
    }
  };

  useEffect(() => {
    if (!token) return // Don't run if token is not present

    const fetchData = async () => {
      try {
        // Fetch preferences first
        await dispatch(prefrencePlacesData({ token })).unwrap()
        await dispatch(prefrencePlacesDatapopular({ token })).unwrap()
        await dispatch(prefrenceeventDatapopular({ token })).unwrap()
        
        // Try to fetch user profile, but don't fail the entire component if it fails
        try {
          await dispatch(userProfile({ token })).unwrap()
        } catch (profileError) {
          console.warn("Failed to fetch user profile:", profileError)
          // Don't show error toast for profile fetch failure
          // This allows the component to continue working even if profile fetch fails
        }
      } catch (error) {
        console.error("Failed to fetch preferences:", error)
        toast.error("Something went wrong while loading your preferences")
      }
    }

    fetchData()
  }, [dispatch, token])

  // Helper function to extract preference ID from different data structures
  const extractPreferenceId = (item) => {
    // Handle nested preference structure: { preference: { id, ... } }
    if (item?.preference?.id) {
      return item.preference.id;
    }
    // Fallback to direct id
    if (item?.id) {
      return item.id;
    }
    return null;
  };

  // Helper function to extract place IDs from category array
  const extractPlaceIds = (categoryArray) => {
    if (!categoryArray || !Array.isArray(categoryArray)) {
      return [];
    }
    
    return categoryArray
      .map(extractPreferenceId)
      .filter(id => id != null && id !== undefined && id !== '');
  };

  // Helper function to extract activity preference IDs
  const extractActivityIds = (activitiesArray) => {
    if (!activitiesArray || !Array.isArray(activitiesArray)) {
      return [];
    }
    
    return activitiesArray
      .map(extractPreferenceId)
      .filter(id => id != null && id !== undefined && id !== '');
  };

  // Helper function to extract event preference IDs
  const extractEventIds = (eventsArray) => {
    if (!eventsArray || !Array.isArray(eventsArray)) {
      return [];
    }
    
    return eventsArray
      .map(extractPreferenceId)
      .filter(id => id != null && id !== undefined && id !== '');
  };

  // Helper function to get image URLs for places from must_go_places
  const getPlaceImageUrls = (placeId) => {
    if (!mustGoPlaces || !Array.isArray(mustGoPlaces)) {
      return null;
    }
    
    // Match by place ID from must_go_places
    const place = mustGoPlaces.find(p => p.id === placeId);
    return place?.image_url || null;
  };

  // Helper function to get the first image URL from image_url (handles both array and string)
  const getFirstImageUrl = (imageUrl) => {
    if (Array.isArray(imageUrl) && imageUrl.length > 0) {
      return imageUrl[0];
    }
    if (typeof imageUrl === 'string') {
      return imageUrl;
    }
    return null;
  };

  // Helper function to build place data with image URLs
  const buildPlaceData = (categoryArray) => {
    if (!categoryArray || !Array.isArray(categoryArray)) {
      return [];
    }
    
    return categoryArray
      .map(item => {
        const placeId = extractPreferenceId(item);
        if (!placeId) return null;
        
        // Try to get image_url from preference data first, then from must_go_places
        const imageUrls = item?.preference?.image_url || 
                         item?.image_url || 
                         getPlaceImageUrls(placeId);
        
        return {
          id: placeId,
          ...(imageUrls && { image_url: imageUrls })
        };
      })
      .filter(item => item !== null);
  };

  const handleClick = async () => {
    if (!token) {
      localStorage.setItem("helpRedirect", "true");
      clientRedirect("/login");
      return;
    }

    // Extract all preference IDs
    const placeIds = extractPlaceIds(category);
    const activityIds = extractActivityIds(populargetData);
    const eventIds = extractEventIds(eventsData);

    // Build place data with image URLs from must_go_places
    const placesWithImages = buildPlaceData(category);

    // Check if user has any preferences at all
    const hasPlaces = placeIds.length > 0;
    const hasActivities = activityIds.length > 0;
    const hasEvents = eventIds.length > 0;
    const totalPreferences = placeIds.length + activityIds.length + eventIds.length;

    // Validation: Check if user has any preferences
    if (totalPreferences === 0) {
      toast.error("No preferences selected to create a trip. Please add places, activities, or events.");
      return;
    }

    // Validation: At least one place is required (API requirement)
    if (!hasPlaces) {
      toast.error("Please add at least one place to visit to create a trip. Activities and events are additional preferences.");
      return;
    }

    // Validate that we have valid place IDs
    if (placeIds.length === 0) {
      toast.error("No valid places selected. Please select places with valid IDs.");
      return;
    }

    // Warn if some places were excluded due to invalid IDs
    if (category && placeIds.length !== category.length) {
      toast.warning("Some selected places have invalid IDs and will be excluded.");
    }

    // Prepare trip dates (currently hardcoded - can be made dynamic later)
    const startDate = new Date("2025-07-01");
    const endDate = new Date("2025-07-05");
    const formatDate = (date) => date.toISOString().split("T")[0];

    // Build payload with place_ids, activity_ids, and event_ids
    const payload = {
      start_date: formatDate(startDate),
      end_date: formatDate(endDate),
      place_ids: placeIds,
      // Include activity preference IDs
      ...(activityIds.length > 0 && { activity_ids: activityIds }),
      // Include event preference IDs
      ...(eventIds.length > 0 && { event_ids: eventIds }),
      // Include places data with image URLs from must_go_places (if API supports it)
      // ...(placesWithImages.length > 0 && { places: placesWithImages }),
    };

    // Log payload for debugging (remove in production)
    console.log("Creating trip with payload:", JSON.stringify(payload, null, 2));

    try {
      setIsLoading(true);
      const res = await dispatch(createTrip({ token, payload })).unwrap();

      if (res) {
        toast.success(res?.message || "Trip created successfully!");
        setPreferenceModalOpen(false);
      } else {
        toast.error("Failed to create trip. Please try again.");
      }
    } catch (error) {
      console.error("Create trip error:", error);
      
      // Handle specific error cases
      if (error && typeof error === 'string' && error.includes('place IDs are invalid')) {
        // Refresh preferences to remove invalid places
        if (token) {
          dispatch(prefrencePlacesData({ token }));
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Function to handle place removal for authenticated users
  const handleRemovePlace = async (placeId) => {
    try {
      const res = await dispatch(deletePlacesData(
        {
          "token": token,
          "place_id": placeId
        }
      )).unwrap()
      if (res?.status) {
        await dispatch(prefrencePlacesData(
          {
            "token": token
          }
        )).unwrap()
        toast.success("Place removed from preferences")
      } else {
        toast.error("Failed to remove place")
      }
    } catch (error) {
      console.error("Error removing place:", error)
      toast.error("Error occurred while removing place")
    }
  }

  // Function to handle place removal for non-authenticated users
  const handleRemoveLocalPlace = (placeId) => {
    const updatedPlaces = localSavedPlaces.filter(place => place.id !== placeId);
    setLocalSavedPlaces(updatedPlaces);
    localStorage.setItem("savedPlaces", JSON.stringify(updatedPlaces));

    // Dispatch custom event with more specific details
    window.dispatchEvent(new CustomEvent('localStorageUpdated', {
      detail: {
        key: 'savedPlaces',
        action: 'remove',
        id: placeId,
        source: 'navbar-modal'
      }
    }));

    toast.success("Place removed from preferences");
  }

  // Function to handle activity deletion for authenticated users
  const handleDeleteActivity = async (item) => {
    const activityName = item.preference?.activity || item.activity || "Activity";
    const placeId = extractPreferenceId(item);

    // Update loading state for this specific activity
    setLoadingActivityIds(prev => ({ ...prev, [placeId]: true }));

    try {

      const result = await dispatch(deletePlacesDatapopular({
        location: item.preference?.location || item.location || "",
        activity: activityName,
        token,
        place_id: placeId
      })).unwrap();

      if (result) {
        toast.success(`${activityName} removed from preferences`);
        // Refresh the activity preferences
        dispatch(prefrencePlacesDatapopular({ token }));
      }
    } catch (error) {
      console.error("Failed to remove activity:", error);
      toast.error(`Failed to remove ${activityName}`);
    } finally {
      setLoadingActivityIds(prev => ({ ...prev, [placeId]: false }));
    }
  };

  // Function to handle activity deletion for non-authenticated users
  const handleDeleteLocalActivity = (activityId) => {
    const updatedActivities = localSavedActivities.filter(activity => activity.id !== activityId);
    setLocalSavedActivities(updatedActivities);
    localStorage.setItem("savedActivities", JSON.stringify(updatedActivities));

    // Dispatch custom event
    window.dispatchEvent(new CustomEvent('localStorageUpdated', {
      detail: {
        key: 'savedActivities',
        action: 'remove',
        id: activityId,
        source: 'navbar-modal'
      }
    }));

    toast.success("Activity removed from preferences");
  }

  // Function to handle event deletion for authenticated users
  const handleDeleteEvent = async (item) => {
    const eventName = item.preference?.activity || item.activity || "Event";
    const eventLocation = item.preference?.location || item.location || "Location";

    try {
      const eventId = extractPreferenceId(item);
      const result = await dispatch(deleteeventsDatapopular({
        location: eventLocation,
        activity: eventName,
        token,
        place_id: eventId
      })).unwrap();

      if (result) {
        toast.success(`${eventName} removed from preferences`);
        // Refresh the events preferences
        dispatch(prefrenceeventDatapopular({ token }));
      }
    } catch (error) {
      console.error("Failed to remove event:", error);
      toast.error(`Failed to remove ${eventName}`);
    }
  }

  // Add a custom event listener for localStorage changes from other components
  useEffect(() => {
    const handleCustomStorageEvent = (e) => {
      if (e.detail && (e.detail.key === "savedPlaces" || e.detail.key === "savedActivities")) {
        refreshLocalStorageData();
      }
    };

    window.addEventListener('localStorageUpdated', handleCustomStorageEvent);

    return () => {
      window.removeEventListener('localStorageUpdated', handleCustomStorageEvent);
    };
  }, [refreshLocalStorageData]);

  // Add listener for help-me-decide cleanup events
  useEffect(() => {
    const handleHelpMeDecideCleanup = (e) => {
      if (e.detail && e.detail.action === 'cleanup') {
        // Reset local state
        setLocalSavedPlaces([]);
        setLocalSavedActivities([]);
        setLocalStorageChanged(prev => prev + 1);
      }
    };

    window.addEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    return () => {
      window.removeEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    };
  }, []);

  return (
    <>
      {/* Beta Banner for Local Expert and Service Provider Panels */}
      {(isLocalExpertPannel || isServiceProviderPannel) && (
        <div className="w-full bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white py-2 px-4 text-center relative overflow-hidden border-b border-orange-300">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10 container mx-auto flex items-center justify-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold animate-pulse">
              🚀 BETA
            </span>
            <span className="text-xs md:text-sm font-medium">
              Testing new features • Your feedback helps us improve
            </span>
          </div>
        </div>
      )}
      
      <header className="border-b bg-white shadow-sm">
        <div className="px-4 flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => clientRedirect("/")}>
            <Image src="/Main-logo.png" width={150} height={50} alt="Arial Travel Logo" className="object-contain" />
            {(isLocalExpertPannel || isServiceProviderPannel) && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-orange-500 via-orange-400 to-orange-500 text-white shadow-md border border-orange-300">
                🚀 BETA
              </span>
            )}
          </div>
          <div className="hidden md:flex items-center gap-3">
            {!isDashboard && !isServiceProviderPannel && !isLocalExpertPannel && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-rose-500 border-rose-500 whitespace-nowrap"
                  onClick={() => setPreferenceModalOpen(true)}
                >
                  Preference Cart ({getTotalPreferencesCount()})
                </Button>
                <Button size="sm" onClick={() => clientRedirect("/Itinerary")} className="bg-rose-500 hover:bg-rose-600 whitespace-nowrap">
                  Create a New Trip
                </Button>
              </>
            )}
            {isDashboard && token && (
              <div
                className="rounded-[22px] border-none bg-[#fdeef4] px-3 flex items-center gap-2 h-[42px] flex-shrink-0 cursor-not-allowed"
                onClick={() => {
                  console.log('Credits clicked')
                }}
              >
                <Image 
                  src="/coins-icon.png" 
                  alt="Credits" 
                  width={16} 
                  height={16} 
                  className="h-4 w-4 flex-shrink-0"
                />
                <span className="bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-clip-text text-transparent font-medium whitespace-nowrap">{userCredits} Credits</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 rounded-full bg-white hover:bg-pink-100 border border-pink-200 flex-shrink-0 ml-1 cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleAddCredits()
                  }}
                >
                  <svg 
                    className="h-3 w-3" 
                    fill="url(#plusGradient)" 
                    viewBox="0 0 24 24"
                  >
                    <defs>
                      <linearGradient id="plusGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#F30131" />
                        <stop offset="100%" stopColor="#BE35EB" />
                      </linearGradient>
                    </defs>
                    <path d="M12 4v16m8-8H4" stroke="url(#plusGradient)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                  </svg>
                </Button>
              </div>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                {token ? (
                  <Button
                    variant="outline"
                    className="flex items-center gap-2 px-3 py-2 h-9 rounded-full border-gray-200 shadow-sm"
                  >
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={user?.image || "/placeholder.svg"} alt={user?.username} />
                      <AvatarFallback className="text-xs bg-rose-500 text-white">{user?.username?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium text-gray-800 max-w-20 truncate">{user?.username}</span>
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    className="flex items-center gap-2 px-3 py-2 h-9 rounded-full border-gray-200 shadow-sm"
                  >
                    Login
                  </Button>
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-40" align="end">
                {token && (
                  <DropdownMenuItem
                    onClick={() => {
                      router.push("/dashboard/profile")
                    }}
                  >
                    User Profile
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  onClick={() => {
                    if (token) {
                      toast("Logging out...")
                      signOut({ callbackUrl: "/" })
                    } else {
                      router.push("/login")
                    }
                  }}
                >
                  {token ? "Logout" : "Login"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setMenuOpen(!menuOpen)}>
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden border-t bg-white">
            {!isDashboard && !isServiceProviderPannel && !isLocalExpertPannel && (
              <div className="px-4 py-3 flex flex-col gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-rose-500 border-rose-500 w-full justify-center"
                  onClick={() => setPreferenceModalOpen(true)}
                >
                  Preference Cart ({getTotalPreferencesCount()})
                </Button>
                <Button onClick={() => clientRedirect("/Itinerary")} size="sm" className="w-full bg-rose-500 hover:bg-rose-600 text-white justify-center">
                  Create a New Trip
                </Button>
              </div>
            )}
            {isDashboard && token && (
              <div className="px-4 py-3 flex flex-col gap-2">
                <div
                  className="rounded-[22px] border-none bg-[#fdeef4] px-3 flex items-center gap-2 h-[42px] flex-shrink-0 cursor-not-allowed w-full justify-center"
                  onClick={() => {
                    console.log('Credits clicked (mobile)')
                  }}
                >
                  <Image 
                    src="/coins-icon.png" 
                    alt="Credits" 
                    width={16} 
                    height={16} 
                    className="h-4 w-4 flex-shrink-0"
                  />
                  <span className="bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-clip-text text-transparent font-medium text-sm whitespace-nowrap">{userCredits} Credits</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 rounded-full bg-white hover:bg-pink-100 border border-pink-200 flex-shrink-0 ml-1 cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleAddCredits()
                    }}
                  >
                    <svg 
                      className="h-3 w-3" 
                      fill="url(#plusGradientMobile)" 
                      viewBox="0 0 24 24"
                    >
                      <defs>
                        <linearGradient id="plusGradientMobile" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#F30131" />
                          <stop offset="100%" stopColor="#BE35EB" />
                        </linearGradient>
                      </defs>
                      <path d="M12 4v16m8-8H4" stroke="url(#plusGradientMobile)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                    </svg>
                  </Button>
                </div>
              </div>
            )}
            <div className="px-4 py-3 border-t flex items-center justify-between">
              {token ? (
                <>
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={user?.image || "/placeholder.svg"} alt={user?.username} />
                      <AvatarFallback className="text-xs bg-rose-500 text-white">{user?.username?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium text-gray-800">{user?.username}</span>
                  </div>
                  <div className="flex gap-2">
                    {token && (
                      <Button variant="ghost" size="sm" onClick={() => clientRedirect("/dashboard/profile")} className="text-xs">
                        User Profile
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => { toast("Logging out..."); signOut({ callbackUrl: "/" }); }} className="text-xs">
                      Logout
                    </Button>
                  </div>
                </>
              ) : (
                <Button variant="ghost" size="sm" onClick={() => router.push("/login") } className="text-xs w-full justify-center">
                  Login
                </Button>
              )}
            </div>
          </div>
        )}
      </header>

      <Dialog open={isPreferenceModalOpen} onOpenChange={setPreferenceModalOpen}>
        <DialogContent className="!max-w-[900px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <DialogTitle className="text-2xl font-bold">Preference Cart ({getTotalPreferencesCount()})</DialogTitle>
          </DialogHeader>

          <div className="space-y-8">
            {/* Upcoming Events Section */}
            <h3 className="text-lg font-semibold mb-4">Events</h3>
            <div>
              {token ? (
                // For authenticated users - show data from API
                eventsData && eventsData.length > 0 ? (
                  <div className="space-y-2">
                    {eventsData.map((item, index) => {
                     
                      const eventName = item.preference?.event || item.event || "Event";
                      const eventLocation = item.preference?.location || item.location || "Location";

                      return (
                        <div
                          key={`event-${item.preference?.id || item.id || index}`}
                          className="flex items-center justify-between rounded-lg p-3 bg-[#f3f4f8] transition-all hover:bg-[#e8eaf2]"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#fff] rounded-full flex items-center justify-center">
                              <Calendar className="h-5 w-5 text-[#FF385C]" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{eventName}</p>
                              <p className="text-xs text-[#535556]">{eventLocation}</p>
                            </div>
                          </div>

                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 bg-[#fff] rounded-full transition-all hover:bg-gray-100 text-red-500"
                            onClick={() => handleDeleteEvent(item)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <div className="text-center">
                      <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No upcoming events added yet</p>
                    </div>
                  </div>
                )
              ) : (
                // For non-authenticated users - show empty state
                <div className="flex items-center justify-center py-12 text-gray-500">
                  <div className="text-center">
                    <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                    <p className="text-sm">No upcoming events added yet</p>
                  </div>
                </div>
              )}
            </div>

            {/* Places to Visit Section */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Places to Visit</h3>
              {token ? (
                // For authenticated users - show data from API
                category && category.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {category.map((item) => (
                      <div key={item.preference.id} className="flex items-center gap-4 p-4 border rounded-lg bg-white">
                        <div className="flex-shrink-0">
                          <Image
                            src={getFirstImageUrl(item?.preference?.image_url) || "/placeholder.svg?height=80&width=80"}
                            alt={item?.preference?.place || "Place"}
                            width={80}
                            height={80}
                            className="w-20 h-20 object-cover rounded-lg"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-base text-gray-900">
                            {item?.preference?.place || "Unknown Place"}
                          </h4>
                          <p className="text-sm text-gray-500 capitalize">
                            {(() => {
                              if (!item.preference.category) return "Unknown Category"
                              if (Array.isArray(item.preference.category)) {
                                return item.preference.category.join(" / ")
                              }
                              if (typeof item.preference.category === "string") {
                                return item.preference.category
                                  .replace(/[[\]']/g, "")
                                  .split(",")
                                  .map((cat) => cat?.trim() || "")
                                  .filter(Boolean)
                                  .join(" / ")
                              }
                              return "Unknown Category"
                            })()}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemovePlace(item.preference.id)}
                          className="text-rose-500 hover:text-rose-600 hover:bg-rose-50 font-medium"
                        >
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No places added to your preferences yet</p>
                    </div>
                  </div>
                )
              ) : (
                // For non-authenticated users - show data from localStorage
                localSavedPlaces && localSavedPlaces.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {localSavedPlaces.map((place) => (
                      <div key={place.id} className="flex items-center gap-4 p-4 border rounded-lg bg-white">
                        <div className="flex-shrink-0">
                          <Image
                            src={getFirstImageUrl(place?.image) || place?.image || "/placeholder.svg?height=80&width=80"}
                            alt={place?.place || "Place"}
                            width={80}
                            height={80}
                            className="w-20 h-20 object-cover rounded-lg"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-base text-gray-900">
                            {place?.place || "Unknown Place"}
                          </h4>
                          <p className="text-sm text-gray-500 capitalize">
                            {Array.isArray(place.category)
                              ? place.category.join(" / ")
                              : place.category || "Unknown Category"}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveLocalPlace(place.id)}
                          className="text-rose-500 hover:text-rose-600 hover:bg-rose-50 font-medium"
                        >
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No places added to your preferences yet</p>
                    </div>
                  </div>
                )
              )}
            </div>

            {/* Activity Preferences Section */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Activity Preferences</h3>
              {token ? (
                // For authenticated users - show data from API
                populargetData && populargetData.length > 0 ? (
                  <div className="space-y-2">
                    {populargetData.map((item, index) => {
                      const activityName = item.preference?.activity || item.activity || "Activity";
                      const activityKey = `activity-${item.preference?.id || item.id || index}`;
                      const placeId = item.preference?.id || item.id;
                      const isActivityLoading = loadingActivityIds[placeId] || false;

                      return (
                        <div
                          key={`${activityKey}-${index}`}
                          className="flex items-center justify-between rounded-lg p-3 bg-[#f3f4f8] transition-all hover:bg-[#e8eaf2]"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#fff] rounded-full flex items-center justify-center">
                              <Image src="/dummyicon.svg" alt={`${activityName} activity icon`} width={30} height={30} />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{activityName}</p>
                              <p className="text-xs text-[#535556]">{item.preference?.location || item.location || "Location"}</p>
                            </div>
                          </div>

                          <Button
                            size="icon"
                            variant="ghost"
                            className={`h-8 w-8 bg-[#fff] rounded-full transition-all ${isActivityLoading ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-100"
                              } text-red-500`}
                            onClick={() => handleDeleteActivity(item)}
                            disabled={isActivityLoading}
                          >
                            {isActivityLoading ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
                            ) : (
                              <Minus className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <div className="text-center">
                      <Tag className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No activity preferences selected yet</p>
                    </div>
                  </div>
                )
              ) : (
                // For non-authenticated users - show data from localStorage
                localSavedActivities && localSavedActivities.length > 0 ? (
                  <div className="space-y-2">
                    {localSavedActivities.map((activity, index) => {
                      const activityName = activity.name || "Activity";

                      return (
                        <div
                          key={`activity-${activity.id || index}`}
                          className="flex items-center justify-between rounded-lg p-3 bg-[#f3f4f8] transition-all hover:bg-[#e8eaf2]"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#fff] rounded-full flex items-center justify-center">
                              <Image src="/dummyicon.svg" alt={`${activityName} activity icon`} width={30} height={30} />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{activityName}</p>
                              <p className="text-xs text-[#535556]">{activity.locations || "Location"}</p>
                            </div>
                          </div>

                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 bg-[#fff] rounded-full transition-all hover:bg-gray-100 text-red-500"
                            onClick={() => handleDeleteLocalActivity(activity.id)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <div className="text-center">
                      <Tag className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No activity preferences selected yet</p>
                    </div>
                  </div>
                )
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="border-t pt-6 mt-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-sm text-gray-600 text-center sm:text-left">
                Create your personalised Itinerary With Selected Preferences, Locations, and upcoming Events
              </p>
              <Button
                className="bg-rose-500 hover:bg-rose-600 text-white px-6"
                disabled={isLoading}
                onClick={
                  token
                    ? handleClick
                    : () => {
                      // Clear specific localStorage items
                      localStorage.removeItem("savedActivities");
                      localStorage.removeItem("savedPlaces");
                      localStorage.setItem("helpRedirect", "true");

                      // Redirect to login
                      clientRedirect("/login");
                    }
                }
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="animate-spin w-4 h-4" />
                    Creating...
                  </span>
                ) : token ? (
                  "✏️ Create a Trip"
                ) : (
                  "Login to Create a Trip"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Credits Modal */}
      <Dialog open={showCreditsModal} onOpenChange={setShowCreditsModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-gray-900">Add Credits</DialogTitle>
            <DialogDescription className="text-gray-600 mt-2">
              Are you sure you want to add more credits to your account?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center justify-center p-4 bg-gradient-to-r from-[#F30131] to-[#BE35EB] rounded-lg mb-4">
              <FaCoins className="w-8 h-8 text-white mr-3" />
                              <span className="text-white font-semibold text-lg">{userCredits} Credits</span>
            </div>
            <p className="text-sm text-gray-600 text-center">
              Adding credits will allow you to generate more itineraries and access premium features.
            </p>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleCancelAddCredits}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmAddCredits}
              className="flex-1 bg-gradient-to-r from-[#F30131] to-[#BE35EB] hover:from-[#D4002A] hover:to-[#A82FD8] text-white"
            >
              Add Credits
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}




