"use client"

import { useState, useRef, useEffect, useMemo } from "react"
import { ChevronDown } from "lucide-react"
import { Button } from "../ui/button"
import { cn } from "../../lib/utils"
import { ScrollArea } from "../ui/scroll-area"
import { useRouter } from "next/navigation"
import { useSelector } from "react-redux"

export function Calendar({ className }) {
  const router = useRouter()
  const currentYear = new Date().getFullYear()
  const nextYear = currentYear + 1

  const [selectedYear, setSelectedYear] = useState(currentYear)
  const [viewMode, setViewMode] = useState("12 Months")
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const dropdownRef = useRef(null)

  // Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Get events from Redux store
  const events1FromRedux = useSelector((state) => state?.helpme?.placeandactivitiesData?.live_events)

  // Use only Redux data
  const events1 = events1FromRedux || []


  // Format events1 data for calendar display with error handling
  const events = useMemo(() => {
    if (!events1 || events1.length === 0) {
      return []
    }

    return events1
      .map((event) => {
        try {
          const dateParts = event.start_date.split(" ")
          const month = {
            Jan: 0,
            Feb: 1,
            Mar: 2,
            Apr: 3,
            May: 4,
            Jun: 5,
            Jul: 6,
            Aug: 7,
            Sep: 8,
            Oct: 9,
            Nov: 10,
            Dec: 11,
          }[dateParts[0]]
          const day = Number.parseInt(dateParts[1])
          const year = 2025

          const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`

          return {
            label: event.title,
            dates: [dateStr],
            venue: event.venue?.name,
            image_url: event.image_url,
            originalEvent: event,
          }
        } catch (error) {
          console.error("Error parsing event date:", error)
          return null
        }
      })
      .filter(Boolean)
  }, [events1])

  // Generate months based on selectedYear and viewMode
  const generateMonths = (year, mode) => {
    const months = []
    const now = new Date()
    const currentMonthIndex = now.getMonth()

    let startMonth = 0
    let monthsToShow = 12

    switch (mode) {
      case "12 Months":
        startMonth = 0
        monthsToShow = 12
        break
      case "6 Months":
        startMonth = 0
        monthsToShow = 6
        break
      case "3 Months":
        startMonth = 0
        monthsToShow = 3
        break
      case "Current Month":
        startMonth = currentMonthIndex
        monthsToShow = 1
        break
      default:
        startMonth = 0
        monthsToShow = 12
    }

    for (let m = startMonth; m < startMonth + monthsToShow; m++) {
      const month = m % 12
      const monthYear = m >= 12 ? year + 1 : year

      const firstDay = new Date(monthYear, month, 1).getDay()
      const daysInMonth = new Date(monthYear, month + 1, 0).getDate()
      const startDay = (firstDay + 6) % 7

      months.push({
        name: new Date(monthYear, month).toLocaleString("default", {
          month: "long",
          year: "numeric",
        }),
        days: daysInMonth,
        startDay,
        year: monthYear,
        month,
      })
    }
    return months
  }

  const daysOfWeek = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]

  const renderMonth = (month, index) => {
    const days = []

    for (let i = 0; i < month.startDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-6 w-6"></div>)
    }

    for (let i = 1; i <= month.days; i++) {
      const dateStr = `${month.year}-${String(month.month + 1).padStart(2, "0")}-${String(i).padStart(2, "0")}`
      const isToday = new Date().toDateString() === new Date(month.year, month.month, i).toDateString()
      const event = events && events.length > 0 ? events.find((e) => e.dates.includes(dateStr)) : null

      days.push(
        <div
          key={i}
          className="relative group cursor-pointer"
          onClick={() => {
            
            if (event) {
              localStorage.setItem("selectedEventDate", dateStr)
              localStorage.setItem("selectedDateEvents", JSON.stringify(events1))
              
              // Dispatch custom event to notify other components
              window.dispatchEvent(new CustomEvent('localStorageChange', {
                detail: {
                  key: "selectedEventDate",
                  value: dateStr
                }
              }))
              window.dispatchEvent(new CustomEvent('localStorageChange', {
                detail: {
                  key: "selectedDateEvents",
                  value: JSON.stringify(events1)
                }
              }))
              
              router.push("/help-me-decide/events")
            } else {
              console.log("No event found for this date")
            }
          }}
          title={event ? event.label : ""}
        >
          <div
            className={cn(
              "h-6 w-6 flex items-center justify-center text-xs rounded-full transition-colors",
              event ? "bg-rose-500 text-white" : isToday ? "bg-rose-200 text-white" : "text-black",
            )}
          >
            {i}
          </div>
          {event && (
            <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10">
              {event.label}
              {event.venue && <span className="block text-xs text-gray-300">{event.venue}</span>}
            </div>
          )}
        </div>,
      )
    }

    return (
      <div key={index} className="mb-4">
        <h3 className="text-sm font-medium mb-2">{month.name}</h3>
        <div className="grid grid-cols-7 gap-1">
          {daysOfWeek.map((day) => (
            <div key={day} className="h-6 w-6 flex items-center justify-center text-xs text-muted-foreground">
              {day}
            </div>
          ))}
          {days}
        </div>
      </div>
    )
  }

  const viewModes = ["12 Months", "6 Months", "3 Months", "Current Month"]

  return (
    <div className={cn("bg-white p-4 rounded-lg border", className)}>
      

      <ScrollArea className="h-[calc(100vh-5rem)] pr-4">
        <div className="flex justify-between items-center mb-4">
          <div className="space-x-2">
            <Button
              variant={selectedYear === currentYear ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedYear(currentYear)}
            >
              {currentYear}
            </Button>
            <Button
              variant={selectedYear === nextYear ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedYear(nextYear)}
            >
              {nextYear}
            </Button>
          </div>

          <div className="relative inline-block" ref={dropdownRef}>
            <Button
              variant="outline"
              size="sm"
              className="text-sm flex items-center"
              onClick={() => setDropdownOpen(!dropdownOpen)}
            >
              View by: {viewMode} <ChevronDown className="ml-1 h-4 w-4" />
            </Button>

            {dropdownOpen && (
              <div className="absolute right-0 mt-1 w-40 bg-white border rounded shadow-lg z-20">
                {viewModes.map((mode) => (
                  <div
                    key={mode}
                    onClick={() => {
                      setViewMode(mode)
                      setDropdownOpen(false)
                    }}
                    className={cn(
                      "px-4 py-2 cursor-pointer hover:bg-gray-100",
                      mode === viewMode ? "font-semibold bg-gray-200" : "",
                    )}
                  >
                    {mode}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {generateMonths(selectedYear, viewMode).map((month, index) => renderMonth(month, index))}
        </div>

        {(!events || events.length === 0) && (
          <div className="flex flex-col items-center justify-center py-6 mt-4 bg-gray-50 rounded-lg">
            <p className="text-gray-500 mb-2">No events available for this period</p>
            <Button variant="outline" size="sm" onClick={() => router.push("/help-me-decide")}>
              Explore Activities
            </Button>
          </div>
        )}
      </ScrollArea>
    </div>
  )
}
