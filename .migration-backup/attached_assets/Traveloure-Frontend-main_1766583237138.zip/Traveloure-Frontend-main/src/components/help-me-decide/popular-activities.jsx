"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { ChevronDown, ChevronUp, Plus, Minus } from "lucide-react"
import { Button } from "../ui/button"
import Link from "next/link"
import Image from "next/image"
import { toast } from "sonner"
import { useDispatch, useSelector } from "react-redux"
import {
  activitiesPlacesData,
  deletePlacesDatapopular,
  fetchPlacesDatapoular,
  prefrencePlacesDatapopular,
} from "../../app/redux-features/help-me-decide/HelpmeDecideSlice"
import { Badge } from "../ui/badge"
import { useSession } from "next-auth/react"
import { usePathname } from "next/navigation"
import { clientRedirect } from "../commonfunctions/page"

export function PopularActivities() {
  const dispatch = useDispatch()
  const { data: session } = useSession()
  const token = session?.backendData?.accessToken
  const pathname = usePathname()

  // Redux selectors
  const activities = useSelector((state) => state?.helpme?.placeandactivitiesData?.popular_activities)
  const populargetData = useSelector((state) => state?.helpme?.prefrencesDatapopular?.data)
  const locations = useSelector((state) => state?.helpme?.placeandactivitiesData?.location)
  const loading = useSelector((state) => state.helpme.loading)
  const city = useSelector((state) => state?.helpme?.placeandactivitiesData?.location) || "your destination"
  const category = useSelector((state) => state?.helpme?.placeandactivitiesData?.categories)

  // Local state
  const [expanded, setExpanded] = useState(false)
  const [savedActivities, setSavedActivities] = useState([])
  const [interests, setInterests] = useState([])
  const [loadingStates, setLoadingStates] = useState({})
  const [userClickedStates, setUserClickedStates] = useState({})
  const [localStorageChanged, setLocalStorageChanged] = useState(0)
  const [hasSearched, setHasSearched] = useState(false)

  // Ensure activities is always an array
  const activitiesArray = Array.isArray(activities) ? activities : []
  const popularDataArray = Array.isArray(populargetData) ? populargetData : []

 

  // Create unique key for each activity
  const createActivityKey = (activity, index) => {
    return (
      activity.id?.toString() ||
      activity.place_id?.toString() ||
      activity.name?.toLowerCase().replace(/\s+/g, "-") ||
      `activity-${index}`
    )
  }

  // Load saved activities from localStorage for non-authenticated users
  useEffect(() => {
    if (!token) {
      const saved = localStorage.getItem("savedActivities")
      if (saved) {
        try {
          setSavedActivities(JSON.parse(saved))
        } catch {
          localStorage.removeItem("savedActivities")
        }
      } else {
        setSavedActivities([])
      }
    }
  }, [token, localStorageChanged])

  // Add a listener for custom events from other components
  useEffect(() => {
    const handleCustomStorageEvent = (e) => {
      if (e.detail && e.detail.key === "savedActivities") {
        // Force refresh of local state
        setLocalStorageChanged(prev => prev + 1)
        
        // If the event came from the navbar modal and it's a remove action,
        // we need to reset the UI state for this activity
        if (e.detail.source === 'navbar-modal' && e.detail.action === 'remove') {
          const removedId = e.detail.id
          
          // Reset the userClickedStates for this activity
          setUserClickedStates(prev => {
            const newState = { ...prev }
            
            // Find all keys that might match this activity
            Object.keys(newState).forEach(key => {
              // Check if this key corresponds to the removed activity
              if (key === removedId || key.includes(removedId)) {
                newState[key] = false
              }
            })
            
            return newState
          })
        }
      }
    }
    
    window.addEventListener('localStorageUpdated', handleCustomStorageEvent)
    return () => {
      window.removeEventListener('localStorageUpdated', handleCustomStorageEvent)
    }
  }, [])

  // Add listener for help-me-decide cleanup events
  useEffect(() => {
    const handleHelpMeDecideCleanup = (e) => {
      if (e.detail && e.detail.action === 'cleanup') {
        // Reset all local state
        setSavedActivities([]);
        setUserClickedStates({});
        setLocalStorageChanged(prev => prev + 1);
      }
    };
    
    window.addEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    return () => {
      window.removeEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    };
  }, []);

  // Add a listener for storage events (for changes in other tabs)
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === "savedActivities") {
        setLocalStorageChanged(prev => prev + 1)
      }
    }
    
    window.addEventListener('storage', handleStorageChange)
    return () => {
      window.removeEventListener('storage', handleStorageChange)
    }
  }, [])

  // Listen for changes in activities data to detect search
  useEffect(() => {
    if (activitiesArray.length > 0 || (locations && locations !== "your destination")) {
      setHasSearched(true);
    }
  }, [activitiesArray, locations]);

  const hasFetched = useRef(false);

  useEffect(() => {
    if (hasFetched.current) return;
    hasFetched.current = true;

    const fetchData = async () => {
      try {
        const result = await dispatch(activitiesPlacesData({ token })).unwrap();
        // If we get data back, it means a search was performed
        if (result && (result.popular_activities || result.location)) {
          setHasSearched(true);
        }
      } catch (error) {
        console.error("Error fetching activitiesPlacesData:", error);
        if (error?.response?.status === 404) {
          console.warn("No activities found.");
        } else {
          console.log("Failed to load activities");
        }
      }

      if (token) {
        try {
          await dispatch(prefrencePlacesDatapopular({ token })).unwrap();
        } catch (error) {
          console.error("Error fetching prefrencePlacesDatapopular:", error);
          if (error?.response?.status === 404) {
            console.warn("No preferences found.");
          } else {
            console.log("Failed to load preferences");
          }
        }
      }
    };

    fetchData();
  }, [dispatch, token]);

  // Handle interest/category selection
  const handleInterest = (interest) => {
    setInterests((prev) => (prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]))

    if (token) {
      dispatch(
        fetchPlacesDatapoular({
          place_id: interest,
          token,
          location: locations || city,
          activity: interest,
        }),
      )
    } else {
      toast.info("Sign in to save your preferences")
    }
  }

  // Check if activity is saved in API data
  const isActivitySavedInAPI = (activity, activityKey) => {
    if (!token || !popularDataArray.length) return false

    return popularDataArray.some((item) => {
      if (!item.preference) return false

      const prefActivity = item.preference.activity?.toLowerCase()
      const activityName = activity.name?.toLowerCase()

      return prefActivity === activityName
    })
  }

  // Check if activity is saved in localStorage
  const isActivitySavedInStorage = (activity, activityKey) => {
    if (!savedActivities || !Array.isArray(savedActivities)) return false
    
    return savedActivities.some((a) => {
      // Try multiple ways to match the activity
      const savedKey = a.place_id?.toString() || a.id || a.name?.toLowerCase().replace(/\s+/g, "-")
      const activityName = activity.name?.toLowerCase()
      const savedName = a.name?.toLowerCase()
      
      return (
        savedKey === activityKey || 
        a.name === activity.name ||
        (activityName && savedName && activityName === savedName)
      )
    })
  }

  // Get current state of activity (saved or not)
  const getCurrentState = (activity, activityKey) => {
    // If user has clicked this activity, use that state
    if (userClickedStates.hasOwnProperty(activityKey)) {
      return userClickedStates[activityKey]
    }

    // Otherwise check initial state
    if (token) {
      return isActivitySavedInAPI(activity, activityKey)
    } else {
      // For non-authenticated users, always check localStorage directly
      return isActivitySavedInStorage(activity, activityKey)
    }
  }

  // Find saved activity data for deletion with multiple matching strategies
  const findSavedActivityData = (activity) => {
    if (!popularDataArray.length) {
      return null
    }

    const activityName = activity.name?.toLowerCase().trim()


    // Strategy 1: Match by activity name in preference
    let found = popularDataArray.find((item) => {
      if (!item.preference) return false
      const prefActivity = item.preference.activity?.toLowerCase().trim()
      const match = prefActivity === activityName
      if (match) console.log("Found match by preference.activity:", item)
      return match
    })

    if (found) return found

    // Strategy 2: Match by name in preference
    found = popularDataArray.find((item) => {
      if (!item.preference) return false
      const prefName = item.preference.name?.toLowerCase().trim()
      const match = prefName === activityName
      if (match) console.log("Found match by preference.name:", item)
      return match
    })

    if (found) return found

    // Strategy 3: Match by direct activity field
    found = popularDataArray.find((item) => {
      const itemActivity = item.activity?.toLowerCase().trim()
      const match = itemActivity === activityName
      if (match) console.log("Found match by direct activity:", item)
      return match
    })

    if (found) return found

    // Strategy 4: Match by direct name field
    found = popularDataArray.find((item) => {
      const itemName = item.name?.toLowerCase().trim()
      const match = itemName === activityName
      if (match) console.log("Found match by direct name:", item)
      return match
    })

    return found || null
  }

  // Handle toggle activity (add/remove)
  const handleToggleActivity = async (activity, activityKey) => {
    const currentState = getCurrentState(activity, activityKey)
    const newState = !currentState


    // Immediately update UI
    setUserClickedStates((prev) => ({
      ...prev,
      [activityKey]: newState,
    }))

    const name = activity.name || "Activity"
    const location = locations || city || "ludhiana"

    if (token) {
      setLoadingStates((prev) => ({ ...prev, [activityKey]: true }))

      try {
        if (currentState) {
          // DELETE operation - find the correct place_id from saved data
          const savedActivityData = findSavedActivityData(activity)

          if (!savedActivityData) {
            console.warn(`No saved data found for ${name}, attempting to refresh and retry...`)

            // Try to refresh the saved preferences first
            await dispatch(prefrencePlacesDatapopular({ token }))

            // Wait a moment for the state to update
            setTimeout(() => {
              const refreshedData = findSavedActivityData(activity)
              if (!refreshedData) {
                console.error(`Still no saved data found for ${name} after refresh`)
                // Revert UI state
                setUserClickedStates((prev) => ({
                  ...prev,
                  [activityKey]: currentState,
                }))
                toast.error(`Cannot find saved data for ${name}. Please try refreshing the page.`)
                return
              }
            }, 500)

            throw new Error("Saved activity data not found - refreshing...")
          }

          // Extract place_id with multiple fallbacks
          const placeIdToDelete =
            savedActivityData.preference?.id ||
            savedActivityData.preference?.place_id ||
            savedActivityData.id ||
            savedActivityData.place_id

          if (!placeIdToDelete) {
            console.error("No valid place_id found in saved data:", savedActivityData)
            throw new Error("No valid place_id found for deletion")
          }

          const result = await dispatch(
            deletePlacesDatapopular({
              location,
              activity: name,
              token,
              place_id: placeIdToDelete,
            }),
          )

          if (result.type.endsWith("/fulfilled")) {
            // Refresh the saved preferences data
            dispatch(prefrencePlacesDatapopular({ token }))
            toast.success(`${name} removed from preferences`)
          } else {
            throw new Error("Delete operation failed")
          }
        } else {
          // ADD operation

          const result = await dispatch(
            fetchPlacesDatapoular({
              location,
              activity: name,
              token,
            }),
          )

          if (result.type.endsWith("/fulfilled")) {
            // Refresh the saved preferences data
            dispatch(prefrencePlacesDatapopular({ token }))
            toast.success(`${name} added to preferences`)
          } else {
            throw new Error("Add operation failed")
          }
        }
      } catch (error) {
        console.error(`API Error for ${name}:`, error)

        // Revert UI state on error
        setUserClickedStates((prev) => ({
          ...prev,
          [activityKey]: currentState,
        }))

        const errorMessage = error.message.includes("not found")
          ? `Cannot find saved data for ${name}. Please refresh the page.`
          : `Failed to ${currentState ? "remove" : "add"} activity`

        toast.error(errorMessage)
      } finally {
        setLoadingStates((prev) => {
          const newState = { ...prev }
          delete newState[activityKey]
          return newState
        })
      }
    } else {
      // Handle localStorage for non-authenticated users
      if (currentState) {
        const updated = savedActivities.filter((a) => {
          const savedKey = a.place_id?.toString() || a.id || a.name?.toLowerCase().replace(/\s+/g, "-")
          return savedKey !== activityKey && a.name !== activity.name
        })
        setSavedActivities(updated)
        localStorage.setItem("savedActivities", JSON.stringify(updated))
        
        // Dispatch custom event to notify other components
        window.dispatchEvent(new CustomEvent('localStorageUpdated', { 
          detail: { key: 'savedActivities', action: 'remove', id: activityKey } 
        }))
        
        toast.success(`${name} removed`)
      } else {
        const stored = {
          id: activityKey,
          name,
          locations: activity.locations || location,
          category: activity.category,
          count: activity.count,
          place_id: activity.id || activity.place_id || activityKey,
        }
        const updated = [...savedActivities, stored]
        setSavedActivities(updated)
        localStorage.setItem("savedActivities", JSON.stringify(updated))
        
        // Dispatch custom event to notify other components
        window.dispatchEvent(new CustomEvent('localStorageUpdated', { 
          detail: { key: 'savedActivities', action: 'add', data: stored } 
        }))
        
        toast.success(`${name} added`)
      }
      
      // Update local state to trigger UI refresh
      setLocalStorageChanged(prev => prev + 1)
    }
  }

  // Filter activities based on selected interests
  const filteredActivities =
    interests.length > 0
      ? activitiesArray.filter((a) => interests.includes(a.category?.toLowerCase()))
      : activitiesArray

  const displayedActivities = expanded ? filteredActivities : filteredActivities.slice(0, 6)

  // Don't render if no activities data
  if (!activitiesArray.length && !loading) {
    return null
  }

  return (
    <div className="space-y-4">
      {hasSearched && (
        <div className="text-[16px] text-[#9A99A8] mb-5">
          <i>Here are the Searched Results for "{city}"</i>
        </div>
      )}

      {/* Category filters */}
      {category && category.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {category.map((interest, i) => (
            <Badge
              key={`${interest}-${i}`}
              onClick={() => handleInterest(interest)}
              className={`rounded-full px-3 py-1 cursor-pointer transition-colors ${
                interests.includes(interest) ? "bg-[#FF385C] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {interest.charAt(0).toUpperCase() + interest.slice(1)}
            </Badge>
          ))}
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">
          {hasSearched ? `Popular Activities to do in "${city}"` : "Popular Activities"}
        </h2>
        {!token && savedActivities.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => clientRedirect("/login")}
            className="text-xs border-rose-500 text-rose-500 hover:bg-rose-50"
          >
            Sign in to save preferences
          </Button>
        )}
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF385C]"></div>
        </div>
      ) : displayedActivities.length > 0 ? (
        <>
          {/* Activities grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {displayedActivities.map((activity, index) => {
              const activityKey = createActivityKey(activity, index)
              const isLoading = loadingStates[activityKey]
              const isSaved = getCurrentState(activity, activityKey)

              return (
                <div
                  key={`${activityKey}-${index}`}
                  className="flex items-center justify-between rounded-lg p-3 bg-[#f3f4f8] transition-all hover:bg-[#e8eaf2]"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#fff] rounded-full flex items-center justify-center">
                      <Image src="/dummyicon.svg" alt="activity icon" width={30} height={30} />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{activity.name}</p>
                      {/* <Link
                        href={`/help-me-decide/${activity.name?.toLowerCase().replace(/\s+/g, "-")}/${activityKey}`}
                        className="text-xs text-[#535556] underline hover:text-[#FF385C]"
                      > */}
                        {activity.count} Locations
                      {/* </Link> */}
                    </div>
                  </div>

                  <Button
                    size="icon"
                    variant="ghost"
                    className={`h-8 w-8 bg-[#fff] rounded-full transition-all ${
                      isLoading ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-100"
                    } ${isSaved ? "text-red-500" : "text-green-500"}`}
                    onClick={() => handleToggleActivity(activity, activityKey)}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
                    ) : isSaved ? (
                      <Minus className="h-4 w-4" />
                    ) : (
                      <Plus className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              )
            })}
          </div>

          {/* Show more/less button */}
          {filteredActivities.length > 6 && (
            <Button
              variant="ghost"
              className="w-full text-[#101010] hover:bg-gray-100"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? (
                <span className="flex items-center gap-1">
                  Show Less <ChevronUp className="h-4 w-4" />
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  Show More <ChevronDown className="h-4 w-4" />
                </span>
              )}
            </Button>
          )}
        </>
      ) : (
        /* No data state */
        <div className="text-center py-8">
          <p className="text-gray-500">No activities found for "{city}"</p>
        </div>
      )}

      <div className="border-t border-[#E8EAF2] mt-6"></div>
    </div>
  )
}




