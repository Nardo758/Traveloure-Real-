"use client"

import { useState } from "react"
import { ScrollArea } from "../ui/scroll-area"
import { Calendar } from "../help-me-decide/calendar"
import DestinationHeader from "../help-me-decide/DestinationHeader"
import { SearchDestination } from "../help-me-decide/search-destination"
import { PopularActivities } from "../help-me-decide/popular-activities"
import { MustGoPlaces } from "../help-me-decide/must-go-places"
import { RelatedArticles } from "../help-me-decide/related-articles"
import { Button } from "../ui/button"
import { CalendarDays, ChevronDown, ChevronUp } from "lucide-react"

export function TripPlanner() {
  const [showCalendarMobile, setShowCalendarMobile] = useState(false)

  return (
    <div className="px-4 grid grid-cols-1 lg:grid-cols-2 gap-6 py-6">
      {/* Left Column - Scrollable Content */}
      <div className="relative">
        <ScrollArea className="h-[calc(100vh-5rem)] pr-4">
          <div className="space-y-8">
            <DestinationHeader />
            <SearchDestination
       
            />
            <PopularActivities  />
            <MustGoPlaces  />
            <RelatedArticles />

            {/* Mobile Calendar Toggle */}
            <div className="block lg:hidden">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowCalendarMobile(!showCalendarMobile)}
                className="flex items-center gap-2 w-full justify-center mt-4"
              >
                <CalendarDays className="h-4 w-4" />
                {showCalendarMobile ? "Hide Calendar" : "Show Calendar"}
                {showCalendarMobile ? (
                  <ChevronUp className="h-4 w-4" />
                ) : (
                  <ChevronDown className="h-4 w-4" />
                )}
              </Button>

              {showCalendarMobile && (
                <div className="mt-4 border rounded-lg shadow-sm p-2 transition-all duration-300 ease-in-out">
                  <Calendar />
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </div>

      {/* Right Column - Visible only on lg and above */}
      <div className="hidden lg:block">
        <Calendar />
      </div>
    </div>
  )
}
