"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Search, X } from "lucide-react"
import { Input } from "../ui/input"
import { Progress } from "../ui/progress"
import { Button } from "../ui/button"
import { activitiesPlacesData } from "../../app/redux-features/help-me-decide/HelpmeDecideSlice"
import { useSession } from "next-auth/react"

export function SearchDestination() {
  const dispatch = useDispatch()
  const {data:session} = useSession();
  const token = session?.backendData?.accessToken;
  const loading = useSelector((state) => state.helpme?.loading)
  const [selectedDestination, setSelectedDestination] = useState("")
  const [progress, setProgress] = useState(0)
  const [dots, setDots] = useState("")

  const handleSubmit = () => {
    if (selectedDestination.trim() !== "") {
      dispatch(activitiesPlacesData(
        {
          "token": token,
          "query": selectedDestination.trim()
        }
      ))
    } else {
      dispatch(activitiesPlacesData(
        {
          "token": token
        }
      ))
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleSubmit()
    }
  }

  // Progress animation
  useEffect(() => {
    let progressTimer
    let dotsTimer

    if (loading) {
      setProgress(10)
      progressTimer = setInterval(() => {
        setProgress((prev) => (prev < 90 ? prev + 10 : prev))
      }, 300)

      dotsTimer = setInterval(() => {
        setDots((prev) => (prev.length >= 3 ? "" : prev + "."))
      }, 500)
    } else {
      setProgress(100)
      setTimeout(() => {
        setProgress(0)
        setDots("")
      }, 500)
    }

    return () => {
      clearInterval(progressTimer)
      clearInterval(dotsTimer)
    }
  }, [loading])

  return (
    <div className="space-y-4 px-4 py-6 md:py-10 rounded-[8px] bg-[#f8f9fb]" style={{ border: "1px solid #E8EAF2" }}>
      <h2 className="text-xl md:text-2xl font-extrabold leading-tight">
        Select Trip Destination and Activity Preferences
      </h2>

      <div className="flex flex-col md:flex-row md:items-center w-full gap-2 md:gap-4">
        <label htmlFor="destination" className="text-sm font-medium md:w-[30%] md:m-0">
          Trip to:
        </label>

        <div className="relative w-full md:w-[70%]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="destination"
            value={selectedDestination}
            onChange={(e) => setSelectedDestination(e.target.value)}
            onKeyDown={handleKeyDown}
            className="pl-10 pr-10 bg-[#fff]"
            placeholder="Enter destination and press Enter"
          />
          {selectedDestination && (
            <button
              onClick={() => setSelectedDestination("")}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              <X className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button 
          onClick={handleSubmit}
          disabled={loading}
          className="bg-[#FF385C] hover:bg-[#e23350] text-white w-full md:w-auto"
        >
          {loading ? "Searching..." : "Search"}
        </Button>
      </div>
      
      {loading && (
        <div className="mt-2">
          <Progress value={progress} className="h-1" />
          <p className="text-xs text-muted-foreground mt-1 animate-pulse">
            Please wait{dots}
          </p>
        </div>
      )}
    </div>
  )
}


