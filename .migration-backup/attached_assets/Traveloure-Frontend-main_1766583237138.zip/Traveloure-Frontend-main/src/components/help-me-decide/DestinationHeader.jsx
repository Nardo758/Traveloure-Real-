"use client"

import Image from "next/image"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "../ui/carousel"
import { ArrowUpRight } from "lucide-react"
import { useEffect, useState } from "react"

export default function DestinationHeader() {
  const items = [
    {
      title: "Top Destinations in London for Couples",
      date: "Updated on May 10, 2025",
      image: "/sample-destination.png",
    },
    {
      title: "Romantic Getaways in Paris",
      date: "Updated on May 15, 2025",
      image: "/sample-destination.png",
    },
    {
      title: "Must-See Spots in Rome",
      date: "Updated on May 20, 2025",
      image: "/sample-destination.png",
    },
    {
      title: "Adventure Escapes in Bali",
      date: "Updated on May 25, 2025",
      image: "/sample-destination.png",
    },
  ]

  const [api, setApi] = useState(null)
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    if (!api) return

    const onSelect = () => {
      setCurrent(api.selectedScrollSnap())
    }

    api.on("select", onSelect)

    // Initial call to set the current slide
    onSelect()

    return () => {
      api.off("select", onSelect)
    }
  }, [api])

  const scrollToSlide = (index) => {
    if (api) {
      api.scrollTo(index)
    }
  }

  return (
    <div className=" bg-gradient-to-b from-[#F8F9FB] to-[#FBFCFD] relative">
      <Carousel setApi={setApi} className="mb-6">
        <CarouselContent>
          {items.map((item, index) => (
            <CarouselItem key={index}>
              <div className="relative  ">
                <div className="w-full aspect-[16/9] relative">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover rounded-lg"
                    sizes="(max-width: 768px) 100vw, 800px"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-8">
                  <h1 className="text-2xl font-bold text-white">{item.title}</h1>
                  <p className="text-sm text-white/80">{item.date}</p>
                  <ArrowUpRight className="absolute top-4 right-4 h-6 w-6 text-white/80" />
                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
      </Carousel>

      {/* Dots Navigation */}
      <div className="absolute left-0 right-0 bottom-4 flex justify-center gap-2 z-20">
        {items.map((_, index) => (
          <button
            key={index}
            onClick={() => scrollToSlide(index)}
            className={`h-2 w-2 rounded-full transition-colors ${current === index ? "bg-white" : "bg-gray-400"}`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
