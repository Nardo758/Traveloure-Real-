"use client"

import { ChevronDown, MessageCircle, Heart } from "lucide-react"
import { Button } from "../ui/button"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "../ui/dropdown-menu"
import { useState } from "react"
import { PiShareFatLight } from "react-icons/pi"
import Link from "next/link"

export function RelatedArticles() {
  const [dateFilter, setDateFilter] = useState("Anytime")
  const [interestFilter, setInterestFilter] = useState("All Activities")

  const articles = [
    {
      title: "Best Urban Beaches in New York to Relax and Recharge",
      description:
        "From Coney Island to Rockaway Beach, explore NYC's top coastal escapes where you can unwind, sunbathe, and enjoy beachside bliss.",
      date: "April 10, 2025",
      likes: 560,
      comments: 102,
    },
    {
      title: "Exploring the Hidden Parks of Manhattan",
      description:
        "Discover green oases in the heart of NYC. These hidden gems are perfect for a peaceful escape from the city's hustle.",
      date: "April 5, 2025",
      likes: 320,
      comments: 45,
    },
    {
      title: "Top Rooftop Cafes to Watch the Sunset in Brooklyn",
      description:
        "Savor great food and stunning views at these amazing rooftop cafes spread across Brooklyn's skyline.",
      date: "March 28, 2025",
      likes: 410,
      comments: 87,
    },
  ]

  return (
    <div className="space-y-4">
      {/* Header + Filters */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
        <h2 className="text-xl font-semibold">Related Articles</h2>

        <div className="flex flex-col sm:flex-row gap-2 sm:gap-6">
          {/* Uploaded Date Filter */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Uploaded Date:</span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  {dateFilter}
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {["Anytime", "Last 7 Days", "Last Month"].map((item) => (
                  <DropdownMenuItem key={item} onClick={() => setDateFilter(item)}>
                    {item}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Interests Filter */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Interests:</span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  {interestFilter}
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {["All Activities", "Food & Dining", "Nightlife"].map((item) => (
                  <DropdownMenuItem key={item} onClick={() => setInterestFilter(item)}>
                    {item}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Articles */}
      {articles.map((article, index) => (
        <div key={index} className="border rounded-lg overflow-hidden relative">
          <div className="flex flex-col sm:flex-row">
            <img
              src="/articleimage.png"
              alt="Article"
              className="w-full sm:w-1/3 h-48 object-cover"
            />
            <div className="p-4 flex flex-col justify-between flex-1">
              <div>
                <Link href="/help-me-decide/articles">
                  <h3 className="font-semibold text-lg">{article.title}</h3>
                  <p className="text-sm text-muted-foreground mt-2">{article.description}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Updated on: {article.date}
                  </p>
                </Link>
              </div>
              <div className="flex justify-between items-center mt-4">
                <div className="flex items-center gap-6">
                  {/* Likes */}
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4 text-rose-500" />
                    <span className="text-sm">{article.likes} Likes</span>
                  </div>

                  {/* Comments */}
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{article.comments} Comments</span>
                  </div>
                </div>

                {/* Share Button */}
                <Button variant="ghost" size="sm" className="text-rose-500 flex items-center gap-1">
                  <PiShareFatLight className="h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
