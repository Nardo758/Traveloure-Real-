"use client"

import { useState, useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { ChevronDown, ChevronUp, Plus, Minus } from "lucide-react"
import { Button } from "../ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@radix-ui/react-dropdown-menu"
import { toast } from "sonner"
import {
  fetchPlacesData,
  deletePlacesData,
  prefrencePlacesData,
} from "../../app/redux-features/help-me-decide/HelpmeDecideSlice"
import Image from "next/image"
import { useSession } from "next-auth/react"

export function MustGoPlaces({ city }) {
  const dispatch = useDispatch()
  const [expanded, setExpanded] = useState(false)
  const [selectedFilter, setSelectedFilter] = useState("All Activities")
  const [imageErrors, setImageErrors] = useState({})
  const {data:session} = useSession();
  const token = session?.backendData?.accessToken;
  // Add this state for non-authenticated users
  const [localSavedPlaces, setLocalSavedPlaces] = useState([]);
  // Add this state to track localStorage changes
  const [localStorageChanged, setLocalStorageChanged] = useState(0);

  const savedPlacesFromRedux = useSelector((state) => state?.helpme?.prefrencesData?.data)
  const mustGoPlacesRaw = useSelector((state) => state?.helpme?.placeandactivitiesData?.must_go_places)

  // Load saved places from localStorage for non-authenticated users
  useEffect(() => {
    if (!token) {
      const saved = localStorage.getItem("savedPlaces");
      if (saved) {
        try {
          setLocalSavedPlaces(JSON.parse(saved));
        } catch {
          localStorage.removeItem("savedPlaces");
        }
      }
    }
  }, [token, localStorageChanged]);

  // Load preferences on component mount
   useEffect(() => {
    if (token) {
      dispatch(prefrencePlacesData({ token }));
    }
  }, [token]); // ✅ Include token in dependency array

  const places = Array.isArray(mustGoPlacesRaw) && mustGoPlacesRaw.length > 0
    ? mustGoPlacesRaw
    : []

  const filteredPlaces = selectedFilter === "All Activities"
    ? places
    : places.filter((p) => p.category?.toLowerCase().includes(selectedFilter.toLowerCase()))

  const displayedPlaces = expanded ? filteredPlaces : filteredPlaces.slice(0, 4)

  // Add a listener for custom events
  useEffect(() => {
    const handleCustomStorageEvent = (e) => {
      if (e.detail && e.detail.key === "savedPlaces") {
        // Force refresh of local state
        setLocalStorageChanged(prev => prev + 1);
      }
    };
    
    window.addEventListener('localStorageUpdated', handleCustomStorageEvent);
    return () => {
      window.removeEventListener('localStorageUpdated', handleCustomStorageEvent);
    };
  }, []);

  // Add listener for help-me-decide cleanup events
  useEffect(() => {
    const handleHelpMeDecideCleanup = (e) => {
      if (e.detail && e.detail.action === 'cleanup') {
        // Reset local state
        setLocalSavedPlaces([]);
        setLocalStorageChanged(prev => prev + 1);
      }
    };
    
    window.addEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    return () => {
      window.removeEventListener('helpMeDecideCleanup', handleHelpMeDecideCleanup);
    };
  }, []);

  // Update isPlaceSaved to always check localStorage directly for non-authenticated users
  const isPlaceSaved = (placeId) => {
    if (token) {
      return savedPlacesFromRedux?.some((item) => item.preference?.id === placeId) || false;
    } else {
      // Always get the latest data from localStorage
      const saved = localStorage.getItem("savedPlaces");
      if (saved) {
        try {
          const places = JSON.parse(saved);
          return places.some((item) => item.id === placeId) || false;
        } catch {
          return false;
        }
      }
      return false;
    }
  };

  // Helper function to get the first image URL from image_url array
  const getPlaceImage = (place) => {
    // Handle array of image URLs - get first one
    if (Array.isArray(place.image_url) && place.image_url.length > 0) {
      return place.image_url[0];
    }
    // Handle single image_url string
    if (typeof place.image_url === 'string') {
      return place.image_url;
    }
    // Fallback to image property
    if (place.image) {
      return place.image;
    }
    // Default fallback
    return "/articleimage.png";
  };

  const handleImageError = (placeId) => {
    setImageErrors(prev => ({
      ...prev,
      [placeId]: true
    }))
  }

  const handleTogglePlace = async (place) => {
    try {
      if (!token) {
        // Handle non-authenticated users with localStorage
        if (isPlaceSaved(place.id)) {
          // Remove from localStorage
          const updatedPlaces = localSavedPlaces.filter(item => item.id !== place.id);
          setLocalSavedPlaces(updatedPlaces);
          localStorage.setItem("savedPlaces", JSON.stringify(updatedPlaces));
          
          // Dispatch custom event to notify other components
          window.dispatchEvent(new CustomEvent('localStorageUpdated', { 
            detail: { key: 'savedPlaces', action: 'remove', id: place.id } 
          }));
          
          toast.error(`${place.city || place.place} removed from your preferences`);
        } else {
          // Add to localStorage
          const placeToSave = {
            id: place.id,
            place: place.place || place.name,
            city: place.city,
            category: place.category,
            // Save first image from array or single image
            image: Array.isArray(place.image_url) && place.image_url.length > 0 
              ? place.image_url[0] 
              : (place.image_url || place.image || "/articleimage.png")
          };
          const updatedPlaces = [...localSavedPlaces, placeToSave];
          setLocalSavedPlaces(updatedPlaces);
          localStorage.setItem("savedPlaces", JSON.stringify(updatedPlaces));
          
          // Dispatch custom event to notify other components
          window.dispatchEvent(new CustomEvent('localStorageUpdated', { 
            detail: { key: 'savedPlaces', action: 'add', data: placeToSave } 
          }));
          
          toast.success(`${place.city || place.place || place.name} added to your preferences`);
        }
      } else {
        // Handle authenticated users with API calls
        if (isPlaceSaved(place.id)) {
          const response = await dispatch(deletePlacesData({
            "token": token,
            "place_id": place.id
          }));
          if (response?.payload?.status) {
            await dispatch(prefrencePlacesData({
              "token": token
            }));
            toast.error(`${place.city || place.place} removed from your preferences`);
          }
        } else {
          const response = await dispatch(fetchPlacesData({
            "token": token,
            "place_id": place.id
          }));
          if (response?.payload?.status) {
            await dispatch(prefrencePlacesData({
              "token": token
            }));
            toast.success(`${place.city || place.place} added to your preferences`);
          }
        }
      }
    } catch (error) {
      toast.error("Failed to update preferences. Please try again.");
      console.error("Error updating preferences:", error);
    }
  }

  const categories = [
    "All Activities",
    "Landmark / Architecture",
    "Art & Culture",
    "Neighborhood",
    "Tour / Activity",
    "Shopping / Landmark",
  ]

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-xl font-semibold">Must go places </h2>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>Interests: </span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center gap-1 hover:bg-gray-100"
              >
                {selectedFilter}
                <ChevronDown className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {categories.map((item) => (
                <DropdownMenuItem 
                  key={item} 
                  onClick={() => setSelectedFilter(item)}
                  className="cursor-pointer hover:bg-gray-100"
                >
                  {item}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {displayedPlaces.map((place) => (
          <div 
            key={place.id} 
            className="flex items-center justify-between border rounded-lg p-3 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-3">
              <div className="relative w-16 h-16 rounded-md overflow-hidden bg-gray-100">
                <Image
                  src={imageErrors[place.id] ? "/articleimage.png" : getPlaceImage(place)}
                  alt={place.place || "Place image"}
                  className="object-cover"
                  fill
                  sizes="(max-width: 64px) 100vw, 64px"
                  onError={() => handleImageError(place.id)}
                  priority={false}
                />
              </div>
              <div>
                <p className="font-medium line-clamp-1">{place.place}</p>
                <p className="text-sm text-muted-foreground line-clamp-1">
                  {Array.isArray(place.category) ? place.category.join(" / ") : place.category}
                </p>
              </div>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className={`h-8 w-8 rounded-full transition-colors ${
                isPlaceSaved(place.id) 
                  ? "bg-red-50 hover:bg-red-100 text-red-600" 
                  : "bg-[#E8EAF280] hover:bg-[#E8EAF2]"
              }`}
              onClick={() => handleTogglePlace(place)}
              aria-label={isPlaceSaved(place.id) ? "Remove place" : "Add place"}
            >
              {isPlaceSaved(place.id) ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            </Button>
          </div>
        ))}
      </div>

      {filteredPlaces.length > 4 && (
        <Button 
          variant="ghost" 
          className="w-full text-[#101010] hover:bg-gray-100" 
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? (
            <span className="flex items-center gap-1">
              Show Less <ChevronUp className="h-4 w-4" />
            </span>
          ) : (
            <span className="flex items-center gap-1">
              Show More <ChevronDown className="h-4 w-4" />
            </span>
          )}
        </Button>
      )}
    </div>
  )
}



