"use client"

import { useEffect, useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useDispatch, useSelector } from 'react-redux'
import { Input } from '../ui/input'
import { Button } from '../ui/button'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion'
import { fetchFAQs, clearError } from '../../app/redux-features/faq/faqSlice'
import { 
  Search,
  Loader2,
  AlertCircle,
  HelpCircle
} from 'lucide-react'

export default function FAQContent({ 
  getAccessToken,
  isAuthenticated,
  dashboardPath = '/dashboard'
}) {
  const { data: sessionData } = useSession()
  const dispatch = useDispatch()
  const [searchQuery, setSearchQuery] = useState('')
  const hasFetchedRef = useRef(false)

  const faqState = useSelector((state) => state.faq)
  const { 
    faqs = [], 
    loading = false, 
    error = null 
  } = faqState || {}

  // Get access token helper
  const getToken = () => {
    if (getAccessToken) {
      return getAccessToken()
    }
    // Fallback to session/localStorage
    return sessionData?.backendData?.accessToken || 
           sessionData?.backendData?.backendData?.accessToken ||
           localStorage.getItem('accessToken')
  }

  // Fetch FAQs on mount - only once
  useEffect(() => {
    if (isAuthenticated && !hasFetchedRef.current) {
      const token = getToken()
      if (token) {
        hasFetchedRef.current = true
        dispatch(fetchFAQs(token))
      }
    }
  }, [isAuthenticated, dispatch])

  // Clear error after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        dispatch(clearError())
      }, 5000)
      return () => clearTimeout(timer)
    }
  }, [error, dispatch])

  // Filter FAQs based on search query
  const filteredFAQs = faqs.filter(faq => {
    if (!searchQuery.trim()) return true
    const searchLower = searchQuery.toLowerCase()
    return (
      faq.question?.toLowerCase().includes(searchLower) ||
      faq.answer?.toLowerCase().includes(searchLower)
    )
  })

  return (
    <div className="max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="mb-8">
        <div className="mb-6">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Frequently Asked Questions
          </h1>
          <p className="text-gray-600 text-base md:text-lg">
            Find answers to common questions about the platform
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
            <Search className="w-5 h-5 text-gray-400" />
          </div>
          <Input
            type="search"
            className="pl-12 pr-4 py-6 w-full text-base border-2 border-gray-200 focus:border-[#ff2e44] rounded-xl bg-white shadow-sm"
            placeholder="Search FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        {searchQuery && (
          <div className="mt-3 text-sm text-gray-600 font-medium">
            Found {filteredFAQs.length} result{filteredFAQs.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg">
          <div className="flex items-center gap-2 text-red-800">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        </div>
      )}

      {/* Loading State */}
      {loading && faqs.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-16 text-center">
          <Loader2 className="w-10 h-10 animate-spin text-[#ff2e44] mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading FAQs...</p>
        </div>
      )}

      {/* FAQs List */}
      {!loading && (
        <>
          {faqs.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-12 md:p-16 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <HelpCircle className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No FAQs Available</h3>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                There are no frequently asked questions available at the moment.
              </p>
            </div>
          ) : filteredFAQs.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-12 md:p-16 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Results Found</h3>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                No FAQs match your search query "{searchQuery}".
              </p>
              <Button 
                variant="outline"
                onClick={() => setSearchQuery('')}
                className="border-gray-300"
              >
                Clear Search
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredFAQs.map((faq, index) => (
                <div 
                  key={faq.id} 
                  className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden"
                >
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value={faq.id} className="border-0">
                      <AccordionTrigger className="px-5 md:px-6 py-5 hover:no-underline hover:bg-gray-50/50 group">
                        <div className="flex items-start gap-4 text-left w-full">
                          <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#ff2e44]/10 flex items-center justify-center mt-0.5">
                            <span className="text-sm font-bold text-[#ff2e44]">
                              {String(index + 1).padStart(2, '0')}
                            </span>
                          </div>
                          <div className="flex-1 pt-1">
                            <h3 className="font-semibold text-gray-900 group-hover:text-[#ff2e44] transition-colors text-base md:text-lg leading-snug">
                              {faq.question}
                            </h3>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-5 md:px-6 pb-5 pt-0">
                        <div className="ml-14 md:ml-16">
                          <div className="pt-1 pb-2">
                            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap text-base">
                              {faq.answer}
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}

