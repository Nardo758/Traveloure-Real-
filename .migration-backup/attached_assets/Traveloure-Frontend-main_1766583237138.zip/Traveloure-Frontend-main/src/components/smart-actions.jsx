"use client"

import { Button } from "./ui/button"
import { useRouter } from "next/navigation"

export function SmartActions() {
  const router = useRouter()

  const actions = [
    {
      title: "Plan a New Trip With AI",
      onClick: () => router.push('/Itinerary')
    },
    {
      title: "Help Me Decide",
      onClick: () => router.push('/help-me-decide')
    },
    {
      title: "Build a Trip With Expert",
      onClick: () => router.push('/experts')
    }
  ]

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-gray-900">Smart Actions</h3>
      <div className="space-y-2">
        {actions.map((action, index) => (
          <Button
            key={index}
            variant="outline"
            className="w-full justify-start text-gray-700 border-gray-200 hover:bg-gray-50"
            onClick={action.onClick}
          >
            {action.title}
          </Button>
        ))}
      </div>
    </div>
  )
} 