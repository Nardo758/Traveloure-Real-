"use client"

import { useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'

export default function TokenFragmentHandler() {
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Only run on client side
    if (typeof window === 'undefined') return

    // Check if URL has access token in fragment or query params
    const hash = window.location.hash
    const searchParams = window.location.search
  
    // Only redirect if we're not already on token-callback page AND we have tokens
    if (pathname !== '/token-callback' && 
        ((hash && hash.includes('access=')) || (searchParams && searchParams.includes('access=')))) {
      
      // Redirect to token-callback page with the same hash/params
      const redirectUrl = hash ? `/token-callback${hash}` : `/token-callback${searchParams}`
      router.push(redirectUrl)
    }
  }, [router, pathname])

  // Also check on window load in case the fragment is added after initial load
  useEffect(() => {
    const handleHashChange = () => {
      if (typeof window === 'undefined') return
      if (pathname === '/token-callback') return

      const hash = window.location.hash
      const searchParams = window.location.search
     
      if ((hash && hash.includes('access=')) || (searchParams && searchParams.includes('access='))) {
        const redirectUrl = hash ? `/token-callback${hash}` : `/token-callback${searchParams}`
        router.push(redirectUrl)
      }
    }

    window.addEventListener('hashchange', handleHashChange)
    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [router, pathname])

  return null // This component doesn't render anything
} 