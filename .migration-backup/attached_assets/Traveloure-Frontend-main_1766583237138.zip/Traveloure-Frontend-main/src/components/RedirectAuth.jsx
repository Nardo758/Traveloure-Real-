"use client"

import { useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, usePathname } from 'next/navigation'
import { clientRedirect } from './commonfunctions/page'

export default function RedirectAuth() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Only run when session is authenticated and user is on home page
    if (status !== 'authenticated' || !session || pathname !== '/') {
      return
    }

    const userRoles = session?.user?.roles || []
    

    // Admin users go to admin dashboard (only when on home page)
    if (userRoles.includes('admin')) {
      clientRedirect('/admin/dashboard')
      return
    }

    // Local expert users go to local expert panel (only when on home page)
    if (userRoles.includes('local_expert')) {
      clientRedirect('/local-expert/dashboard')
      return
    }
    if (userRoles.includes('service_provider')) {
      clientRedirect('/service-provider-panel/dashboard')
      return
    }

    // Regular users stay on home page
    
  }, [session, status, pathname])

  return null // This component doesn't render anything
}
