

export function ServiceItem({ icon: Icon, title, isHighlighted = false }) {
  return (
    <div
      className={`
      flex items-center gap-3 p-2 lg:p-3 rounded-lg cursor-pointer transition-colors
      ${isHighlighted ? "bg-pink-50 text-pink-600" : "hover:bg-gray-50 text-gray-700"}
    `}
    >
      <div
        className={`
        p-1.5 lg:p-2 rounded-lg 
        ${isHighlighted ? "bg-pink-100" : "bg-gray-100"}
      `}
      >
        <Icon className="h-3 w-3 lg:h-4 lg:w-4" />
      </div>
      <span className="text-xs lg:text-sm font-medium">{title}</span>
    </div>
  )
}
