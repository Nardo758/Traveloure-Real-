"use client"

import { Button } from "./ui/button"
import { Globe } from "lucide-react"
import { useState } from "react"
import { Card, CardContent } from "./ui/card"
import { useRouter } from "next/navigation"

export function PersonalizedRecommendation() {
  const router = useRouter()
  const recommendations = [
    {
      destination: "Japan",
      reason: "Based on your love for urban culture and history, Japan would be perfect for your next adventure. Cherry blossom season is ideal!",
      exploreText: "Explore Japan"
    },
    {
      destination: "Italy",
      reason: "Your interest in art and cuisine makes Italy an excellent choice. Spring offers perfect weather for exploring!",
      exploreText: "Explore Italy"
    },
    {
      destination: "Thailand",
      reason: "For adventure and culture, Thailand offers amazing experiences. The weather is perfect for outdoor activities!",
      exploreText: "Explore Thailand"
    }
  ]

  const [currentRecommendation, setCurrentRecommendation] = useState(0)

  const nextRecommendation = () => {
    setCurrentRecommendation((prev) => (prev + 1) % recommendations.length)
  }

  const current = recommendations[currentRecommendation]

  return (
    <Card className="bg-white">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          {/* Globe icon with gradient background */}
          <div className="relative">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, #10B981 0%, #3B82F6 100%)"
              }}
            >
              <Globe className="h-6 w-6 text-white" />
            </div>
          </div>
          
          {/* Content */}
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-2">Personalized Recommendation</h3>
            <p className="text-gray-600 text-sm mb-4 leading-relaxed">
              {current.reason}
            </p>
            
            {/* Action buttons */}
            <div className="flex gap-2">
              <Button 
                className="bg-[#FF385C] hover:bg-[#E02D50] text-white text-sm px-4 py-2"
                onClick={() => {
                  // Navigate to destination search with the recommended destination
                  router.push(`/help-me-decide?destination=${current.destination}`)
                }}
              >
                {current.exploreText}
              </Button>
              <Button 
                variant="outline" 
                className="border-[#FF385C] text-[#FF385C] hover:bg-[#FF385C] hover:text-white text-sm px-4 py-2"
                onClick={nextRecommendation}
              >
                Explore More
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
} 