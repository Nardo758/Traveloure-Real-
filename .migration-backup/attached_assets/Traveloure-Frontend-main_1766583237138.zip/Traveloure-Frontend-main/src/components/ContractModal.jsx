"use client"

import { useState, useRef, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Paperclip, ChevronLeft, ChevronRight, Plus, Minus, Eye } from "lucide-react"
import { toast } from "sonner"
import { apiRequest } from "../lib/api"

export default function ContractModal({ 
  isOpen, 
  onClose, 
  expert, 
  onSubmit,
  userRole = [],
  initialData = {
    contractTitle: "",
    trip_to: "",
    description: "",
    expertFee: "0.00",
    platformFee: "0.00",
    finalAmount: "0.00"
  }
}) {
  
  const [step, setStep] = useState(1) // 1: Contract details, 2: Package selection
  const [formData, setFormData] = useState(initialData)
  const [selectedFile, setSelectedFile] = useState(null)
  const [categories, setCategories] = useState([])
  const [subcategories, setSubcategories] = useState({}) // categoryId -> subcategories array
  const [selectedCategories, setSelectedCategories] = useState([])
  const [selectedSubcategories, setSelectedSubcategories] = useState([])
  const [expandedCategories, setExpandedCategories] = useState({})
  const [expandedSubcategories, setExpandedSubcategories] = useState({})
  const [loading, setLoading] = useState(false)
  const [loadingCategories, setLoadingCategories] = useState(false)
  const fileInputRef = useRef(null)
  const { data: session } = useSession()

  // Get access token from session or localStorage
  const getAccessToken = () => {
    return session?.backendData?.accessToken || 
           session?.backendData?.backendData?.accessToken ||
           localStorage.getItem('accessToken')
  }

  // Fetch categories by expert_id
  useEffect(() => {
    if (isOpen && step === 2 && expert) {
      // Reset expanded categories when entering step 2
      setExpandedCategories({})
      setSubcategories({})
      fetchExpertCategories()
    }
  }, [isOpen, step, expert])

  const fetchExpertCategories = async () => {
    const expertId = expert?.id || expert?.user_id || expert?.user?.id || expert?.pk || expert?.uuid
    if (!expertId) {
      toast.error('Expert ID not found')
      return
    }

    setLoadingCategories(true)
    try {
      const token = getAccessToken()
      const response = await apiRequest(`/auth/category/?expert_id=${expertId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setCategories(Array.isArray(data) ? data : [])
      } else {
        toast.error('Failed to fetch categories')
      }
    } catch (error) {
      console.error('Error fetching categories:', error)
      toast.error('Error loading categories')
    } finally {
      setLoadingCategories(false)
    }
  }

  const fetchSubcategoriesForCategory = async (categoryId) => {
    try {
      const token = getAccessToken()
      if (!token) {
        toast.error('Authentication required')
        return
      }

      // Get expert ID
      const expertId = expert?.id || expert?.user_id || expert?.user?.id || expert?.pk || expert?.uuid
      if (!expertId) {
        toast.error('Expert ID not found')
        return
      }

      const response = await apiRequest(`/auth/subcategory/?category_id=${categoryId}&expert_id=${expertId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        const subcategoriesList = Array.isArray(data) ? data : []
        
        setSubcategories(prev => ({
          ...prev,
          [categoryId]: subcategoriesList
        }))
      } else {
        const errorData = await response.json().catch(() => ({}))
        console.error('Failed to fetch subcategories:', errorData)
        toast.error('Failed to load services')
      }
    } catch (error) {
      console.error('Error fetching subcategories:', error)
      toast.error('Error loading services')
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const handleAttachFile = () => {
    fileInputRef.current?.click()
  }

  const handleNext = () => {
    if (!formData.contractTitle.trim()) {
      toast.error('Contract title is required')
      return
    }

    if (!formData.trip_to.trim()) {
      toast.error('Trip destination is required')
      return
    }

    if (!formData.description.trim()) {
      toast.error('Description is required')
      return
    }

    setStep(2)
  }

  const handleBack = () => {
    setStep(1)
  }

  const toggleCategoryExpansion = (categoryId) => {
    const isExpanded = expandedCategories[categoryId]
    
    // If expanding, close all other categories first (only one open at a time)
    if (!isExpanded) {
      setExpandedCategories({ [categoryId]: true })
      
      // Always fetch subcategories when expanding (in case data changed)
      fetchSubcategoriesForCategory(categoryId)
    } else {
      // If collapsing, just close this category
      setExpandedCategories(prev => ({
        ...prev,
        [categoryId]: false
      }))
    }
  }

  const toggleSubcategoryExpansion = (subcategoryId) => {
    setExpandedSubcategories(prev => ({
      ...prev,
      [subcategoryId]: !prev[subcategoryId]
    }))
  }

  const handleSubcategoryToggle = (subcategory) => {
    const isSelected = selectedSubcategories.some(sub => sub.id === subcategory.id)
    
    if (isSelected) {
      setSelectedSubcategories(prev => prev.filter(sub => sub.id !== subcategory.id))
    } else {
      setSelectedSubcategories(prev => [...prev, subcategory])
      
      // Auto-select category if not already selected
      const categoryId = subcategory.category
      if (!selectedCategories.includes(categoryId)) {
        setSelectedCategories(prev => [...prev, categoryId])
      }
    }
  }

  const calculateTotalAmount = () => {
    return selectedSubcategories.reduce((total, sub) => {
      const price = parseFloat(sub.price) || 0
      return total + price
    }, 0)
  }

  const handleSubmit = async () => {
    if (selectedSubcategories.length === 0) {
      toast.error('Please select at least one service package')
      return
    }

    const expertId = expert?.id || expert?.user_id || expert?.user?.id || expert?.pk || expert?.uuid
    
    if (!expertId) {
      toast.error('Expert ID not found. Cannot create contract.')
      return
    }

    const totalAmount = calculateTotalAmount()
    
    const contractData = {
      created_for: expertId,
      title: formData.contractTitle,
      trip_to: formData.trip_to,
      description: formData.description,
      amount: totalAmount,
      category_ids: selectedCategories,
      subcategory_ids: selectedSubcategories.map(sub => sub.id),
      file: selectedFile,
      expert: expert,
      hasAttachment: !!selectedFile,
      attachmentName: selectedFile?.name
    }
   
    if (onSubmit) {
      onSubmit(contractData)
    } else {
      toast.success('Contract sent successfully!')
      onClose()
    }
  }

  const handleClose = () => {
    setStep(1)
    setFormData(initialData)
    setSelectedFile(null)
    setSelectedCategories([])
    setSelectedSubcategories([])
    setExpandedCategories({})
    setExpandedSubcategories({})
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto">
        {/* Contract Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            {step === 2 && (
              <button
                onClick={handleBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
            )}
            <div className="flex-1 text-center">
              <h2 className="text-2xl font-bold text-gray-900">
            {userRole && userRole.includes("local_expert") ? "Send Contract to Traveler" : "Send Contract to Local Expert"}
          </h2>
              <p className="text-gray-500 text-sm mt-1">
                {step === 1 
                  ? "Create and send a contract for your local expert service"
                  : "Select packages and services"
            }
          </p>
            </div>
            {step === 2 && <div className="w-9" />} {/* Spacer for alignment */}
            <button
              onClick={handleClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <span className="text-2xl text-gray-400 hover:text-gray-600">×</span>
            </button>
          </div>
        </div>

        {/* Step 1: Contract Details */}
        {step === 1 && (
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contract Title
              </label>
              <input
                type="text"
                value={formData.contractTitle}
                onChange={(e) => handleInputChange('contractTitle', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ff2e44] focus:border-transparent"
                placeholder="Enter contract title"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Trip to
              </label>
              <input
                type="text"
                value={formData.trip_to}
                onChange={(e) => handleInputChange('trip_to', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ff2e44] focus:border-transparent"
                placeholder="Enter destination"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
            </label>
            <textarea
              rows={4}
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#ff2e44] focus:border-transparent resize-none"
              placeholder="Describe your service in detail"
            />
            <div 
              className="mt-2 flex items-center gap-2 text-gray-500 text-sm cursor-pointer hover:text-gray-700"
              onClick={handleAttachFile}
            >
              <Paperclip className="w-4 h-4" />
              <span>Attach File</span>
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileChange}
                className="hidden"
                accept="image/*,application/pdf,.doc,.docx"
              />
            </div>
            {selectedFile && (
              <div className="mt-2 text-sm text-green-600">
                ✓ {selectedFile.name} selected
              </div>
            )}
          </div>

            <div className="flex justify-end gap-3 pt-4">
              <button
                onClick={handleClose}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2 text-white rounded-lg font-medium transition-colors"
                style={{ backgroundColor: '#ff2e44' }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#e01e35'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#ff2e44'}
              >
                Proceed & Select Packages
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Package Selection */}
        {step === 2 && (
          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Panel: Categories */}
              <div className="lg:col-span-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Packages</h3>
                {loadingCategories ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: '#ff2e44' }}></div>
                  </div>
                ) : categories.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No packages available</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {categories.map((category) => {
                      const categorySubcategories = subcategories[category.id] || []
                      const selectedCount = selectedSubcategories.filter(
                        sub => sub.category === category.id
                      ).length
                      const isExpanded = expandedCategories[category.id]
                      const isLoading = !subcategories[category.id] && expandedCategories[category.id]
                      // Use number_of_sub_category from API if available, otherwise use loaded subcategories length
                      const totalServices = category.number_of_sub_category !== undefined 
                        ? category.number_of_sub_category 
                        : (isExpanded ? categorySubcategories.length : 0)

                      return (
                        <div
                          key={category.id}
                          className={`border rounded-lg transition-colors ${
                            selectedCount > 0
                              ? 'border-[#ff2e44] bg-[#ff2e4410]'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          {/* Category Header - Clickable */}
                          <div 
                            className="p-4 cursor-pointer"
                          onClick={() => toggleCategoryExpansion(category.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900">{category.name}</h4>
                              <p className="text-sm text-gray-500 mt-1">
                                  Total Services: {isExpanded && isLoading
                                  ? 'Loading...' 
                                    : totalServices}
                              </p>
                              {selectedCount > 0 && (
                                <p className="text-sm mt-1" style={{ color: '#ff2e44' }}>
                                  Selected Services: {selectedCount}
                                </p>
                              )}
                            </div>
                            <ChevronRight 
                              className={`w-5 h-5 text-gray-400 transition-transform ${
                                isExpanded ? 'transform rotate-90' : ''
                              }`}
                />
              </div>
                          </div>

                          {/* Subcategories - Shown inside category card on mobile */}
                          {isExpanded && (
                            <div className="border-t pt-4 px-4 pb-4 lg:hidden">
                              {isLoading ? (
                                <div className="flex items-center justify-center py-8">
                                  <div className="animate-spin rounded-full h-6 w-6 border-b-2" style={{ borderColor: '#ff2e44' }}></div>
                                </div>
                              ) : categorySubcategories.length === 0 ? (
                                <p className="text-gray-500 text-sm">No services available</p>
                              ) : (
                                <div className="space-y-3">
                                  {categorySubcategories.map((subcategory) => {
                                    const isSelected = selectedSubcategories.some(sub => sub.id === subcategory.id)
                                    const isExpanded = expandedSubcategories[subcategory.id]
                                    const description = subcategory.description || subcategory.descritpion || ''

                                    return (
                                      <div
                                        key={subcategory.id}
                                        className="border rounded-lg p-3"
                                        onClick={(e) => e.stopPropagation()}
                                      >
                                        <div className="flex items-start justify-between">
                                          <div className="flex-1">
                                            <div className="flex items-center gap-3">
                                              <h5 className="font-medium text-gray-900 text-sm">
                                                {subcategory.name}
                                              </h5>
                                              <span className="text-sm font-medium text-gray-600">
                                                ${parseFloat(subcategory.price || 0).toFixed(2)}
                                              </span>
                                            </div>
                                            {description && (
                                              <div className="mt-2">
                                                {isExpanded ? (
                                                  <>
                                                    <p className="text-sm text-gray-600">{description}</p>
                                                    <button
                                                      onClick={(e) => {
                                                        e.stopPropagation()
                                                        toggleSubcategoryExpansion(subcategory.id)
                                                      }}
                                                      className="text-sm mt-1"
                                                      style={{ color: '#ff2e44' }}
                                                    >
                                                      Hide Description
                                                    </button>
                                                  </>
                                                ) : (
                                                  <button
                                                    onClick={(e) => {
                                                      e.stopPropagation()
                                                      toggleSubcategoryExpansion(subcategory.id)
                                                    }}
                                                    className="text-sm"
                                                    style={{ color: '#ff2e44' }}
                                                  >
                                                    Show Description
                                                  </button>
                                                )}
                                              </div>
                                            )}
                                          </div>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation()
                                              handleSubcategoryToggle(subcategory)
                                            }}
                                            className={`ml-3 flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                                              isSelected
                                                ? 'bg-[#ff2e44] text-white'
                                                : 'border-2 border-gray-300 hover:border-[#ff2e44]'
                                            }`}
                                          >
                                            {isSelected ? (
                                              <Minus className="w-4 h-4" />
                                            ) : (
                                              <Plus className="w-4 h-4" />
                                            )}
                                          </button>
                                        </div>
                                      </div>
                                    )
                                  })}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              {/* Right Panel: Subcategories - Desktop Only */}
              <div className="hidden lg:block lg:col-span-2">
                {Object.keys(expandedCategories).filter(catId => expandedCategories[catId]).length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <p>Select a package category to view services</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.keys(expandedCategories)
                      .filter(categoryId => expandedCategories[categoryId])
                      .map(categoryId => {
                      const category = categories.find(cat => cat.id === categoryId)
                      const categorySubcategories = subcategories[categoryId] || []
                      const isLoading = !subcategories[categoryId] && expandedCategories[categoryId]

                      return (
                        <div key={categoryId} className="border rounded-lg p-4">
                          <h4 className="text-lg font-semibold text-gray-900 mb-4">
                            {category?.name || 'Services'}
                          </h4>
                          {isLoading ? (
                            <div className="flex items-center justify-center py-8">
                              <div className="animate-spin rounded-full h-6 w-6 border-b-2" style={{ borderColor: '#ff2e44' }}></div>
                            </div>
                          ) : categorySubcategories.length === 0 ? (
                            <p className="text-gray-500 text-sm">No services available</p>
                          ) : (
                            <div className="space-y-3">
                              {categorySubcategories.map((subcategory) => {
                                const isSelected = selectedSubcategories.some(sub => sub.id === subcategory.id)
                                const isExpanded = expandedSubcategories[subcategory.id]
                                const description = subcategory.description || subcategory.descritpion || ''

                                return (
                                  <div
                                    key={subcategory.id}
                                    className="border rounded-lg p-4"
                                  >
                                    <div className="flex items-start justify-between">
                                      <div className="flex-1">
                                        <div className="flex items-center gap-3">
                                          <h5 className="font-medium text-gray-900">
                                            {subcategory.name}
                                          </h5>
                                          <span className="text-sm font-medium text-gray-600">
                                            ${parseFloat(subcategory.price || 0).toFixed(2)}
                                          </span>
                                        </div>
                                        {description && (
                                          <div className="mt-2">
                                            {isExpanded ? (
                                              <>
                                                <p className="text-sm text-gray-600">{description}</p>
                                                <button
                                                  onClick={() => toggleSubcategoryExpansion(subcategory.id)}
                                                  className="text-sm mt-1"
                                                  style={{ color: '#ff2e44' }}
                                                >
                                                  Hide Description
                                                </button>
                                              </>
                                            ) : (
                                              <button
                                                onClick={() => toggleSubcategoryExpansion(subcategory.id)}
                                                className="text-sm"
                                                style={{ color: '#ff2e44' }}
                                              >
                                                Show Description
                                              </button>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          handleSubcategoryToggle(subcategory)
                                        }}
                                        className={`ml-4 p-2 rounded-full transition-colors ${
                                          isSelected
                                            ? 'text-white'
                                            : 'text-gray-400 border border-gray-300 hover:border-[#ff2e44]'
                                        }`}
                                        style={isSelected ? { backgroundColor: '#ff2e44' } : {}}
                                      >
                                        {isSelected ? (
                                          <Minus className="w-4 h-4" />
                                        ) : (
                                          <Plus className="w-4 h-4" />
                                        )}
                                      </button>
                                    </div>
                                  </div>
                                )
                              })}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Footer with Total and Submit */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm font-medium text-gray-700">AMOUNT TO PAY</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">
                    ${calculateTotalAmount().toFixed(2)}
                    <span className="text-sm font-normal text-gray-500 ml-2">
                      ({selectedSubcategories.length} {selectedSubcategories.length === 1 ? 'Service' : 'Services'} Selected)
                    </span>
                  </p>
          </div>
        </div>
              <div className="flex justify-end gap-3">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
                  className="px-6 py-2 text-white rounded-lg font-medium transition-colors"
                  style={{ backgroundColor: '#ff2e44' }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#e01e35'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#ff2e44'}
          >
                  Pay and Send Contract
          </button>
        </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
} 
