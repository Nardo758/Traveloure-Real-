"use client"

import { useState, useEffect } from "react"
import { Paperclip } from "lucide-react"
import { toast } from "sonner"

export function VoiceMessagePlayer({ 
  message, 
  attachment, 
  messageId, 
  index, 
  isOutgoing, 
  voiceDuration 
}) {
  const [playingAudioId, setPlayingAudioId] = useState(null)
  const [audioInstances, setAudioInstances] = useState({})

  // Cleanup audio instances on unmount
  useEffect(() => {
    return () => {
      Object.values(audioInstances).forEach(audio => {
        if (audio) {
          audio.pause()
          audio.src = ''
        }
      })
    }
  }, [])

  const handlePlayPause = async () => {
    try {
      const currentMessageId = messageId || `msg-${index || 0}`
      const isCurrentlyPlaying = playingAudioId === currentMessageId
      
      
      
      if (!attachment) {
        console.error('🔌 No attachment found in message')
        toast.error('No voice message attachment found')
        return
      }
      
      if (isCurrentlyPlaying) {
        // Pause the audio
        const currentAudio = audioInstances[currentMessageId]
        if (currentAudio) {
          currentAudio.pause()
          setPlayingAudioId(null)
          console.log('🔌 Voice message paused')
        }
        return
      }
      
      // Stop any currently playing audio
      if (playingAudioId && audioInstances[playingAudioId]) {
        audioInstances[playingAudioId].pause()
        setPlayingAudioId(null)
      }
      
      // Handle both API URLs and WebSocket file objects
      let audioUrl
      if (typeof attachment === 'string') {
        if (attachment.startsWith('http')) {
          audioUrl = attachment
        } else {
          audioUrl = `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment}`
        }
      } else if (attachment instanceof File || attachment instanceof Blob) {
        audioUrl = URL.createObjectURL(attachment)
      } else {
        // Handle case where attachment is an object but not a File/Blob
        if (attachment.url) {
          audioUrl = attachment.url.startsWith('http') 
            ? attachment.url 
            : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.url}`
        } else if (attachment.attachment) {
          audioUrl = attachment.attachment.startsWith('http') 
            ? attachment.attachment 
            : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.attachment}`
        }
      }
      
   
      
      if (!audioUrl) {
        console.error('🔌 No valid audio URL generated')
        toast.error('Invalid audio file')
        return
      }
      
      const audio = new Audio(audioUrl)
      
      // Store audio instance
      setAudioInstances(prev => ({
        ...prev,
        [currentMessageId]: audio
      }))
      
      // Add comprehensive error handling
      audio.onerror = (e) => {
        console.error('🔌 Audio playback error:', e)
        console.error('🔌 Audio error details:', audio.error)
        toast.error('Failed to play voice message')
        setPlayingAudioId(null)
      }
      
      // Add success handling
      audio.oncanplay = () => {
        console.log('🔌 Audio can play, starting playback')
      }
      
      audio.onloadstart = () => {
        console.log('🔌 Audio loading started')
      }
      
      audio.onloadeddata = () => {
        console.log('🔌 Audio data loaded')
      }
      
      audio.onended = () => {
        setPlayingAudioId(null)
      }
      
      await audio.play()
      setPlayingAudioId(currentMessageId)
    } catch (error) {
     
      toast.error('Failed to play voice message')
      setPlayingAudioId(null)
    }
  }

  return (
    <div className="mt-2">
      <div className={`flex items-center gap-3 p-2 rounded-lg ${
        isOutgoing 
          ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-opacity-10' 
          : 'bg-gray-100'
      }`}>
        <button
          onClick={handlePlayPause}
          className="w-6 h-6 bg-gray-700 rounded-full flex items-center justify-center hover:bg-gray-800 transition-colors"
        >
          {playingAudioId === (messageId || `msg-${index || 0}`) ? (
            // Pause icon
            <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          ) : (
            // Play icon
            <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8 5v10l8-5-8-5z" clipRule="evenodd" />
            </svg>
          )}
        </button>
        <div className="flex-1 bg-gray-300 rounded-full h-1">
          <div className="bg-blue-500 h-1 rounded-full" style={{ width: '0%' }}></div>
        </div>
        <span className={`text-xs ${
          isOutgoing ? 'text-white' : 'text-gray-600'
        }`}>
          {voiceDuration ? `${Math.floor(voiceDuration / 60)}:${(voiceDuration % 60).toString().padStart(2, '0')}` : '0:00'}
        </span>
      </div>
      
      {/* Show attachment link for voice messages */}
      <div className="mt-1">
        <a 
          href={(() => {
            if (typeof attachment === 'string') {
              return attachment.startsWith('http') 
                ? attachment 
                : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment}`
            } else if (attachment instanceof File || attachment instanceof Blob) {
              return URL.createObjectURL(attachment)
            } else if (attachment && attachment.url) {
              return attachment.url.startsWith('http') 
                ? attachment.url 
                : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.url}`
            } else if (attachment && attachment.attachment) {
              return attachment.attachment.startsWith('http') 
                ? attachment.attachment 
                : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.attachment}`
            }
            return '#'
          })()} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-xs underline flex items-center gap-1"
        >
          <Paperclip className="w-3 h-3" />
          Attachment
        </a>
      </div>
    </div>
  )
}
