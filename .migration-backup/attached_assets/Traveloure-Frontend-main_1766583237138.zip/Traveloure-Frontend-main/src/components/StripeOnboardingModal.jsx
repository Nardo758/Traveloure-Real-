"use client"

import { useState } from 'react'
import { Button } from './ui/button'
import { CreditCard } from 'lucide-react'

export default function StripeOnboardingModal({ isOpen, onClose, onCompleteOnboarding, message, onboardingUrl }) {
  if (!isOpen) return null

  const handleCompleteOnboarding = () => {
    if (onboardingUrl) {
      // Open the Stripe onboarding URL in a new tab
      window.open(onboardingUrl, '_blank')
    }
    
    if (onCompleteOnboarding) {
      onCompleteOnboarding()
    }
  }

  return (
    <div class="fixed inset-0 !bg-gray-300/30 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-8 max-w-md mx-4 shadow-xl">
        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-r from-[#F30131] to-[#BE35EB] rounded-full flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
            <div className="absolute inset-0 w-16 h-16 bg-gradient-to-r from-[#F30131] to-[#BE35EB] rounded-full opacity-20 animate-ping"></div>
          </div>
        </div>

        {/* Title */}
        <h2 className="text-2xl font-bold text-center text-gray-900 mb-4">
          Complete Your Stripe Onboarding
        </h2>

        {/* Description */}
        <p className="text-gray-600 text-center mb-8 leading-relaxed">
          {message || "To start receiving payments and bookings on Traveloure, please complete your Stripe Connect onboarding."}
        </p>

        {/* Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1 border-[#F30131] text-[#F30131] hover:bg-gray-50"
          >
            I'll do it Later
          </Button>
          <Button
            onClick={handleCompleteOnboarding}
            className="flex-1 bg-gradient-to-r from-[#F30131] to-[#BE35EB] hover:from-[#E0012A] hover:to-[#A82DD4] text-white"
          >
            Complete Onboarding
          </Button>
        </div>
      </div>
    </div>
  )
}
