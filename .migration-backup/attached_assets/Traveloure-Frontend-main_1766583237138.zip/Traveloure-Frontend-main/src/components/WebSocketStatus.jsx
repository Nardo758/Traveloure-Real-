"use client"

import { useWebSocketContext } from './WebSocketProvider'
import { Wifi, WifiOff, AlertCircle } from 'lucide-react'
import { Badge } from './ui/badge'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip'

export const WebSocketStatus = ({ showText = false, className = "" }) => {
  const { isConnected, connectionStatus, connectionError, userId } = useWebSocketContext()

  const getStatusInfo = () => {
    switch (connectionStatus) {
      case 'connected':
        return {
          icon: Wifi,
          color: 'text-green-500',
          bgColor: 'bg-green-100',
          text: 'Connected',
          tooltip: `WebSocket connected (User ID: ${userId})`
        }
      case 'error':
        return {
          icon: AlertCircle,
          color: 'text-red-500',
          bgColor: 'bg-red-100',
          text: 'Error',
          tooltip: `Connection error: ${connectionError}`
        }
      default:
        return {
          icon: WifiOff,
          color: 'text-gray-400',
          bgColor: 'bg-gray-100',
          text: 'Disconnected',
          tooltip: 'WebSocket disconnected'
        }
    }
  }

  const statusInfo = getStatusInfo()
  const Icon = statusInfo.icon

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`flex items-center gap-2 ${className}`}>
            <div className={`p-1 rounded-full ${statusInfo.bgColor}`}>
              <Icon className={`h-3 w-3 ${statusInfo.color}`} />
            </div>
            {showText && (
              <Badge 
                variant={connectionStatus === 'connected' ? 'default' : 'secondary'}
                className="text-xs"
              >
                {statusInfo.text}
              </Badge>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{statusInfo.tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
} 