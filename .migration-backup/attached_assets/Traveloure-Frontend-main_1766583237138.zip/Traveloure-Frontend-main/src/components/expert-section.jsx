"use client"

import { useState } from "react"
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "../components/ui/accordion"
import { motion, AnimatePresence } from "framer-motion"
import {
  Map,
  Sparkles,
  Compass,
  Coffee,
  Briefcase,
} from "lucide-react"
import Image from "next/image"
import dummypic from "../../public/dummypic.png"
import { cn } from "../lib/utils"


const expertiseContent = {
  "let-ai-plan": {
    title: "Let Our AI Plan Your Trip",
    description: "AI evaluates countless travel choices for you, comparing flights, hotels, and itineraries to find the perfect match for your budget, schedule, and preferences.",
    icon: <Sparkles className="h-5 w-5 text-green-600" />,
    content: (
      <div className="bg-cover bg-center">
     <Image src="/ai-plan.png" alt="AI Expert" width={700} height={700} />
    </div>
    ),
  },
  "local-expert": {
    title: "Travel Experts To Help",
    description: "Connect with trusted experts for insider tips, hidden gems, and real-time assistance.",
    icon: <Map className="h-5 w-5 text-green-600" />,
    content: (
      <div className="bg-cover bg-center">
        <Image src={dummypic} alt="logo" />
      </div>
    ),
  },
  "ai-optimization": {
    title: "AI Optimization – Perfectly Tailored for You  ",
    description: "Our AI tailors your trip by optimizing cost, time, and preferences, while providing real-time updates and personalized recommendations—all for effortless, stress-free planning. ",
    icon: <Compass className="h-5 w-5 text-green-600" />,
    content: (
      <div className="bg-cover bg-center">
     <Image src="/ai-expert-img.png" alt="AI Expert" width={700} height={700} />
    </div>
    ),
  },
  "discover-destinations": {
    title: "Discover New Destinations",
    description: "From cozy cafés to epic peaks,  Adventurer, foodie, or zen-seeker? —Your vibe charts the course.",
    icon: <Coffee className="h-5 w-5 text-green-600" />,
    content: (
      <div className="bg-cover bg-center">
      <Image src="/discover-expert-img.png" alt="Discover Expert" width={700} height={700} />
     </div>
    ),
  },
  "partner-with-us": {
    title: "Partner With Us",
    description: "Partner with us to amplify your reach in the thriving travel market. Whether you're a content creator, brand, or tourism provider, our platform connects you with passionate travelers seeking authentic experiences. We offer collaborative opportunities that drive visibility, engagement, and mutual growth, turning wanderlust into measurable results. Let's create unforgettable journeys together.",
    icon: <Briefcase className="h-5 w-5 text-green-600" />,
    content: (
      <div className="bg-cover bg-center">
      <Image src="/partner-expert-img.png" alt="Discover Expert" width={700} height={700} />
     </div>
    ),
  },
}

export default function ExpertSection() {
  const [activeTab, setActiveTab] = useState(null)

  const contentVariants = {
    hidden: { opacity: 0, x: 50 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4 } },
    exit: { opacity: 0, x: -50, transition: { duration: 0.3 } },
  }

  return (
    <section className="container mx-auto px-4 relative py-9">
      <div className={`grid gap-8 ${activeTab ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}> 
        {/* Left Side: Accordion */}
        <div className="p-6">
          <Accordion
            type="single"
            collapsible
            value={activeTab}
            onValueChange={(value) => {
              setActiveTab(value === activeTab ? null : value)
            }}
            className="space-y-3"
          >
            {Object.entries(expertiseContent).map(([key, item]) => (
              <div key={key} className="relative">
                <AccordionItem
                  value={key}
                  className="rounded-lg bg-white border border-gray-200 overflow-hidden relative"
                >
                  {activeTab === key && (
                    <div className="absolute left-0 top-2/5 bottom-2/5 border-l-4 border-green-500 rounded-tl-lg rounded-bl-lg" />
                  )}
                  <AccordionTrigger
                    className={cn(
                      "flex justify-between items-center p-5 text-base font-semibold text-left custom-accordion-trigger",
                      activeTab === key ? "text-green-600" : "text-black",
                      activeTab === key ? "border-b-0" : "border-b border-gray-200"
                    )}
                  >
                    <span>{item.title}</span>
                    <span className="ml-2">
                      {/* Arrow: up if closed, down if open */}
                      {activeTab === key ? (
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      ) : (
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 15l-6-6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      )}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="px-5 pb-5 text-gray-600 text-sm leading-relaxed whitespace-normal break-words">
                    {item.description}
                  </AccordionContent>
                </AccordionItem>
              </div>
            ))}
          </Accordion>
        </div>

        {/* Right Side: Dynamic Content with Conditional Background */}
        {activeTab && (
          <div
            className={`p-6 rounded-lg relative transition-all duration-500`}
            style={
              activeTab === "local-expert"
                ? {
                    backgroundImage: "url('/localbg.png')",
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }
                : {}
            }
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial="hidden"
                animate="visible"
                exit="exit"
                variants={contentVariants}
              >
                <div className="flex flex-col items-center justify-center  p-6 rounded-md">
                  {expertiseContent[activeTab].content}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        )}
      </div>
    </section>
  )
}
