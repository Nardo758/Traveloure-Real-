"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "../components/ui/button"
import { ScrollArea } from "../components/ui/scroll-area"
import { ChevronLeft, MapPin } from "lucide-react"
import { toast } from "sonner"

export function VenueListing({ title, subtitle, venues }) {
  const [preferences, setPreferences] = useState([])

  const handleAddToPreference = (id) => {
    setPreferences((prev) => {
      const isAlreadyAdded = prev.includes(id)
      const newPreferences = isAlreadyAdded ? prev.filter((item) => item !== id) : [...prev, id]

      toast.success(isAlreadyAdded ? "Removed from preferences" : "Added to preferences")
      return newPreferences
    })
  }

  const isVenueInPreferences = (id) => preferences.includes(id)

  return (
    <div className="h-full">
      <div className="mb-6">
        <Link href="/help-me-decide" className="flex items-center text-sm text-[#FF385C] mb-4">
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Main Page
        </Link>
        <h1 className="text-2xl font-bold">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>

      <ScrollArea className="h-[calc(100vh-12rem)] pr-4">
        <div className="space-y-0">
          {venues.map((venue) => (
            <VenueCard
              key={venue.id}
              venue={venue}
              isInPreferences={isVenueInPreferences(venue.id)}
              onAddToPreference={handleAddToPreference}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

function VenueCard({ venue, isInPreferences, onAddToPreference }) {
  const { id, name, description, address, image_url, price_range, rating, reviews_count } = venue

  return (
    <div className="flex border-b pb-6 mb-6">
      <div className="w-32 h-24 md:w-40 md:h-32 relative flex-shrink-0 mr-4">
        <Image
          src={image_url || "/placeholder.svg?height=128&width=160"}
          alt={name}
          fill
          className="object-cover rounded-md"
        />
      </div>

      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold">{name}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
            <div className="flex items-center text-xs text-muted-foreground mt-1">
              <MapPin className="h-3 w-3 mr-1" />
              <span>{address}</span>
              <Button variant="link" size="sm" className="text-xs text-[#FF385C] p-0 h-auto ml-1">
                Get Directions
              </Button>
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold">{price_range}</div>
            <div className="text-xs text-muted-foreground">(Per Person)</div>
          </div>
        </div>

        <div className="flex justify-between">
          <div className="flex gap-2 mt-3">
            <Button size="sm" className="bg-[#FF385C] hover:bg-red-600 text-white rounded-[6px] px-6">
              Book Now
            </Button>
            <Button
              size="sm"
              variant="outline"
              className={`${
                isInPreferences
                  ? "bg-green-50 text-green-600 border-green-300"
                  : "text-[#FF385C] border-[#FF385C] hover:bg-red-50"
              }  rounded-[6px] px-4`}
              onClick={() => onAddToPreference(id)}
            >
              {isInPreferences ? "Added to Preference" : "Add to Preference"}
            </Button>
          </div>

          <div className="flex items-center mt-2 md:mt-0 flex-nowrap whitespace-nowrap">
            <div className="flex flex-nowrap">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                  }`}
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
              ))}
            </div>
            <span className="text-sm font-medium ml-2">{rating}</span>
            <span className="text-xs text-muted-foreground ml-1">({reviews_count} Reviews)</span>
          </div>
        </div>
      </div>
    </div>
  )
}
