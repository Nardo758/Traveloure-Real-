"use client"
import React, { useState, useEffect } from "react"
import { Button } from "./ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog"
import { 
  Share2, 
  Download, 
  MessageCircle, 
  Instagram, 
  Facebook, 
  Twitter, 
  Mail, 
  Copy,
  X
} from "lucide-react"
import { toast } from "sonner"

export default function ShareButton({ tripId, tripTitle = "My Trip", onDownloadPDF }) {
  const [isShareModalOpen, setIsShareModalOpen] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)
  const [actualTripId, setActualTripId] = useState(tripId)

  // Get trip ID from localStorage if not provided as prop
  useEffect(() => {
    if (!tripId) {
      const localTripId = localStorage.getItem("itinerary_id")
      if (localTripId) {
        setActualTripId(localTripId)
      }
    } else {
      setActualTripId(tripId)
    }
  }, [tripId])

  const shareUrl = `https://traveloure.com/ai-optimization/${actualTripId || '1'}`

  const socialPlatforms = [
    {
      name: "WhatsApp",
      icon: MessageCircle,
      color: "bg-green-500 hover:bg-green-600",
      url: `https://wa.me/?text=Check out my amazing trip to ${tripTitle}! ${shareUrl}`,
     },
    // {
    //   name: "Instagram",
    //   icon: Instagram,
    //   color: "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600",
    //   url: `https://www.instagram.com/`,
    //   isDirectMessage: true,
    //   message: `Check out my amazing trip to ${tripTitle}! ${shareUrl}`,
    //   instructions: "Open Instagram and paste the message in your story or DM",
    // },
    // {
    //   name: "Facebook",
    //   icon: Facebook,
    //   color: "bg-blue-600 hover:bg-blue-700",
    //   url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=Check out my amazing trip to ${tripTitle}!`,
    //   isDirectMessage: false,
    // },
    // {
    //   name: "Messenger",
    //   icon: MessageCircle,
    //   color: "bg-blue-500 hover:bg-blue-600",
    //   url: `https://www.messenger.com/`,
    //   isDirectMessage: true,
    //   message: `Check out my amazing trip to ${tripTitle}! ${shareUrl}`,
    //   instructions: "Open Messenger and paste the message in your conversation",
    // },
    // {
    //   name: "Twitter",
    //   icon: Twitter,
    //   color: "bg-sky-500 hover:bg-sky-600",
    //   url: `https://twitter.com/intent/tweet?text=Check out my amazing trip to ${tripTitle}!&url=${encodeURIComponent(shareUrl)}`,
    // }
  ]

  const handleShare = (platform) => {
    if (platform.name === "Copy Link") {
      navigator.clipboard.writeText(shareUrl)
      toast.success("Link copied to clipboard!")
    } else if (platform.isDirectMessage) {
      // For platforms that need to open message section
      window.open(platform.url, "_blank", "noopener,noreferrer")
      
      // Show a toast with instructions and copy the message to clipboard
      navigator.clipboard.writeText(platform.message)
      const instruction = platform.instructions || "Message copied to clipboard. You can paste it in the message."
      toast.success(`${platform.name} opened! ${instruction}`)
    } else {
      window.open(platform.url, "_blank", "noopener,noreferrer")
    }
    setIsShareModalOpen(false)
  }

  const handleDownloadPDF = async () => {
    setIsDownloading(true)
    try {
      if (onDownloadPDF) {
        await onDownloadPDF()
      }
      toast.success("PDF download started!")
    } catch (error) {
      toast.error("Failed to download PDF")
      console.error("PDF download error:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <>
      <Button
        onClick={() => setIsShareModalOpen(true)}
        className="flex items-center gap-2 bg-[#FF385C] hover:bg-[#e02d50] text-white font-semibold px-5 py-2 rounded-lg shadow transition"
      >
        <Share2 className="w-4 h-4" />
        Share Trip
      </Button>

      <Dialog open={isShareModalOpen} onOpenChange={setIsShareModalOpen}>
        <DialogContent className="w-full max-w-md rounded-2xl p-0">
          <DialogHeader className="px-6 pt-6 pb-4">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-xl font-bold text-gray-900">
                Share Your Trip
              </DialogTitle>
              
            </div>
          </DialogHeader>

          <div className="px-6 pb-6 space-y-4">
            {/* Download PDF Section */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Download</h3>
              <Button
                onClick={handleDownloadPDF}
                disabled={isDownloading}
                className="w-full flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-900"
              >
                <Download className="w-4 h-4" />
                {isDownloading ? "Downloading..." : "Download PDF"}
              </Button>
            </div>

            {/* Social Media Sharing */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Share via</h3>
              <div className="grid grid-cols-2 gap-3">
                {socialPlatforms.map((platform) => (
                  <Button
                    key={platform.name}
                    onClick={() => handleShare(platform)}
                    className={`flex items-center gap-2 text-white ${platform.color} transition-colors`}
                  >
                    <platform.icon className="w-4 h-4" />
                    {platform.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Copy Link */}
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">Or copy link</h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shareUrl}
                  readOnly
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50"
                />
                <Button
                  onClick={() => handleShare({ name: "Copy Link" })}
                  variant="outline"
                  className="px-4"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
} 