"use client";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Progress } from "../components/ui/progress";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

export default function EnhancedServiceTable({ services, onClick, loadingServiceId }) {
  const [progress, setProgress] = useState(0);

  const loading = useSelector((state) => state.itinerary.loading);
  const loadingService = services.find(service => service.id === loadingServiceId);
  
  return (
    <div className="w-full overflow-x-auto p-4 bg-gradient-to-b from-[#F8F9FB] to-[#FBFCFD] rounded-lg shadow-lg">
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white rounded-lg shadow-md w-full">
          <Progress value={progress} className="w-[80%] mb-6" />
          <p className="text-lg font-semibold text-[#FF385C] animate-pulse">
            Loading {loadingService?.name || "AI data"}...
          </p>
        </div>
      ) : (
        <Table className="w-full bg-white rounded-lg shadow-md overflow-hidden">
          <TableHeader>
            <TableRow className="bg-[#F4F5F9] border-b border-[#E8EAF2]">
              <TableCell className="p-4 text-left text-xs sm:text-sm font-semibold text-[#333]">
                Service
              </TableCell>
              <TableCell className="p-4 text-left text-xs sm:text-sm font-semibold text-[#333]">
                Icon
              </TableCell>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.map((service, index) => (
              <TableRow
                key={service.id || index}
                className="cursor-pointer border-b border-[#E8EAF2] hover:bg-[#FF385C] hover:text-white transition-all group"
                onClick={() => onClick(service)}
              >
                <TableCell className="p-4 text-xs sm:text-sm font-medium">
                  {service.name}
                </TableCell>
                <TableCell className="p-4 text-xs sm:text-sm font-medium">
                  <div className="relative w-20 h-20 overflow-hidden shadow-md group-hover:scale-110 group-hover:shadow-lg transition-all">
                    <Image
                      src={service.image_url || "/placeholder.svg?height=80&width=80"}
                      width={80}
                      height={80}
                      alt={service.name || "Service"}
                      className="object-cover w-full h-full"
                    />
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
