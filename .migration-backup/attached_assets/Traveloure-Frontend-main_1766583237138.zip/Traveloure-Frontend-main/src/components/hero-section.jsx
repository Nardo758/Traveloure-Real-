"use client"

import { useState } from "react"
import Image from "next/image"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Carousel, CarouselContent, CarouselItem } from "../components/ui/carousel"
import Autoplay from "embla-carousel-autoplay"
import { Button } from "../components/ui/button"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { toast } from "sonner"
import { cn } from "../lib/utils"

const images = [
  "/landing-img1.png",
  "/landing-img1.png",
  "/landing-img1.png",
  "/landing-img1.png",
]

// Zod schema
const tripFormSchema = z.object({
  trip: z.string().min(2, { message: "Please enter a valid trip location." }),
})

export default function HeroSection() {
  const router = useRouter()
  const { data: session } = useSession()
  const [activeIndex, setActiveIndex] = useState(0)


  return (
    <>
      <section
        className="w-full py-10 md:py-16 relative"
        style={{
          backgroundImage: "url('/expert-section-bg.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Beta Badge - Top Right Corner with Ribbon Effect */}
        <div className="absolute top-4 right-4 md:top-8 md:right-8 z-10">
          <div className="relative">
            <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white px-5 py-2.5 rounded-lg shadow-2xl flex items-center gap-2 transform rotate-2 hover:rotate-0 transition-transform duration-300 border-2 border-orange-300">
              <span className="text-sm font-bold animate-pulse">🚀</span>
              <span className="text-sm font-bold">BETA</span>
              <span className="text-xs opacity-95 font-medium">VERSION</span>
            </div>
            {/* Ribbon tail effect */}
            <div className="absolute -bottom-1 right-2 w-0 h-0 border-l-8 border-l-transparent border-r-8 border-r-transparent border-t-8 border-t-orange-400"></div>
          </div>
        </div>
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 items-center gap-10">
          {/* Left Content */}
          <div>
            <h1 className="text-3xl md:text-5xl font-extrabold text-black leading-tight">
              Revolutionized Your <br />
              Travel Planning With <br />
              AI & <span className="text-green-600">Travel</span> Experts
            </h1>
            <p className="text-gray-500 mt-6 max-w-md text-sm md:text-base">
              Experience personalized travel planning with insider knowledge from travel experts,
              powered by advanced AI.
            </p>
            
            {/* Beta Notice */}
            <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-orange-50 border border-orange-200 rounded-lg">
              <span className="text-orange-600 font-semibold text-xs">BETA</span>
              <span className="text-orange-700 text-xs">New features in development • Your feedback matters</span>
            </div>

            <div className="flex flex-wrap gap-4 mt-8">
              <Button
                onClick={() => router.push("/Itinerary")}
                className="bg-[#ff3e65] hover:bg-[#FF385C] text-white px-6 py-4 rounded-lg text-sm font-semibold"
              >
                Create a New Trip →
              </Button>
              <Button
                variant="outline"
                onClick={() => router.push("/experts")}
                className="px-6 py-4 rounded-lg text-sm font-semibold"
              >
                Build with an Expert
              </Button>
              <Button
                onClick={() => router.push("/help-me-decide")}
                variant="outline"
                className="px-6 py-4 rounded-lg text-sm font-semibold"
              >
                Help Me Decide
              </Button>
            </div>
          </div>

          {/* Right Image Carousel */}
          <div className="relative w-full rounded-xl overflow-hidden shadow-lg">
            <Carousel
              plugins={[Autoplay({ delay: 4000 })]}
              opts={{ loop: true }}
              onSlideChange={(index) => setActiveIndex(index)}
            >
              <CarouselContent>
                {images.map((src, index) => (
                  <CarouselItem key={index}>
                    <div className="relative">
                      <div className="overflow-hidden border-[2px] border-[#F5F0E8CC] rounded-xl">
                        <Image
                          src={src}
                          alt={`Hero Image ${index + 1}`}
                          width={800}
                          height={500}
                          className="object-cover w-full h-[300px] md:h-[500px]"
                        />
                      </div>
                      {/* Dots */}
                      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                        {images.map((_, i) => (
                          <span
                            key={i}
                            className={cn(
                              "w-2 h-2 rounded-full bg-white/50 transition-colors duration-300",
                              activeIndex === i && "bg-white"
                            )}
                          />
                        ))}
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>
        </div>
      </section>

      {/* Modal */}
      
       
    </>
  )
}
