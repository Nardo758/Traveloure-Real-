"use client"

import { FileVideo, Download } from "lucide-react"

export function VideoAttachmentPlayer({ 
  attachment, 
  isOutgoing 
}) {
  // Handle both API URLs and file objects
  const getVideoUrl = () => {
    if (!attachment) {
      return null
    }
    
    if (typeof attachment === 'string') {
      return attachment.startsWith('http') 
        ? attachment 
        : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment}`
    } else if (attachment instanceof File || attachment instanceof Blob) {
      return URL.createObjectURL(attachment)
    } else {
      // Handle case where attachment is an object but not a File/Blob
      // Try to extract URL from the object
      if (attachment.url) {
        return attachment.url.startsWith('http') 
          ? attachment.url 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.url}`
      } else if (attachment.attachment) {
        return attachment.attachment.startsWith('http') 
          ? attachment.attachment 
          : `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}${attachment.attachment}`
      }
      return null
    }
  }

  const videoUrl = getVideoUrl()
  
  // Don't render if no valid URL
  if (!videoUrl) {
    return null
  }

  return (
    <div className="mt-2">
      <div className={`flex items-center gap-3 p-3 rounded-lg border ${
        isOutgoing 
          ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] bg-opacity-10 border-pink-200' 
          : 'bg-gray-50 border-gray-200'
      }`}>
        <div className={`p-2 rounded-lg ${
          isOutgoing 
            ? 'bg-gradient-to-r from-[#F30131] to-[#BE35EB] text-white' 
            : 'bg-white text-gray-600 border border-gray-200'
        }`}>
          <FileVideo className="w-4 h-4" />
        </div>
        
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium ${
            isOutgoing ? 'text-white' : 'text-gray-900'
          }`}>
            Video file
          </p>
        </div>
        
        <a 
          href={videoUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className={`p-1.5 rounded-md transition-colors ${
            isOutgoing 
              ? 'text-white hover:bg-white hover:text-[#F30131]' 
              : 'text-gray-500 hover:bg-gray-200'
          }`}
          title="Download video"
        >
          <Download className="w-3.5 h-3.5" />
        </a>
      </div>
      
      {/* Video preview */}
      <div className="mt-2">
        <div className="relative">
          <video 
            src={videoUrl} 
            className="max-w-full h-auto rounded-lg max-h-32 object-cover cursor-pointer"
            preload="metadata"
            controls
            onPlay={(e) => {
              // Hide play button overlay when video starts playing
              e.target.nextElementSibling.style.display = 'none'
            }}
            onPause={(e) => {
              // Show play button overlay when video is paused
              e.target.nextElementSibling.style.display = 'flex'
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-black bg-opacity-50 rounded-full p-2">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
