"use client"

import { Card, CardContent } from "../../ui/card"
import Image from "next/image"
import servicebgIcon1 from "../../public/service-bg-icon1.png"
import servicebgIcon2 from "../../public/service-icon2.png"
import servicebgIcon3 from "../../public/service-icon3 (1).png"
import curveicon from "../../public/servciecurveicon.png"
import aeroicon from "../../public/aeroicon.png"
import cardim1 from "../../public/cardim1.png"
import cardim2 from "../../public/cardim2.png"
import cardim3 from "../../public/cardim3.png"

const services = [
  {
    title: "Travel Expert",
    image: cardim1,
    alt: "Travel Expert",
  },
  {
    title: "Travel Services",
    image: cardim2,
    alt: "Travel Services",
  },
  {
    title: "AI Itinerary",
    image: cardim3,
    alt: "AI Itinerary",
  },
]

export default function ServicesSection() {
  return (
    <section className="pt-16 pb-15 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-[127px] h-[65px]">
        <Image src={servicebgIcon1} alt="icon" />
      </div>
      <div className="absolute top-10 right-10 w-[81px] h-[101px]">
        <Image src={servicebgIcon2} alt="icon" />
      </div>
      <div className="absolute bottom-5 left-0 w-[81px] h-[101px]">
        <Image src={servicebgIcon3} alt="icon" />
      </div>
      <div className="absolute bottom-[-20px] right-[-50px]">
        <Image src={curveicon} alt="icon" className="w-[127px] h-[251px]" />
      </div>
      <div className="absolute bottom-[210px] right-[63px] w-[81px] h-[101px]">
        <Image src={aeroicon} alt="icon" />
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our <span className="text-green-600">Services</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From planning to packing — get smart suggestions, seamless bookings, and travel insights tailored to you.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 justify-items-center">
          {services.map((service, index) => (
            <Card
              key={index}
              className="w-[300px] rounded-lg overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
            >
              <CardContent className="p-0">
                <div className="relative w-full h-[260px]">
                  <Image
                    src={service.image}
                    alt={service.alt}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <div className="px-6 py-4 text-center">
                  <h3 className="text-xl font-semibold">{service.title}</h3>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
