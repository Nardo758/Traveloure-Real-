"use client"

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { MapPin, Paperclip, Download, Eye, CheckCircle, XCircle, Clock } from 'lucide-react'
import { Button } from './ui/button'
import { toast } from 'sonner'
import ItineraryDecisionModal from './ItineraryDecisionModal'

export default function ItineraryMessage({ itinerary, onApprove, onRequestEdit, isOwnMessage = false }) {
  const [isLoading, setIsLoading] = useState(false)
  const [showDecisionModal, setShowDecisionModal] = useState(false)
  const [pendingAction, setPendingAction] = useState(null) // 'accept' or 'reject'
  const { data: session } = useSession()
  
  // Debug logging

  
  // Determine if we should show status messages
  const shouldShowApprovedStatus = itinerary.status === 'approved'
  const shouldShowRejectedStatus = itinerary.status === 'rejected'
  const shouldShowPendingStatus = itinerary.status === 'pending'
  
  // Show buttons when itinerary is pending
  const isItineraryPending = itinerary.status === 'pending' || !itinerary.status
  const shouldShowButtons = isItineraryPending && !isOwnMessage
  
  const handleApprove = () => {
    setPendingAction('accept')
    setShowDecisionModal(true)
  }

  const handleRequestEdit = () => {
    setPendingAction('reject')
    setShowDecisionModal(true)
  }

  const handleConfirmDecision = async () => {
    if (!pendingAction || !itinerary.id) return

    setIsLoading(true)
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}/ai/submit-itinerary/${itinerary.id}/decision/`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.backendData?.accessToken}`
        },
        body: JSON.stringify({
          status: pendingAction === 'accept' ? 'accepted' : 'rejected'
        })
      })

      if (!response.ok) {
        throw new Error('Failed to update itinerary status')
      }

      const data = await response.json()

      // Call the parent component's handler if provided
      if (pendingAction === 'accept' && onApprove) {
        await onApprove(itinerary.id)
      } else if (pendingAction === 'reject' && onRequestEdit) {
        await onRequestEdit(itinerary.id)
      }

      // Status will be shown in the itinerary message box via WebSocket

      setShowDecisionModal(false)
      setPendingAction(null)

    } catch (error) {
      console.error("Failed to update itinerary status:", error)
      toast.error(
        pendingAction === 'accept' 
          ? 'Failed to approve itinerary' 
          : 'Failed to reject itinerary'
      )
    } finally {
      setIsLoading(false)
    }
  }

  const handleCloseModal = () => {
    setShowDecisionModal(false)
    setPendingAction(null)
  }

  const handleDownload = () => {
    if (itinerary.attachment) {
      // Create a temporary link to download the file
      const link = document.createElement('a')
      link.href = itinerary.attachment
      link.download = `${itinerary.title || 'itinerary'}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      toast.success('Download started!')
    } else {
      toast.error('No attachment available for download')
    }
  }

  const handleView = () => {
    if (itinerary.attachment) {
      window.open(itinerary.attachment, '_blank')
    } else {
      toast.error('No attachment available to view')
    }
  }

  // Format timestamp
  const formatTimeAgo = (timestamp) => {
    if (!timestamp) return 'Just now'
    
    const now = new Date()
    const messageTime = new Date(timestamp)
    const diffInSeconds = Math.floor((now - messageTime) / 1000)
    
    if (diffInSeconds < 60) return 'Just now'
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`
    
    return messageTime.toLocaleDateString()
  }

  return (
    <>
      {/* Decision Modal */}
      <ItineraryDecisionModal
        isOpen={showDecisionModal}
        onClose={handleCloseModal}
        onConfirm={handleConfirmDecision}
        action={pendingAction}
        itineraryTitle={itinerary.title}
        isLoading={isLoading}
      />

      <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4`}>
        <div className="flex items-start gap-3 max-w-sm">
        {/* Profile Picture */}
        {!isOwnMessage && (
          <div className="w-10 h-10 rounded-full bg-gray-300 flex-shrink-0 mt-1">
            <img 
              src="/dummypic.png" 
              alt="Profile" 
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        )}
        
        {/* Itinerary Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 relative">
          {/* Header */}
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 text-sm">
                {itinerary.title}
              </h3>
              <div className="flex items-center gap-1 mt-1">
                <MapPin className="w-3 h-3 text-gray-500" />
                <span className="text-xs text-gray-500">{itinerary.location}</span>
              </div>
            </div>
          </div>
          
          {/* Divider */}
          <div className="border-t border-gray-100 mb-3"></div>
          
          {/* Greeting and Description */}
          <div className="mb-3">
            <p className="text-sm font-medium text-gray-900 mb-2">
              Hello {itinerary.receiver?.first_name || 'Traveler'},
            </p>
            {/* Show description only for receivers (users), not for local experts (senders) */}
            {!isOwnMessage && itinerary.description && (
              <p className="text-sm text-gray-600 leading-relaxed">
                {itinerary.description}
              </p>
            )}
            {/* Show generic message only for receivers when no description is available */}
            {!isOwnMessage && !itinerary.description && (
              <p className="text-sm text-gray-600 leading-relaxed">
                Your custom itinerary has been prepared based on your trip details and preferences. Please review the full plan using the options below. You can approve the itinerary to confirm your contract, or request edits if you'd like any changes. We look forward to making your journey memorable!
              </p>
            )}
          </div>
          
          {/* File Attachment */}
          {itinerary.attachment && (
            <div className="mb-3 p-2 bg-gray-50 rounded border">
              <div className="flex items-center gap-2">
                <Paperclip className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">Attachment available</span>
              </div>
            </div>
          )}
          
          {/* Action Buttons for Download/View */}
          {itinerary.attachment && (
            <div className="mb-4 flex gap-2">
              <Button
                onClick={handleDownload}
                variant="outline"
                size="sm"
                className="flex-1 border-pink-200 text-pink-600 hover:bg-pink-50 hover:border-pink-300"
              >
                <Download className="w-3 h-3 mr-1" />
                Download
              </Button>
              <Button
                onClick={handleView}
                size="sm"
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
              >
                <Eye className="w-3 h-3 mr-1" />
                Click to View
              </Button>
            </div>
          )}
          
          {/* Note */}
          {shouldShowButtons && (
            <p className="text-xs text-gray-500 mb-3">
              Note*: By clicking "Approve Itinerary," you agree to the proposed plan, and your contract with the expert will be finalized.
            </p>
          )}

          {/* Action Buttons or Status */}
          <>
            {/* Show Approve/Request Edit buttons if itinerary is pending and user is the receiver */}
            {shouldShowButtons && (
              <div className="flex gap-2">
                <Button
                  onClick={handleRequestEdit}
                  disabled={isLoading}
                  variant="outline"
                  size="sm"
                  className="flex-1 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
                >
                  Request to Edit
                </Button>
                <Button
                  onClick={handleApprove}
                  disabled={isLoading}
                  size="sm"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  Approve
                </Button>
              </div>
            )}
          
            {/* Show Approved status */}
            {shouldShowApprovedStatus && (
              <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-800">
                    {isOwnMessage ? 'You have approved the itinerary' : 'Itinerary has been approved'}
                  </p>
                </div>
              </div>
            )}
            
            {/* Show Rejected status */}
            {shouldShowRejectedStatus && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <XCircle className="w-5 h-5 text-red-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-red-800">
                    {isOwnMessage ? 'Rejected the itinerary' : 'Itinerary has been rejected'}
                  </p>
                </div>
              </div>
            )}
            
            {/* Show Pending status */}
            {shouldShowPendingStatus && (
              <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <Clock className="w-5 h-5 text-yellow-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-yellow-800">
                    Waiting for approval
                  </p>
                </div>
              </div>
            )}
          </>
        </div>
      </div>
      
        {/* Timestamp */}
        <div className={`text-xs text-gray-400 mt-1 ${isOwnMessage ? 'text-right' : 'text-left'}`}>
          {formatTimeAgo(itinerary.created_at)}
        </div>
      </div>
    </>
  )
}
