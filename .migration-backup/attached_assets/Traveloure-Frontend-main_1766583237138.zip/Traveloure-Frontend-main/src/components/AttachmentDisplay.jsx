"use client"

import { VoiceMessagePlayer } from "./VoiceMessagePlayer"
import { ImageAttachmentPlayer } from "./ImageAttachmentPlayer"
import { VideoAttachmentPlayer } from "./VideoAttachmentPlayer"
import { FileAttachmentPlayer } from "./FileAttachmentPlayer"

export function AttachmentDisplay({ 
  message, 
  attachment, 
  messageId, 
  index, 
  isOutgoing,
  voiceMessageBlobs,
  attachmentFiles 
}) {
  // Get message content from various possible properties
  const messageContent = message.content || message.message || message.chat?.message || ''
  
  // Detect if this is a voice message
  const isVoiceMessage = message.isVoiceMessage || 
                       (messageContent && messageContent.startsWith('Voice message (') && 
                        attachment && 
                        (typeof attachment === 'string' && attachment.includes('.wav')) ||
                        (attachment && attachment.type && attachment.type.startsWith('audio/')))
  
  // Extract duration from voice message text if available
  let voiceDuration = null
  if (isVoiceMessage && messageContent && messageContent.startsWith('Voice message (')) {
    const match = messageContent.match(/Voice message \((\d+):(\d+)\)/)
    if (match) {
      voiceDuration = parseInt(match[1]) * 60 + parseInt(match[2])
    }
  }

  // If it's a voice message, use VoiceMessagePlayer
  if (isVoiceMessage && attachment) {
    // Get the actual Blob if available (for local voice messages)
    let actualAttachment = attachment
    if (attachment.isVoiceMessage && attachment.blobId && voiceMessageBlobs) {
      const blob = voiceMessageBlobs.get(attachment.blobId)
      if (blob) {
        actualAttachment = blob
      }
    }
    
    return (
      <VoiceMessagePlayer
        message={message}
        attachment={actualAttachment}
        messageId={messageId}
        index={index}
        isOutgoing={isOutgoing}
        voiceDuration={voiceDuration}
      />
    )
  }

  // For non-voice attachments, determine the type and render appropriate component
  if (attachment) {
    // Get the actual File object if available (for local attachments)
    let actualAttachment = attachment
    if (attachment.fileId && attachmentFiles) {
      const file = attachmentFiles.get(attachment.fileId)
      if (file) {
        actualAttachment = file
      }
    } else if (attachmentFiles && messageId) {
      // Fallback: try to find file by message ID
      const file = attachmentFiles.get(messageId)
      if (file) {
        actualAttachment = file
      }
    }
    
    if (typeof actualAttachment === 'string') {
      // Handle string attachment (URL)
      if (actualAttachment.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
        return <ImageAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      } else if (actualAttachment.match(/\.(mp4|avi|mov|wmv|flv|webm)$/i)) {
        return <VideoAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      } else {
        return <FileAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      }
    } else {
      // Handle file attachment object
      if (actualAttachment.type && actualAttachment.type.startsWith('image/')) {
        return <ImageAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      } else if (actualAttachment.type && actualAttachment.type.startsWith('video/')) {
        return <VideoAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      } else {
        return <FileAttachmentPlayer attachment={actualAttachment} isOutgoing={isOutgoing} />
      }
    }
  }

  // No attachment to display
  return null
}
