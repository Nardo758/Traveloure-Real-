"use client"

import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { SessionProvider } from 'next-auth/react';
import { Toaster } from 'sonner';
import { WebSocketProvider } from './WebSocketProvider';
import loginSlice from '../app/redux-features/auth/auth';
import ItinerarySlice from '../app/redux-features/Itinerary/ItinerarySlice';
import HelpmeDecide from '../app/redux-features/help-me-decide/HelpmeDecideSlice';
import TalktoExpert from '../app/redux-features/TalktoExpert/TalktoExpert';
import Userprofile from '../app/redux-features/userprofile/UserprofileSlice';
import TravelExperts from '../app/redux-features/Travelexperts/travelexpertsSlice';
import ServiceProvider from '../app/redux-features/service-provider/serviceProviderSlice';
import ChatSlice from '../app/redux-features/chat/chatSlice';
import ContractSlice from '../app/redux-features/contract/contractSlice';
import LocalExpertSlice from '../app/redux-features/local-expert/localExpertSlice';
import CategorySlice from '../app/redux-features/category/categorySlice';
import FAQSlice from '../app/redux-features/faq/faqSlice';

const store = configureStore({
  reducer: {
    auth: loginSlice,
    itinerary: ItinerarySlice,
    helpme: HelpmeDecide,
    talkexpert: TalktoExpert,
    userprofile: Userprofile,
    travelExperts: TravelExperts,
    serviceProvider: ServiceProvider,
    chat: ChatSlice,
    contract: ContractSlice,
    localExpert: LocalExpertSlice,
    category: CategorySlice,
    faq: FAQSlice
  },
});

export default function ReduxProvider({ children }) {
  return (
    <SessionProvider>
      <Provider store={store}>
        <WebSocketProvider>
          {children}
          <Toaster />
        </WebSocketProvider>
      </Provider>
    </SessionProvider>
  );
} 