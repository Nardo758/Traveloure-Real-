/**
 * Validates a message using the AI validation API
 * @param {string} message - The message to validate
 * @param {string} token - Authentication token
 * @returns {Promise<{isValid: boolean, reason?: string}>}
 */
export const validateMessage = async (message, token) => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'}/ai/validate-message/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        message: message
      })
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    
    return {
      isValid: data.status === true,
      reason: data.reason || 'Message validation failed',
      data: data.data
    }
  } catch (error) {
    console.error('Error validating message:', error)
    return {
      isValid: false,
      reason: 'Failed to validate message. Please try again.'
    }
  }
}
